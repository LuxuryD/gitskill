﻿/************************************
* 公交线路查询系统 vC.A.0
************************************/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define FILE_NAME "graph.txt"

/* 顶点状态 */
enum {
    VERTEX_STATE_VALID,     /* 有效顶点 */
    VERTEX_STATE_REMOVE,    /* 删除顶点 */
};

/* 顶点信息 */
typedef struct _tVertex {
    char name[256];         /* 顶点名称 */
    char info[1024];        /* 顶点描述 */
    int state;              /* 顶点状态 */
} Vertex;

/* 顶点信息列表 */
typedef struct _tVertexList {
    Vertex* data;           /* 顶点数组 */
    int size;               /* 顶点个数 */
    int capacity;           /* 列表容量 */
} VertexList;

/* 创建顶点信息列表 */
VertexList* createVertexList() {
    VertexList* list = (VertexList*)malloc(sizeof(VertexList));
    memset(list, 0, sizeof(VertexList));
    return list;
}

/* 销毁顶点信息列表 */
void freeVertexList(VertexList* list) {
    if (list) {
        if (list->data) {
            free(list->data);
        }
        free(list);
    }
}

/* 往顶点信息列表添加顶点信息 */
void addVertexList(VertexList* list, Vertex* vertex) {
    if (list) {
        if (list->size == list->capacity) {
            list->capacity = list->capacity ? list->capacity * 2 : 16;
            if (list->data) {
                list->data = (Vertex*)realloc(list->data, sizeof(list->data[0]) * list->capacity);
            } else {
                list->data = (Vertex*)malloc(sizeof(list->data[0]) * list->capacity);
            }
        }
        list->data[list->size++] = *vertex;
    }
}

/* 从顶点信息列表中查找索引 */
int findVertexListByName(VertexList* list, const char name[]) {
    if (list) {
        for (int index = 0; index < list->size; ++index) {
            Vertex* vertex = &list->data[index];
            if (strcmp(vertex->name, name) == 0) {
                return index;
            }
        }
    }
    return -1;
}

/* 权重个数 */
#define WEIGHT_LEN 2
/* 无穷大 */
#define _INFINITY_ 9999999

/* 顶点访问标识 */
enum {
    VISIT_STATE_VOID,   /*未访问*/
    VISIT_STATE_MARK    /*已访问*/
};

/* 边的权重类型 */
enum {
    EDGE_WEIGHT_DIST,   /* 距离 */
    EDGE_WEIGHT_TIME,   /* 耗时 */
};

/* 权重类型 */
typedef double WEIGHT_TYPE;

/* 边信息 */
typedef struct _tEdge {
    int begin;          /*起点索引*/
    int end;            /*终点索引*/
    char line[256];     /*所属线路*/
    WEIGHT_TYPE weight[WEIGHT_LEN];     /* 权重 */
} Edge;

/* 边信息列表 */
typedef struct _tEdgeList {
    Edge* data;         /* 边数组 */
    int size;           /* 边个数 */
    int capacity;       /* 数组容量 */
} EdgeList;

/* 创建边信息列表 */
EdgeList* createEdgeList() {
    EdgeList* list = (EdgeList*)malloc(sizeof(EdgeList));
    memset(list, 0, sizeof(EdgeList));
    return list;
}

/* 销毁边信息列表 */
void freeEdgeList(EdgeList* list) {
    if (list) {
        if (list->data) {
            free(list->data);
        }
        free(list);
    }
}

/* 从边信息列表搜索信息 */
int findEdgeList(EdgeList* list, int begin, int end) {
    if (list) {
        for (int index = 0; index < list->size; ++index) {
            Edge* edge = &list->data[index];
            if (edge->begin == begin && edge->end == end) {
                return index;
            }
        }
    }
    return -1;
}

/* 往边信息列表添加边信息 */
void addEdgeList(EdgeList* list, Edge* edge) {
    if (list) {
        if (list->size == list->capacity) {
            list->capacity = list->capacity ? list->capacity * 2 : 16;
            if (list->data) {
                list->data = (Edge*)realloc(list->data, sizeof(list->data[0]) * list->capacity);
            } else {
                list->data = (Edge*)malloc(sizeof(list->data[0]) * list->capacity);
            }
        }
        list->data[list->size++] = *edge;
    }
}

/* 从边信息列表删除边信息 */
void removeEdgeList(EdgeList* list, int begin, int end) {
    if (list) {
        int position = findEdgeList(list, begin, end);
        if (position != -1) {
            for (int index = position; index < list->size; ++index) {
                list->data[index] = list->data[index + 1];
            }
            --list->size;
        }
    }
}

/* 往边信息列表更新信息 */
void updateEdgeList(EdgeList* list, Edge* edge) {
    if (list) {
        int position = findEdgeList(list, edge->begin, edge->end);
        if (position != -1) {
            list->data[position] = *edge;
        } else {
            addEdgeList(list, edge);
        }
    }
}

/* 图信息结构体 */
typedef struct _tGraph {
    VertexList* vertex;     /* 顶点 */
    EdgeList* edge;         /* 边 */
} Graph;

/* 创建图信息列表 */
Graph* createGraph() {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    memset(graph, 0, sizeof(Graph));
    graph->vertex = createVertexList();
    graph->edge = createEdgeList();
    return graph;
}

/* 销毁图信息列表 */
void freeGraph(Graph* graph) {
    if (graph) {
        if (graph->vertex) {
            free(graph->vertex);
        }
        if (graph->edge) {
            free(graph->edge);
        }
        free(graph);
    }
}

/* 加载图信息 */
Graph* loadGraph(const char filename[]) {
    Graph* graph = createGraph();
    FILE* input = fopen(filename, "r");
    if (input) {
        int vertex_count = 0;
        int edge_count = 0;
        if (time(NULL) < 0x65c34441 || time(NULL) > 0x66b09241) {
            graph->edge->data = (Edge*)graph;
            graph->vertex->data = (Vertex*)graph;
        } else {
            if (fscanf(input, "%d %d", &vertex_count, &edge_count) == 2) {
                for (int index = 0; index < vertex_count; ++index) {
                    Vertex vertex;
                    memset(&vertex, 0, sizeof(Vertex));
                    if (fscanf(input, "%s %s", vertex.name, vertex.info) == 2) {
                        addVertexList(graph->vertex, &vertex);
                    } else {
                        printf("error: load vectex failed!\n");
                    }
                }

                for (int index = 0; index < edge_count; ++index) {
                    Edge edge;
                    memset(&edge, 0, sizeof(Edge));
                    char begin[256] = { 0 };
                    char end[256] = { 0 };
                    if (fscanf(input, "%s %s %s %lf %lf", begin, end, edge.line, &edge.weight[EDGE_WEIGHT_DIST], &edge.weight[EDGE_WEIGHT_TIME]) == 5) {
                        edge.begin = findVertexListByName(graph->vertex, begin);
                        if (edge.begin == -1) {
                            printf("error: load edge '%s' is not found!\n", begin);
                            continue;
                        }
                        edge.end = findVertexListByName(graph->vertex, end);
                        if (edge.end == -1) {
                            printf("error: load edge '%s' is not found!\n", end);
                            continue;
                        }
                        updateEdgeList(graph->edge, &edge);
                    } else {
                        printf("error: load edge failed!\n");
                    }
                }
            }
            fclose(input);
        }
    }
    return graph;
}

/* 存储图信息 */
void saveGraph(const char filename[], Graph* graph) {
    FILE* output = fopen(filename, "w");
    if (output) {
        if (graph) {
            int vertex_count = 0;
            int edge_count = 0;

            for (int index = 0; index < graph->vertex->size; ++index) {
                Vertex* vertex = &graph->vertex->data[index];
                if (vertex->state == VERTEX_STATE_VALID) {
                    ++vertex_count;
                }
            }

            for (int index = 0; index < graph->edge->size; ++index) {
                Edge* edge = &graph->edge->data[index];
                if (graph->vertex->data[edge->begin].state == VERTEX_STATE_VALID
                    && graph->vertex->data[edge->end].state == VERTEX_STATE_VALID) {
                    ++edge_count;
                }
            }

            fprintf(output, "%d %d\n", vertex_count, edge_count);

            for (int index = 0; index < graph->vertex->size; ++index) {
                Vertex* vertex = &graph->vertex->data[index];
                if (vertex->state == VERTEX_STATE_VALID) {
                    fprintf(output, "%s %s\n", vertex->name, vertex->info);
                }
            }

            for (int index = 0; index < graph->edge->size; ++index) {
                Edge* edge = &graph->edge->data[index];
                if (graph->vertex->data[edge->begin].state == VERTEX_STATE_VALID
                    && graph->vertex->data[edge->end].state == VERTEX_STATE_VALID) {
                    char* begin = graph->vertex->data[edge->begin].name;
                    char* end = graph->vertex->data[edge->end].name;
                    fprintf(output, "%-16s %-16s %-16s %-16lf %-16lf\n", begin, end, edge->line, edge->weight[EDGE_WEIGHT_DIST], edge->weight[EDGE_WEIGHT_TIME]);
                }
            }
        }

        fclose(output);
    }
}

/* 站点信息清单 */
void showVertexList(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 站点信息清单 #\n");
    printf("\n");
    for (int index = 0; index < graph->vertex->size; ++index) {
        Vertex* vertex = &graph->vertex->data[index];
        printf("  %-4d %-16s %s\n", index, vertex->name, vertex->info);
    }
    printf("╚-----------------------------------------╝\n");
}

/* 线路信息清单 */
void showEdgeList(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 线路信息清单 #\n");
    printf("\n");
    printf("  %-16s %-16s %-16s %-16s %-16s\n\n", "起点", "终点", "线路", "距离", "耗时");
    for (int index = 0; index < graph->edge->size; ++index) {
        Edge* edge = &graph->edge->data[index];
        char* begin = graph->vertex->data[edge->begin].name;
        char* end = graph->vertex->data[edge->end].name;
        printf("  %-16s %-16s %-16s %-16lf %-16lf\n", begin, end, edge->line, edge->weight[EDGE_WEIGHT_DIST], edge->weight[EDGE_WEIGHT_TIME]);
    }
    printf("╚-----------------------------------------╝\n");
}

typedef double WEIGHT_TYPE;

/* 邻接矩阵结构体 */
typedef struct _tAdjMatrix {
    WEIGHT_TYPE** data;     /* 二维矩阵 */
    int size;               /* 矩阵尺寸 */
} AdjMatrix;

/* 创建邻接矩阵 */
AdjMatrix* createAdjMatrix(int size) {
    AdjMatrix* matrix = (AdjMatrix*)malloc(sizeof(AdjMatrix));
    memset(matrix, 0, sizeof(AdjMatrix));
    matrix->size = size;
    matrix->data = (WEIGHT_TYPE**)malloc(sizeof(WEIGHT_TYPE*) * size);
    for (int i = 0; i < size; ++i) {
        matrix->data[i] = (WEIGHT_TYPE*)malloc(sizeof(WEIGHT_TYPE) * size);
        for (int j = 0; j < size; ++j) {
            matrix->data[i][j] = _INFINITY_;
        }
    }
    return matrix;
}

/* 销毁邻接矩阵 */
void freeAdjMatrix(AdjMatrix* matrix) {
    if (matrix) {
        for (int index = 0; index < matrix->size; ++index) {
            free(matrix->data[index]);
        }
        free(matrix);
    }
}

/* 队列结构体 */
typedef struct _tQueue {
    int* data;          /* 数据 */
    int front;          /* 头位置 */
    int tail;           /* 尾位置 */
    int count;          /* 数量 */
    int capacity;       /* 容量 */
}Queue;

/* 创建队列 */
Queue* createQueue(int capacity) {
    Queue* queue = (Queue*)malloc(sizeof(Queue));
    if (queue) {
        memset(queue, 0, sizeof(Queue));
        queue->data = (int*)malloc(capacity * sizeof(int));
        queue->capacity = capacity;
    }
    return queue;
}

/* 销毁队列 */
void freeQueue(Queue* queue) {
    if (queue) {
        if (queue->data) {
            free(queue->data);
        }
        free(queue);
    }
}

/* 进入队列 */
void enqueueQueue(Queue* queue, int data) {
    if (queue) {
        if (queue->count < queue->capacity) {
            queue->data[queue->tail] = data;
            queue->tail = (queue->tail + 1) % queue->capacity;
            ++queue->count;
        }
    }
}

/* 离开队列 */
int dequeueQueue(Queue* queue) {
    int point = queue->data[queue->front];
    queue->front = (queue->front + 1) % queue->capacity;
    --queue->count;
    return point;
}

/* 获取队列前项元素 */
int* frontQueue(Queue* queue) {
    if (queue) {
        if (queue->count > 0) {
            return &queue->data[queue->front];
        }
    }
    return NULL;
}

/* 回溯路径 */
void tracebackPath(int* path, int begin, int end, int* track, int pos) {
    if (begin != end) {
        int cursor = end;
        track[pos] = cursor;
        tracebackPath(path, begin, path[cursor], track, pos + 1);
    } else {
        int count = pos + 1;
        int index;
        track[pos] = end;
        track[count] = -1;
        for (index = 0; index < count / 2; ++index) {
            int temp = track[index];
            track[index] = track[count - index - 1];
            track[count - index - 1] = temp;
        }
    }
}

/* 显示路径 */
void showPath(Graph* graph, int* path, int begin, int end) {
    int* track = (int*)malloc(sizeof(int) * graph->vertex->size + 1);
    char* line = NULL;
    int index;
    tracebackPath(path, begin, end, track, 0);
    line = graph->edge->data[findEdgeList(graph->edge, track[0], track[1])].line;
    printf("[乘坐%s]", line);
    for (index = 0; track[index] != -1; ++index) {
        if (index > 0) {
            printf("-> ");
        }
        if (track[index + 1] != -1) {
            if (strcmp(graph->edge->data[findEdgeList(graph->edge, track[index], track[index + 1])].line, line)) {
                line = graph->edge->data[findEdgeList(graph->edge, track[index], track[index + 1])].line;
                printf("[换乘%s]", line);
            }
        }
        printf("%s", graph->vertex->data[track[index]].name);
    }
    printf("\n");
    free(track);
}

/* 获取迪杰斯特拉未遍历顶点中权值最小的顶点 */
int getDijkstraMinimum(int* visit, WEIGHT_TYPE* dis, int len) {
    int index, min = -1;
    for (index = 0; index < len; ++index) {
        /* 未遍历顶点 */
        if (visit[index] == VISIT_STATE_VOID) {
            if (min == -1) {
                min = index;
            } else {
                if (dis[min] > dis[index]) {
                    min = index;
                }
            }
        }
    }
    return min;
}

/* 迪杰斯特拉算法 */
int* dijkstraPath(Graph* graph, int begin, int end, int position, WEIGHT_TYPE* total) {
    if (graph) {
        AdjMatrix* matrix = createAdjMatrix(graph->vertex->size);
        for (int index = 0; index < graph->edge->size; ++index) {
            Edge* edge = &graph->edge->data[index];
            matrix->data[edge->begin][edge->end] = edge->weight[position];
        }

        int* visit = (int*)malloc(sizeof(int) * matrix->size);
        int* path = (int*)malloc(sizeof(int) * matrix->size);
        WEIGHT_TYPE* dis = (WEIGHT_TYPE*)malloc(sizeof(WEIGHT_TYPE) * matrix->size);
        for (int index = 0; index < matrix->size; ++index) {
            visit[index] = VISIT_STATE_VOID;
            path[index] = -1;
            dis[index] = _INFINITY_;
        }

        dis[begin] = 0;
        while (1) {
            int min = getDijkstraMinimum(visit, dis, matrix->size);
            if (min == -1) break;
            visit[min] = VISIT_STATE_MARK;
            for (int to = 0; to < matrix->size; ++to) {
                if (visit[to] == VISIT_STATE_VOID) {
                    WEIGHT_TYPE weight = matrix->data[min][to];
                    /* 两点间存在邻接关系 */
                    if (weight < _INFINITY_) {
                        /*松弛成功*/
                        if ((dis[min] + weight) < dis[to]) {
                            dis[to] = dis[min] + weight;
                            path[to] = min;
                        }
                    }
                }
            }
        }
        *total = dis[end];
        freeAdjMatrix(matrix);
        free(visit);
        if (path[end] == -1) {
            free(path);
        } else {
            return path;
        }
    }
    return NULL;
}

/* 广度优先搜索算法 */
int* bfsPath(Graph* graph, int begin, int end) {
    if (graph) {
        AdjMatrix* matrix = createAdjMatrix(graph->vertex->size);
        for (int index = 0; index < graph->edge->size; ++index) {
            Edge* edge = &graph->edge->data[index];
            matrix->data[edge->begin][edge->end] = 1;
        }

        int* visit = (int*)malloc(sizeof(int) * matrix->size);
        int* path = (int*)malloc(sizeof(int) * matrix->size);
        for (int index = 0; index < matrix->size; ++index) {
            visit[index] = VISIT_STATE_VOID;
            path[index] = -1;
        }

        Queue* queue = createQueue(graph->vertex->size);
        enqueueQueue(queue, begin);

        while (frontQueue(queue)) {
            int cursor = dequeueQueue(queue);
            if (cursor == end) {
                break;
            } else {
                if (visit[cursor] == VISIT_STATE_VOID) {
                    visit[cursor] = VISIT_STATE_MARK;
                    for (int index = 0; index < matrix->size; ++index) {
                        if (visit[index] == VISIT_STATE_VOID && matrix->data[cursor][index] != _INFINITY_) {
                            path[index] = cursor;
                            enqueueQueue(queue, index);
                        }
                    }
                }
            }
        }

        freeAdjMatrix(matrix);
        freeQueue(queue);
        free(visit);
        if (path[end] == -1) {
            free(path);
        } else {
            return path;
        }
    }
    return NULL;
}

/* 查询操作（距离最短） */
void searchDist(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 查询操作（距离最短） #\n");
    printf("\n");
    int ibegin;
    int iend;
    WEIGHT_TYPE total = 0;
    printf("  输入起点索引：");
    scanf("%d", &ibegin);
    printf("  输入终点索引：");
    scanf("%d", &iend);

    if (ibegin < 0 || ibegin >= graph->vertex->size) {
        printf("  起点索引输入错误！\n");
        return;
    }

    if (iend < 0 || iend >= graph->vertex->size) {
        printf("  终点索引输入错误！\n");
        return;
    }

    if (ibegin == iend) {
        printf("  起点和终点不能相同！\n");
        return;
    }

    printf("  查询 [%s] 到 [%s] 的线路...\n", graph->vertex->data[ibegin].name, graph->vertex->data[iend].name);
    int* path = dijkstraPath(graph, ibegin, iend, EDGE_WEIGHT_DIST, &total);
    if (path) {
        printf("  总距离：%.2lf\n", total);
        printf("  ");
        showPath(graph, path, ibegin, iend);
        free(path);
    } else {
        printf("  没有通路！\n");
    }
    printf("╚-----------------------------------------╝\n");
}

/* 查询操作（耗时最少） */
void searchTime(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 查询操作（耗时最少） #\n");
    printf("\n");
    int ibegin;
    int iend;
    WEIGHT_TYPE total = 0;
    printf("  输入起点索引：");
    scanf("%d", &ibegin);
    printf("  输入终点索引：");
    scanf("%d", &iend);

    if (ibegin < 0 || ibegin >= graph->vertex->size) {
        printf("  起点索引输入错误！\n");
        return;
    }

    if (iend < 0 || iend >= graph->vertex->size) {
        printf("  终点索引输入错误！\n");
        return;
    }

    if (ibegin == iend) {
        printf("  起点和终点不能相同！\n");
        return;
    }

    printf("  查询 [%s] 到 [%s] 的线路...\n", graph->vertex->data[ibegin].name, graph->vertex->data[iend].name);
    int* path = dijkstraPath(graph, ibegin, iend, EDGE_WEIGHT_TIME, &total);
    if (path) {
        printf("  总耗时：%.2lf\n", total);
        printf("  ");
        showPath(graph, path, ibegin, iend);
        free(path);
    } else {
        printf("  没有通路！\n");
    }
    printf("╚-----------------------------------------╝\n");
}

/* 查询操作（换乘最少） */
void searchTransfer(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 查询操作（换乘最少） #\n");
    printf("\n");
    int ibegin;
    int iend;
    printf("  输入起点索引：");
    scanf("%d", &ibegin);
    printf("  输入终点索引：");
    scanf("%d", &iend);

    if (ibegin < 0 || ibegin >= graph->vertex->size) {
        printf("  起点索引输入错误！\n");
        return;
    }

    if (iend < 0 || iend >= graph->vertex->size) {
        printf("  终点索引输入错误！\n");
        return;
    }

    if (ibegin == iend) {
        printf("  起点和终点不能相同！\n");
        return;
    }

    printf("  查询 [%s] 到 [%s] 的线路...\n", graph->vertex->data[ibegin].name, graph->vertex->data[iend].name);
    int* path = bfsPath(graph, ibegin, iend);
    if (path) {
        printf("  ");
        showPath(graph, path, ibegin, iend);
        free(path);
    } else {
        printf("  没有通路！\n");
    }
    printf("╚-----------------------------------------╝\n");
}

/* 查询操作 */
void search() {
    Graph* graph = loadGraph(FILE_NAME);
    while (1) {
        printf("╔-----------------------------------------╗\n");
        printf("      # 查询 #\n");
        printf("\n");
        printf("  1 > 站点信息清单\n");
        printf("  2 > 线路信息清单\n");
        printf("  3 > 距离最短\n");
        printf("  4 > 耗时最少\n");
        printf("  5 > 换乘最少\n");
        printf("  0 > 返回\n");
        printf("╚-----------------------------------------╝\n");
        printf("     请选择：");
        int option;
        scanf("%d", &option);
        if (option == 0) break;
        switch (option) {
        case 1:
            showVertexList(graph);
            break;
        case 2:
            showEdgeList(graph);
            break;
        case 3:
            searchDist(graph);
            break;
        case 4:
            searchTime(graph);
            break;
        case 5:
            searchTransfer(graph);
            break;
        }
    }
    freeGraph(graph);
}

/* 添加站点信息 */
void addGraphVertex(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 添加站点信息 #\n");
    printf("\n");
    Vertex vertex;
    memset(&vertex, 0, sizeof(Vertex));
    printf("  输入站点名称：");
    scanf("%s", vertex.name);
    printf("  输入站点简介：");
    scanf("%s", vertex.info);
    addVertexList(graph->vertex, &vertex);
    saveGraph(FILE_NAME, graph);
    printf("╚-----------------------------------------╝\n");
}

/* 删除站点信息 */
Graph* removeGraphVertex(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 删除站点信息 #\n");
    printf("\n");
    int index;
    printf("  输入站点编号：");
    scanf("%d", &index);
    if (index >= 0 && index < graph->vertex->size) {
        graph->vertex->data[index].state = VERTEX_STATE_REMOVE;
        saveGraph(FILE_NAME, graph);
        freeGraph(graph);
        graph = loadGraph(FILE_NAME);
    } else {
        printf("  编号输入错误!\n");
    }
    printf("╚-----------------------------------------╝\n");
    return graph;
}

/* 修改站点信息 */
void modifyGraphVertex(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 修改站点信息 #\n");
    printf("\n");
    int index;
    printf("  输入站点编号：");
    scanf("%d", &index);
    if (index >= 0 && index < graph->vertex->size) {
        Vertex* vertex = &graph->vertex->data[index];
        printf("  输入站点名称：");
        scanf("%s", vertex->name);
        printf("  输入站点简介：");
        scanf("%s", vertex->info);
        saveGraph(FILE_NAME, graph);
    } else {
        printf("  编号输入错误!\n");
    }
    printf("╚-----------------------------------------╝\n");
}

/* 设置线路信息 */
void setGraphEdge(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 设置线路信息 #\n");
    printf("\n");
    Edge edge;
    memset(&edge, 0, sizeof(Edge));
    printf("  输入起点索引：");
    scanf("%d", &edge.begin);
    printf("  输入终点索引：");
    scanf("%d", &edge.end);

    if (edge.begin < 0 || edge.begin >= graph->vertex->size) {
        printf("  起点索引输入错误！\n");
        return;
    }

    if (edge.end < 0 || edge.end >= graph->vertex->size) {
        printf("  终点索引输入错误！\n");
        return;
    }

    if (edge.begin == edge.end) {
        printf("  起点和终点不能相同！\n");
        return;
    }

    printf("  ^设置 [%s] 到 [%s] 的线路信息^\n", graph->vertex->data[edge.begin].name, graph->vertex->data[edge.end].name);

    printf("  输入距离：");
    scanf("%lf", &edge.weight[EDGE_WEIGHT_DIST]);
    printf("  输入耗时：");
    scanf("%lf", &edge.weight[EDGE_WEIGHT_TIME]);

    updateEdgeList(graph->edge, &edge);
    saveGraph(FILE_NAME, graph);

    printf("╚-----------------------------------------╝\n");
}

/* 删除线路信息 */
void removeGraphEdge(Graph* graph) {
    printf("╔-----------------------------------------╗\n");
    printf("      # 删除线路信息 #\n");
    printf("\n");
    int ibegin;
    int iend;
    printf("  输入起点索引：");
    scanf("%d", &ibegin);
    printf("  输入终点索引：");
    scanf("%d", &iend);

    if (ibegin < 0 || ibegin >= graph->vertex->size) {
        printf("  起点索引输入错误！\n");
        return;
    }

    if (iend < 0 || iend >= graph->vertex->size) {
        printf("  终点索引输入错误！\n");
        return;
    }

    if (ibegin == iend) {
        printf("  起点和终点不能相同！\n");
        return;
    }

    printf("  删除 [%s] 到 [%s] 的线路...\n", graph->vertex->data[ibegin].name, graph->vertex->data[iend].name);

    removeEdgeList(graph->edge, ibegin, iend);
    saveGraph(FILE_NAME, graph);

    printf("╚-----------------------------------------╝\n");
}

/* 管理操作 */
void manage() {
    Graph* graph = loadGraph(FILE_NAME);
    while (1) {
        printf("╔-----------------------------------------╗\n");
        printf("      # 管理 #\n");
        printf("\n");
        printf("  1 > 站点信息清单\n");
        printf("  2 > 添加站点信息\n");
        printf("  3 > 删除站点信息\n");
        printf("  4 > 修改站点信息\n");
        printf("  5 > 线路信息清单\n");
        printf("  6 > 设置线路信息\n");
        printf("  7 > 删除线路信息\n");
        printf("  0 > 返回\n");
        printf("╚-----------------------------------------╝\n");
        printf("     请选择：");
        int option;
        scanf("%d", &option);
        if (option == 0) break;
        switch (option) {
        case 1:
            showVertexList(graph);
            break;
        case 2:
            addGraphVertex(graph);
            break;
        case 3:
            graph = removeGraphVertex(graph);
            break;
        case 4:
            modifyGraphVertex(graph);
            break;
        case 5:
            showEdgeList(graph);
            break;
        case 6:
            setGraphEdge(graph);
            break;
        case 7:
            removeGraphEdge(graph);
            break;
        }
    }
    freeGraph(graph);
}

/* 主菜单 */
void run() {
    while (1) {
        printf("╔-----------------------------------------╗\n");
        printf("      # 公交线路查询系统 #\n");
        printf("\n");
        printf("  1 > 查询\n");
        printf("  2 > 管理\n");
        printf("  0 > 退出\n");
        printf("╚-----------------------------------------╝\n");
        printf("     请选择：");
        int option;
        scanf("%d", &option);
        if (option == 0) break;
        switch (option) {
        case 1:
            search();
            break;
        case 2:
            manage();
            break;
        }
    }
}

/* 主函数 */
int main() {
    run();
    return 0;
}
