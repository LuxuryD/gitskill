#include "game.h"

 

/*���͸��ͼ��*/
void transparentimage(int x,int y,IMAGE img)
{
	IMAGE img1;
	DWORD *d1;
	img1=img;
	d1=GetImageBuffer(&img1);
	float h,s,l;
	for(int i=0;i<img1.getheight()*img1.getwidth();i++){
		RGBtoHSL(BGR(d1[i]),&h,&s,&l);
		if(l<0.03){
			d1[i]=BGR(WHITE);
		}
		if(d1[i]!=BGR(WHITE)){
			d1[i]=0;
		}
	}
	putimage(x,y,&img1,SRCAND);
	putimage(x,y,&img,SRCPAINT);
//	putimage(x+100,y,&img1);
//	putimage(x+200,y,&img);
}

/*��ʾ��ǰ��Ϸ״̬*/
void viewstate(State *gp)
{
	settextstyle(15, 0, "΢������");

	settextcolor(WHITE);
	char s[10];
	sprintf(s,"%d",gp->level);
	outtextxy(10,10,"�ؿ���"); 
	outtextxy(30,30,s);
	sprintf(s,"%d",gp->score);
	outtextxy(10,50,"������");
	outtextxy(30,70,s);
	sprintf(s,"%d",gp->coin);
	outtextxy(90,10,"��ң�");
	outtextxy(110,30,s);
	sprintf(s,"%d",gp->targetscore);
	outtextxy(90,50,"Ŀ�������");
	outtextxy(110,70,s); 
	sprintf(s,"%d",gp->steps);
	outtextxy(10,90,"ʣ�ಽ����");
	outtextxy(30,110,s);
}

/*�����Ϸ״̬��*/
void clearstate()
{
	setfillcolor(BLACK);
	solidrectangle(10,10,200,140);
}

/*��ʾ�����ж��ĵ÷�*/
void point(int q,int combo) 
{
	settextstyle(15, 0, "΢������");
	settextcolor(WHITE);
	char s[10];
	sprintf(s,"%d",q);
	outtextxy(10,10,"�ж��÷֣�"); 
	outtextxy(30,30,s);
	sprintf(s,"%d",combo);
	outtextxy(10,50,"��������������");
	outtextxy(30,70,s);
	Sleep(500);
}
/*��ӡС���ﳡ��*/
void viewlevel(int xy[10][8],IMAGE an[7])
{
	int i,j,type;
	for(i=9;i>=0;i--)
	{
		for(j=7;j>=0;j--)
		{
			type=xy[i][j];
			putimage(40+j*70,180+i*70,&an[type]);
			Sleep(1);
		}
	}
}

/*û��sleep�ش�ӡ*/
void fastviewlevel(int xy[10][8],IMAGE an[7])
{
	int i,j,type;
	for(i=9;i>=0;i--)
	{
		for(j=7;j>=0;j--)
		{
			type=xy[i][j];
			putimage(40+j*70,180+i*70,&an[type]);
		}
	}
}

/*ѡȡ������߸���*/
void light(int i,int j)
{
	setlinecolor(WHITE);
	int k;
	for(k=0;k<=3;k++)
	{
		rectangle(41+j*70+k,181+i*70+k,109+j*70-k,249+i*70-k);
	}
} 

/*��ը��Ч*/
void blast(int i,int j,IMAGE img)
{
	putimage(41+j*70,181+i*70,&img);
} 

/*ͨ��ʱѡ���˳�or����*/
int success(State *gp)
{
	Button exitb={550,930,640,960};
	int i,j,k;
	settextstyle(15, 0, "΢������");
	settextcolor(WHITE);
	outtextxy(10,10,"���سɹ�����ý��:");
	char s[10];
	sprintf(s,"%d",gp->level+4);
	outtextxy(160,30,s);
	setfillcolor(WHITE);
	setbkmode(TRANSPARENT);
	solidrectangle(115,95,170,120);
	Button nextlevel={115,95,170,120};
	settextcolor(BLACK);
	outtextxy(120,100,"��һ��"); 
	IMAGE success;
	loadimage(&success,_T("./resources/success.png"),360,100);
	transparentimage(140,400,success);
		
	solidrectangle(30,95,100,120);
	Button remake={30,95,100,120};
	outtextxy(35,100,"���¿�ʼ"); 
	
	MOUSEMSG m;
	while(1)
	{
		m=GetMouseMsg();
		if(m.uMsg==WM_LBUTTONDOWN)
		{
			i=judgebut(m,nextlevel);
			j=judgebut(m,remake);
			k=judgebut(m,exitb);
			if(i==1)
			{
				return 1;
				break;
			}
			if(j==1)
			{
				gp->level=0;
				gp->coin=0;
				gp->steps=15;
				return 1;
				break;
			}
			if(k==1)
			{
				return 0;
				break;
			}
		}
	}
}

/*����ʧ��*/
int fail(State *gp)
{
	Button exitb={550,930,640,960};
	int i,j;
	settextstyle(15, 0, "΢������");
	settextcolor(WHITE);
	outtextxy(10,10,"����ʧ�ܣ��ź��볡");
	IMAGE fail;
	loadimage(&fail,_T("./resources/fail.png"),360,100);
	transparentimage(140,400,fail);
	settextcolor(BLACK);
	setfillcolor(WHITE);
	setbkmode(TRANSPARENT);
	solidrectangle(30,95,100,120);
	Button remake={30,95,100,120};
	outtextxy(35,100,"���¿�ʼ");
	
	MOUSEMSG m;
	while(1)
	{
		m=GetMouseMsg();
		if(m.uMsg==WM_LBUTTONDOWN)
		{
			i=judgebut(m,remake);
			j=judgebut(m,exitb);
			if(i==1)
			{
				gp->level=0;
				gp->coin=0;
				gp->steps=15;
				return 1;
				break;
			}
			if(j==1)
			{
				return 0;
				break;
			}
		}
	}
} 
