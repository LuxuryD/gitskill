#include "game.h" 


int main()
{
	/*�����漰ͼ����ʾ����*/
	initgraph(640,960,EW_NOCLOSE);//������չʾ 
	IMAGE backg,start,gamebg,scorepl;
	loadimage(&backg,_T("./resources/backg.png"),640,960);
	putimage(0,0,&backg);
	loadimage(&start,_T("./resources/startbut.png"),320,120);
	loadimage(&gamebg,_T("./resources/bg.png"),640,960);
	transparentimage(160,600,start);
	
	MOUSEMSG m;//�����ʼ��Ϸ 
	while (1) {
		m = GetMouseMsg();
		if (m.x >= 160 && m.x <= 480 && m.y >= 600 && m.y <= 720)
		{
			if (m.uMsg == WM_LBUTTONDOWN)//�������������ʵ����Ӧ����.
			{
				cleardevice();
				putimage(0,0,&gamebg);
				break;
			}
		}
	}
	
	loadimage(&scorepl,_T("./resources/scoreplate.jpg"),210,150);
	putimage(0,0,&scorepl);
	setfillcolor(BLACK);
    solidrectangle(10, 10, 200, 140);
    IMAGE an[7];//С����ͼƬ 
	loadimage(&an[0],_T("./animals/chick.png"),70,70); 
	loadimage(&an[1],_T("./animals/chicken.png"),70,70); 
	loadimage(&an[2],_T("./animals/duck.png"),70,70); 
	loadimage(&an[3],_T("./animals/gorilla.png"),70,70); 
	loadimage(&an[4],_T("./animals/owl.png"),70,70); 
	loadimage(&an[5],_T("./animals/parrot.png"),70,70); 
	IMAGE *anp=&an[0];
	loadimage(&an[6],_T("./resources/0.png"),69,69);
	
	IMAGE exit;
	loadimage(&exit,_T("./resources/exit.png"),90,30);
	putimage(550,930,&exit); 
    
    
    /*��Ϸ����*/
    srand((unsigned)time(NULL));
    int xy[10][8];
    
	State g={1,0,0,0,15};
	State *ptr=&g;
	viewstate(ptr);
	int play=1;
	while(play==1)
	{
		play=startlevel(ptr->level,ptr,xy,an);
		ptr->level++;
	}
	
	
	return 0;
}
