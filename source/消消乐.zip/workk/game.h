#ifndef XXL
#define XXL
#include <iostream>
#include <graphics.h>
#include <conio.h>
#include <stdio.h> 
#include <stdlib.h>
#include <windows.h>
#include <graphics.h>
#include <time.h>

typedef struct{
	int level;
	long int score;
	long int targetscore;
	int coin;
	int steps;
}State;

typedef struct{
    int x1;//��ť��Ӧ������
    int y1;
	int x2;
	int y2; 
}Button;

/*ͼ�����*/
void transparentimage(int x,int y,IMAGE img);
void viewstate(State *gp);
void clearstate();
void viewlevel(int xy[10][8],IMAGE an[6]);
void fastviewlevel(int xy[10][8],IMAGE an[7]);
void point(int q,int combo);
int success(State *gp);
int fail(State *gp);
/*��Ϸ���*/
int startlevel(int i,State *gp,int xy[10][8],IMAGE an[6]);
void generatelevel(int xy[10][8]);
int judge(int xy[10][8],IMAGE bla);
int adjudge(int xy[10][8]);
void light(int i,int j);
void blast(int i,int j,IMAGE img);
int move(int xy[10][8]);
int judgebut(MOUSEMSG m,Button b);
int jbanimal(MOUSEMSG m,int ani[2]);
void swap(int xy[10][8],int x1,int y1,int x2,int y2);
int tg(int lvl);
#endif
