#ifndef STUMODIFYPASSSELF_H
#define STUMODIFYPASSSELF_H

#include <QWidget>
#include <QPainter>
#include <QString>
namespace Ui {
class StuModifyPassSelf;
}

class StuModifyPassSelf : public QWidget
{
    Q_OBJECT

public:
    explicit StuModifyPassSelf(QWidget *parent = 0);
    ~StuModifyPassSelf();
    void iniScreen();
    void paintEvent(QPaintEvent *event);
signals:
    void backToStuScreen();
private slots:
    void on_pushButton_back_clicked();

    void on_pushButton_modifyPass_clicked();

private:
    Ui::StuModifyPassSelf *ui;
    QPixmap bg;

};

#endif // STUMODIFYPASSSELF_H
