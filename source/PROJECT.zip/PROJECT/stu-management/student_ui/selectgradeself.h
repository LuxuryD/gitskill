#ifndef SELECTGRADESELF_H
#define SELECTGRADESELF_H

#include <QWidget>
#include "QPainter"
#include <QString>

namespace Ui {
class SelectGradeSelf;
}

class SelectGradeSelf : public QWidget{
    Q_OBJECT
public:
    explicit SelectGradeSelf(QWidget *parent = 0);
    ~SelectGradeSelf();
    void initScreen();
    void paintEvent(QPaintEvent *event);
private slots:
    void on_pushButton_back_clicked();

private:

    void load_SelfMsg();
    Ui::SelectGradeSelf *ui;
    QPixmap bg;

signals:
    void backToStuScreen();
};

#endif // SELECTGRADESELF_H
