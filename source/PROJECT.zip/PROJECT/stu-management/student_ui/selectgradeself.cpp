#include "selectgradeself.h"
#include "ui_selectgradeself.h"
#include "resources/pic_res.h"
#include "globle.h"
#include "db/opt_sqlite3.h"
#include <QDebug>
#include <QMessageBox>

SelectGradeSelf::SelectGradeSelf(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SelectGradeSelf)
{
    ui->setupUi(this);
    initScreen();
    ui->lineEdit->setText("");
    ui->lineEdit_2->setText("");
    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");
    this->load_SelfMsg();
}

SelectGradeSelf::~SelectGradeSelf(){
    delete ui;
}

void SelectGradeSelf::initScreen(){
    setWindowTitle("个人成绩展示");
    setWindowIcon(QIcon(MAINPAGE_ICON));
    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);
}

void SelectGradeSelf::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void SelectGradeSelf::load_SelfMsg(){
    QString query_sql = "select * from gradetable where stid=\'"+g_login_name+"\'";
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);
    if(res.size() == 0){
        return;
    }
    ui->lineEdit->setText(QString::fromStdString(res[0][1]));
    ui->lineEdit_2->setText(QString::fromStdString(res[0][2]));
    ui->lineEdit_3->setText(QString::fromStdString(res[0][3]));
    int math = atoi(res[0][1].c_str());
    int english = atoi(res[0][2].c_str());
    int cpp = atoi(res[0][3].c_str());
    float ave = (math +english +cpp) /3.0;
    ui->lineEdit_4->setText(QString::number(ave, 'f', 1));

}

void SelectGradeSelf::on_pushButton_back_clicked(){
    emit this->backToStuScreen();
}
