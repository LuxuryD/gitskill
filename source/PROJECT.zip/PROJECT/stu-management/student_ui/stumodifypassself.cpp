#include "stumodifypassself.h"
#include "ui_stumodifypassself.h"
#include "db/opt_sqlite3.h"
#include "resources/pic_res.h"
#include "globle.h"
#include "globle.h"
#include <QDebug>
#include <QMessageBox>

StuModifyPassSelf::StuModifyPassSelf(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StuModifyPassSelf)
{
    ui->setupUi(this);
    iniScreen();
}

StuModifyPassSelf::~StuModifyPassSelf(){
    delete ui;
}

void StuModifyPassSelf::iniScreen(){
    setWindowTitle("修改密码");
    setWindowIcon(QIcon(MAINPAGE_ICON));
    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);
}
void StuModifyPassSelf::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void StuModifyPassSelf::on_pushButton_back_clicked(){
    emit this->backToStuScreen();
}

void StuModifyPassSelf::on_pushButton_modifyPass_clicked(){
    QString oldPwd = ui->lineEdit_oldPass->text();
    QString newPwd = ui->lineEdit_newPass->text();
    QString againPwd = ui->lineEdit_againPass->text();

    if(newPwd == ""){
        QMessageBox::information(this,"提示","新密码不能为空\n请重新输入");
        return;
    }
    if(newPwd != againPwd){
        QMessageBox::information(this,"注意","两次密码输入不同，请重新输入！");
        ui->lineEdit_againPass->setText("");
        return;
    }


    QString query_sql = "select spass from studentpasstable where stid=\'" + g_login_name + "\'";
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);
    QString check_Pwd = QString::fromStdString(res[0][0]);
    if(check_Pwd != oldPwd){
        QMessageBox::critical(this,"警告","初始密码输入错误！\n请重新输入！\n若忘记密码，请联系学校管理员修改");
        return;
    }

    QString modify_sql = "update studentpasstable set spass=\'";
    modify_sql.append(newPwd+"\' where stid=\'");
    modify_sql.append(g_login_name+"\'");
    g_opt_db->modify_db(modify_sql);
}

