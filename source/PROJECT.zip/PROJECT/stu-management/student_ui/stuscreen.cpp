#include "stuscreen.h"
#include "ui_stuscreen.h"
#include "resources/pic_res.h"
#include "db/opt_sqlite3.h"
#include "globle.h"
#include <QDebug>
#include <QSqlError>
#include <QSqlDatabase>
#include <QSqlQuery>
StuScreen::StuScreen(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StuScreen)
{
    ui->setupUi(this);
    initScreen();
    this->load_Stu();
}

StuScreen::~StuScreen(){
    delete ui;
}

void StuScreen::initScreen(){
    setWindowTitle("学生界面");
    setWindowIcon(QIcon(MAINPAGE_ICON));
    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);

    QString btn_style = "border :1px ;background-color: white; color:black; height:350px";

    ui->pushButton_modifyPass->setStyleSheet(btn_style);
    ui->pushButton_selectGrade->setStyleSheet(btn_style);
    ui->pushButton_selectInfo->setStyleSheet(btn_style);
    ui->pushButton_back->setStyleSheet(btn_style);

    QFont font = QFont("微软雅黑",16,QFont::Bold);
    ui->pushButton_modifyPass->setFont(font);
    ui->pushButton_selectGrade->setFont(font);
    ui->pushButton_selectInfo->setFont(font);
    ui->pushButton_back->setFont(font);

}
void StuScreen::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void StuScreen::load_Stu(){
    QString query_sql = "select sname from stutable where stid=\'" + g_login_name +"\'";
    Result res = g_opt_db->query_db(query_sql);

    QString name = QString::fromStdString(res[0][0]);

    ui->lineEdit_welcome->setStyleSheet("border :1px ; background-color: rgba(0,0,0,0);color:black");
    ui->lineEdit_welcome->setText("欢迎"+ name +"同学");
    ui->lineEdit_welcome->setFont(QFont("Timers",28,QFont::Bold));

}
//密码修改
void StuScreen::on_pushButton_modifyPass_clicked(){

    if(stumodipass == nullptr){
        stumodipass = new StuModifyPassSelf;
    }
    connect(stumodipass,&StuModifyPassSelf::backToStuScreen,[=](){ \
        stumodipass->hide(); \
        this->show();});

    this->hide();
    stumodipass->show();
}
//信息查询
void StuScreen::on_pushButton_selectInfo_clicked(){

    if(stuinfoshowself == nullptr){
        this->stuinfoshowself = new StuInfoShowSelf;
    }
    connect(stuinfoshowself,&StuInfoShowSelf::backToStuScreen,[=](){ \
        stuinfoshowself->hide(); \
        this->show();});
    this->hide();
    stuinfoshowself->show();
}
//成绩查询
void StuScreen::on_pushButton_selectGrade_clicked(){

    if(selectgradeself == nullptr){
       selectgradeself = new SelectGradeSelf;
    }
    connect(selectgradeself,&SelectGradeSelf::backToStuScreen,[=](){\
        selectgradeself->hide();\
        this->show();});
    this->hide();
    selectgradeself->show();
}


void StuScreen::on_pushButton_back_clicked(){
    emit this->backToLoginScreen();
}
