#include "stuinfoshowself.h"
#include "ui_stuinfoshowself.h"
#include "db/opt_sqlite3.h"
#include "globle.h"
#include "resources/pic_res.h"
#include <QDebug>
#include <QMessageBox>

StuInfoShowSelf::StuInfoShowSelf(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StuInfoShowSelf)
{
    ui->setupUi(this);
    iniScreen();
    this->load_Info();
    //getInformation();
}

StuInfoShowSelf::~StuInfoShowSelf(){
    delete ui;
}

void StuInfoShowSelf::iniScreen(){
    setWindowTitle("个人信息展示");
    setWindowIcon(QIcon(MAINPAGE_ICON));
    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);
}

void StuInfoShowSelf::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void StuInfoShowSelf::load_Info(){
    QString query_sql = "select sname,ssex,sage,birth_txt,smajor from stutable where stid=\'"+\
                        g_login_name+"\'";
    Result res = g_opt_db->query_db(query_sql);
    if(res.size() == 0){
        return;
    }
    ui->lineEdit_id->setText(g_login_name);
    ui->lineEdit_name->setText(QString::fromStdString(res[0][0]));
    ui->lineEdit_sex->setText(QString::fromStdString(res[0][1]));
    ui->lineEdit_age->setText(QString::fromStdString(res[0][2]));

    ui->lineEdit_place->setText(QString::fromStdString(res[0][3]));
    ui->lineEdit_major->setText(QString::fromStdString(res[0][4]));
}
void StuInfoShowSelf::on_pushButton_back_clicked(){
    emit this->backToStuScreen();
}
