#include "db/opt_sqlite3.h"
#include "globle.h"
#include <QSqlQuery>
#include <QSqlError>

Custom_Db_Opt::Custom_Db_Opt(){

    this->db = QSqlDatabase::addDatabase("QSQLITE");
    this->db.setDatabaseName(CUSTOM_DB_NAME);

    uint32_t open_nums = 5;
    for(uint32_t i=open_nums; i>0; i--){
        if(!this->db.isOpen()){
            this->db.open();
        }else {
            PRINT_STRING("数据库打开成功");
            break;
        }
    }
}

Custom_Db_Opt::~Custom_Db_Opt(){
    PRINT_STRING("析构");
    this->db.close();
}

void Custom_Db_Opt::close_db(){
    this->db.close();
}

bool Custom_Db_Opt::modify_db(const QString sql){
    bool re = false;
    QSqlQuery query(this->db);
    if(!query.exec(sql)){
        PRINT_STRING("修改失败");
        qDebug() << query.lastError();
        re = false;
    }else {
        PRINT_STRING("修改数据库成功！");
        re = true;
    }
    query.clear();
    query.finish();

    return re;
}

Result Custom_Db_Opt::query_db(const QString sql){
    Result res;
    QSqlQuery query(this->db);
    if(query.exec(sql)){
        PRINT_STRING("查询数据库成功！");
    }else {
        PRINT_STRING("查询失败");
        qDebug() << query.lastError();
    }
    //query.exec(sql);
    while(query.next()){
        std::vector<std::string> row;
        for(int i=0; query.value(i).isValid(); i++){
           row.push_back(query.value(i).toString().toStdString());
        }
        res.push_back(row);
    }
    query.clear();
    query.finish();
    return res;
}
Custom_Db_Opt* g_opt_db = nullptr;


