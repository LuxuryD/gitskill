#ifndef __OPT_SQLITE3__
#define __OPT_SQLITE3__
#include <QSqlDatabase>
#include <vector>

//#define CUSTOM_DB_NAME    "./custom_db"
#define CUSTOM_DB_NAME    "F:/Users/feivy/Desktop/PROJECT/stu-management/custom2.db"
typedef std::vector<std::vector<std::string>> Result;
class Custom_Db_Opt{
public:
    Custom_Db_Opt();
    ~Custom_Db_Opt();

    bool modify_db(const QString);
    Result query_db(const QString);
    QSqlDatabase db;

private:

    void close_db();



};
extern Custom_Db_Opt* g_opt_db;

#endif
