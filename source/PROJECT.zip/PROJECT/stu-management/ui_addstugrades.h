/********************************************************************************
** Form generated from reading UI file 'addstugrades.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDSTUGRADES_H
#define UI_ADDSTUGRADES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddStuGrades
{
public:
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QLineEdit *lineEdit_stid;
    QLineEdit *lineEdit_math;
    QLineEdit *lineEdit_english;
    QLineEdit *lineEdit_c;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton_back;
    QPushButton *pushButton_submit;

    void setupUi(QWidget *AddStuGrades)
    {
        if (AddStuGrades->objectName().isEmpty())
            AddStuGrades->setObjectName(QString::fromUtf8("AddStuGrades"));
        AddStuGrades->resize(800, 600);
        widget_3 = new QWidget(AddStuGrades);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        widget_3->setGeometry(QRect(236, 148, 289, 171));
        horizontalLayout = new QHBoxLayout(widget_3);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        widget_2 = new QWidget(widget_3);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        verticalLayout_2 = new QVBoxLayout(widget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_2->addWidget(label);

        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        label_3 = new QLabel(widget_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_2->addWidget(label_3);

        label_4 = new QLabel(widget_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_2->addWidget(label_4);


        horizontalLayout->addWidget(widget_2);

        widget = new QWidget(widget_3);
        widget->setObjectName(QString::fromUtf8("widget"));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        lineEdit_stid = new QLineEdit(widget);
        lineEdit_stid->setObjectName(QString::fromUtf8("lineEdit_stid"));

        verticalLayout->addWidget(lineEdit_stid);

        lineEdit_math = new QLineEdit(widget);
        lineEdit_math->setObjectName(QString::fromUtf8("lineEdit_math"));

        verticalLayout->addWidget(lineEdit_math);

        lineEdit_english = new QLineEdit(widget);
        lineEdit_english->setObjectName(QString::fromUtf8("lineEdit_english"));

        verticalLayout->addWidget(lineEdit_english);

        lineEdit_c = new QLineEdit(widget);
        lineEdit_c->setObjectName(QString::fromUtf8("lineEdit_c"));

        verticalLayout->addWidget(lineEdit_c);


        horizontalLayout->addWidget(widget);

        widget_4 = new QWidget(AddStuGrades);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        widget_4->setGeometry(QRect(260, 330, 251, 50));
        horizontalLayout_2 = new QHBoxLayout(widget_4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        pushButton_back = new QPushButton(widget_4);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));

        horizontalLayout_2->addWidget(pushButton_back);

        pushButton_submit = new QPushButton(widget_4);
        pushButton_submit->setObjectName(QString::fromUtf8("pushButton_submit"));

        horizontalLayout_2->addWidget(pushButton_submit);


        retranslateUi(AddStuGrades);

        QMetaObject::connectSlotsByName(AddStuGrades);
    } // setupUi

    void retranslateUi(QWidget *AddStuGrades)
    {
        AddStuGrades->setWindowTitle(QCoreApplication::translate("AddStuGrades", "Form", nullptr));
        label->setText(QCoreApplication::translate("AddStuGrades", "\345\255\246\345\217\267\357\274\232", nullptr));
        label_2->setText(QCoreApplication::translate("AddStuGrades", "\346\225\260\345\255\246\357\274\232", nullptr));
        label_3->setText(QCoreApplication::translate("AddStuGrades", "\350\213\261\350\257\255\357\274\232", nullptr));
        label_4->setText(QCoreApplication::translate("AddStuGrades", "C++:", nullptr));
        pushButton_back->setText(QCoreApplication::translate("AddStuGrades", "\350\277\224\345\233\236", nullptr));
        pushButton_submit->setText(QCoreApplication::translate("AddStuGrades", "\346\217\220\344\272\244", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddStuGrades: public Ui_AddStuGrades {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDSTUGRADES_H
