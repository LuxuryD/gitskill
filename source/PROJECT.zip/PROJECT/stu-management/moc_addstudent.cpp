/****************************************************************************
** Meta object code from reading C++ file 'addstudent.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "admin_ui/addstudent.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'addstudent.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_AddStudent_t {
    QByteArrayData data[12];
    char stringdata0[253];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AddStudent_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AddStudent_t qt_meta_stringdata_AddStudent = {
    {
QT_MOC_LITERAL(0, 0, 10), // "AddStudent"
QT_MOC_LITERAL(1, 11, 17), // "backToAdminScreen"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 18), // "backToAllStuScreen"
QT_MOC_LITERAL(4, 49, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(5, 73, 28), // "on_pushButton_submit_clicked"
QT_MOC_LITERAL(6, 102, 30), // "on_comboBox_province_activated"
QT_MOC_LITERAL(7, 133, 5), // "index"
QT_MOC_LITERAL(8, 139, 26), // "on_comboBox_city_activated"
QT_MOC_LITERAL(9, 166, 28), // "on_comboBox_county_activated"
QT_MOC_LITERAL(10, 195, 29), // "on_comboBox_college_activated"
QT_MOC_LITERAL(11, 225, 27) // "on_comboBox_major_activated"

    },
    "AddStudent\0backToAdminScreen\0\0"
    "backToAllStuScreen\0on_pushButton_2_clicked\0"
    "on_pushButton_submit_clicked\0"
    "on_comboBox_province_activated\0index\0"
    "on_comboBox_city_activated\0"
    "on_comboBox_county_activated\0"
    "on_comboBox_college_activated\0"
    "on_comboBox_major_activated"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AddStudent[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   59,    2, 0x06 /* Public */,
       3,    0,   60,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   61,    2, 0x08 /* Private */,
       5,    0,   62,    2, 0x08 /* Private */,
       6,    1,   63,    2, 0x08 /* Private */,
       8,    1,   66,    2, 0x08 /* Private */,
       9,    1,   69,    2, 0x08 /* Private */,
      10,    1,   72,    2, 0x08 /* Private */,
      11,    1,   75,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,

       0        // eod
};

void AddStudent::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<AddStudent *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->backToAdminScreen(); break;
        case 1: _t->backToAllStuScreen(); break;
        case 2: _t->on_pushButton_2_clicked(); break;
        case 3: _t->on_pushButton_submit_clicked(); break;
        case 4: _t->on_comboBox_province_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_comboBox_city_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_comboBox_county_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_comboBox_college_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_comboBox_major_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (AddStudent::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AddStudent::backToAdminScreen)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (AddStudent::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AddStudent::backToAllStuScreen)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject AddStudent::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_AddStudent.data,
    qt_meta_data_AddStudent,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *AddStudent::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AddStudent::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_AddStudent.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int AddStudent::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void AddStudent::backToAdminScreen()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void AddStudent::backToAllStuScreen()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
