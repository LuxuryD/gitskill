#include "addstudent.h"
#include "ui_addstudent.h"
#include "resources/pic_res.h"
#include "db/opt_sqlite3.h"
#include <QDebug>
#include <QMessageBox>

AddStudent::AddStudent(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddStudent){

    ui->setupUi(this);
    initScreen();

    this->load_province_msg();
}

AddStudent::~AddStudent(){
    delete ui;
}

void AddStudent::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void AddStudent::initScreen(){
    setWindowIcon(QIcon(MAINPAGE_ICON));
    setWindowTitle("添加学生信息");
    this->setFixedSize(width(), height());

    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);

    ui->comboBox_province->setCurrentIndex(-1);
    ui->comboBox_college->setCurrentIndex(-1);
    ui->comboBox_college->setCurrentIndex(-1);

    ui->radioButton_man->setAutoExclusive(true);
    ui->radioButton_woman->setAutoExclusive(true);
}

void AddStudent::on_pushButton_2_clicked(){
    if(this->addStu_Back_Page == ADDSTU_BACK_PAGE_ADMIN){
        emit this->backToAdminScreen();
    }else if(this->addStu_Back_Page == ADDSTU_BACK_PAGE_ALLSTU){
        emit this->backToAllStuScreen();
    }
}

bool AddStudent::check_stu_id(){

    QString query_sql = "select * from stutable where stid=\'";
    query_sql.append(ui->lineEdit_id->text() + "\'");
    Result res = g_opt_db->query_db(query_sql);
    if(res.size() == 0){
        return true;
    }
    return false;
}
void AddStudent::on_pushButton_submit_clicked(){
    if(!check_stu_id()){
        QMessageBox::critical(this,"警告","该学号已存在!");
        return;
    }

    QString insert_pwd_sql = "insert into studentpasstable(stid, spass) values (\'";

    insert_pwd_sql.append(ui->lineEdit_id->text()+"\' ,");
    insert_pwd_sql.append("\'"+ui->lineEdit_pass->text()+"\')");
    g_opt_db->modify_db(insert_pwd_sql);

    QString insert_msg_sql = "insert into stutable(stid,sname,ssex,sage,splace,smajor,birth_txt) values (\'";
    insert_msg_sql.append(ui->lineEdit_id->text()+"\', ");
    insert_msg_sql.append("\'"+ui->lineEdit_name->text()+"\', ");
    if(ui->radioButton_man->isChecked()){
        insert_msg_sql.append("\'男\', ");
    }else {
        insert_msg_sql.append("\'女\', ");
    }
    insert_msg_sql.append("\'"+ui->lineEdit_age->text()+"\',");

    QString place_code = "";
    place_code.append(QString::number(stu_birth_msg.province) + ", ");
    place_code.append(QString::number(stu_birth_msg.city) + ", ");
    place_code.append(QString::number(stu_birth_msg.area));

    QString place_msg = "";
    place_msg.append(ui->comboBox_province->currentText());
    place_msg.append(ui->comboBox_city->currentText());
    place_msg.append(ui->comboBox_county->currentText());

    QString campus_msg = "";
    campus_msg.append(ui->comboBox_college->currentText());
    campus_msg.append(ui->comboBox_major->currentText());
    campus_msg.append(ui->comboBox_class->currentText());

    insert_msg_sql.append("\'"+place_code+"\', ");
    insert_msg_sql.append("\'"+campus_msg+"\', ");
    insert_msg_sql.append("\'"+place_msg+"\')");

    qDebug() << insert_msg_sql;

    g_opt_db->modify_db(insert_msg_sql);

    //添加成绩到对应表单
    QString insert_grade = "insert into gradetable(stid,grademath,gradeen,gradec) values (\'";
    insert_grade.append(ui->lineEdit_id->text()+"\',\'\',\'\',\'\')");
    qDebug() << insert_grade;
    g_opt_db->modify_db(insert_grade);

}


void AddStudent::load_province_msg(){
    QString query_sql = "select * from province_tb";
    Result res = g_opt_db->query_db(query_sql);
    if(res.size() == 0){
        return;
    }
    for(uint32_t i=0; i<res.size(); i++){
        uint32_t code = atoi(res[i][0].c_str());
        std::string name = res[i][1];
        combo_province_map.insert(i, code);
        ui->comboBox_province->insertItem(i, QString::fromStdString(res[i][1]));
    }
    ui->comboBox_province->setCurrentIndex(-1);
}

void AddStudent::load_city_msg(uint32_t province_id){
    QString query_sql = "select code, name from city_tb where provinceCode=\'";
    query_sql.append(QString::number(province_id) + "\'");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);

    ui->comboBox_city->clear();
    ui->comboBox_county->clear();
    combo_city_map.clear();
    if(res.size() == 0){
        return;
    }
    for(uint32_t i=0; i<res.size(); i++){
        uint32_t city_code = atoi(res[i][0].c_str());
        std::string name = res[i][1];
        combo_city_map.insert(i, city_code);
        ui->comboBox_city->insertItem(i, QString::fromStdString(res[i][1]));
    }
}


void AddStudent::load_area_msg(uint32_t province_id, uint32_t city_id){
    QString query_sql = "select code, name from area_tb where cityCode=\'";
    query_sql.append(QString::number(city_id) + "\' and provinceCode=\'");
    query_sql.append(QString::number(province_id) + "\'");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);

    ui->comboBox_county->clear();
    combo_area_map.clear();

    if(res.size() == 0){
        return;
    }
    for(uint32_t i=0; i<res.size(); i++){
        uint32_t area_code = atoi(res[i][0].c_str());
        std::string name = res[i][1];
        combo_area_map.insert(i, area_code);
        ui->comboBox_county->insertItem(i, QString::fromStdString(res[i][1]));
    }
}
void AddStudent::on_comboBox_province_activated(int index){
    Q_UNUSED(index);
    uint32_t province_code = combo_province_map[ui->comboBox_province->currentIndex()];
    this->load_city_msg(province_code);
    stu_birth_msg.province = province_code;
}

void AddStudent::on_comboBox_city_activated(int index){
    Q_UNUSED(index);
    uint32_t province_code = combo_province_map[ui->comboBox_province->currentIndex()];
    uint32_t city_code = combo_city_map[ui->comboBox_city->currentIndex()];
    this->load_area_msg(province_code, city_code);
    stu_birth_msg.city = city_code;
}


void AddStudent::on_comboBox_county_activated(int index){
    Q_UNUSED(index);
    uint32_t area_code = combo_area_map[ui->comboBox_county->currentIndex()];
    stu_birth_msg.area = area_code;
}


void AddStudent::on_comboBox_college_activated(int index){
    Q_UNUSED(index);
    QString query_sql = "select major from campus_tb where college=\'";
    query_sql.append(ui->comboBox_college->currentText() + "\' group by major");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);

    uint32_t college_nums = res.size();
    ui->comboBox_major->clear();
    for(uint32_t i=0; i<college_nums; i++){
        ui->comboBox_major->insertItem(i, QString::fromStdString(res[i][0]));
    }
}


void AddStudent::on_comboBox_major_activated(int index){
    Q_UNUSED(index);
    QString query_sql = "select class from campus_tb where major=\'";
    query_sql.append(ui->comboBox_major->currentText() + "\' group by class");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);

    uint32_t class_nums = res.size();
    ui->comboBox_class->clear();
    for(uint32_t i=0; i<class_nums; i++){
        ui->comboBox_class->insertItem(i, QString::fromStdString(res[i][0]));
    }
}


