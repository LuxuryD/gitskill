#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlDatabase>
#include <QSqlQuery>
#include "modifystupass.h"
#include "ui_modifystupass.h"
#include "resources/pic_res.h"
#include "db/opt_sqlite3.h"

ModifyStuPass::ModifyStuPass(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ModifyStuPass)
{
    ui->setupUi(this);
    initScreen();
}

ModifyStuPass::~ModifyStuPass(){
    delete ui;
}

void ModifyStuPass::initScreen(){
    setWindowIcon(QIcon(MAINPAGE_ICON));
    setWindowTitle("修改学生密码");
    this->setFixedSize(width(), height());

    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);
}

void ModifyStuPass::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);

    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}
void ModifyStuPass::on_pushButton_back_clicked(){
    emit this->backToadminScreen();
}

void ModifyStuPass::on_pushButton_submit_clicked(){
    QString first_id = ui->lineEdit_newPass->text();
    QString second_id = ui->lineEdit_againPass->text();
    int tmp = QString::compare(first_id, second_id);
    if(tmp != 0){
        QMessageBox::critical(this,"提示","两次密码输入不同！\n请重新输入。");
        return;
    }
    QString modify_sql = "update studentpasstable set spass =\'";
    modify_sql.append(ui->lineEdit_newPass->text()+"\'");
    modify_sql.append(" where stid=\'");
    modify_sql.append(ui->lineEdit_stuid->text()+"\'");
    g_opt_db->modify_db(modify_sql);
}

void ModifyStuPass::on_lineEdit_stuid_editingFinished(){

    QString query_sql = "select sname from stutable where stid=\'";
    query_sql.append(ui->lineEdit_stuid->text() + "\'");
    Result res = g_opt_db->query_db(query_sql);
    if(res.size() == 0){
        QMessageBox::information(this,"提示","无此学生\n请检查学号是否正确\n请重新输入");
        ui->lineEdit_stuid->setText("");
        ui->lineEdit_sname->setText("");
    }else {
        ui->lineEdit_sname->setText(QString::fromStdString(res[0][0]));
    }
}
