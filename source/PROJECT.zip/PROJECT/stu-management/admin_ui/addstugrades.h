#ifndef ADDSTUGRADES_H
#define ADDSTUGRADES_H

#include <QWidget>
#include <QPainter>
#include <QString>
namespace Ui {
class AddStuGrades;
}

class AddStuGrades : public QWidget
{
    Q_OBJECT

public:
    explicit AddStuGrades(QWidget *parent = 0);
    ~AddStuGrades();
    void initScreen();
    void paintEvent(QPaintEvent *event);

private slots:
    void on_pushButton_back_clicked();
    void on_pushButton_submit_clicked();

signals:
    void backToAllGradesScreen();

private:
    Ui::AddStuGrades *ui;
    QPixmap bg;
};

#endif // ADDSTUGRADES_H
