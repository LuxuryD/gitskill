#include "allstuinfo.h"
#include "ui_allstuinfo.h"
#include "resources/pic_res.h"
#include "db/opt_sqlite3.h"
#include <QDebug>
#include <QMessageBox>
#include <QTableView>
#include <QHeaderView>

AllStuInfo::AllStuInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AllStuInfo)
{
    ui->setupUi(this);
    initScreen();
    //studentInfoView();
    this->loadModel();

}

AllStuInfo::~AllStuInfo(){
    delete ui;
}

void AllStuInfo::initScreen(){
    setWindowIcon(QIcon(MAINPAGE_ICON));
    setWindowTitle("学生信息展示");
    this->setFixedSize(width(), height());

    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);

    ui->widget_btn->setStyleSheet("border:0px; background-color: rgba(0,0,0,50);");

    this->btn_style = "height:40px; width: 80px; font-size:14pt; background-color:white";
    ui->pushButton_add->setStyleSheet(this->btn_style);
    ui->pushButton_asc->setStyleSheet(this->btn_style);
    ui->pushButton_back->setStyleSheet(this->btn_style);
    ui->pushButton_delete->setStyleSheet(this->btn_style);
    ui->pushButton_desc->setStyleSheet(this->btn_style);

}

void AllStuInfo::loadModel(){
    model = new QSqlTableModel(this, g_opt_db->db);
    model->setTable("stutable");
    model->setHeaderData(0,Qt::Horizontal,QVariant("学号"));
    model->setHeaderData(1,Qt::Horizontal,QVariant("姓名"));
    model->setHeaderData(2,Qt::Horizontal,QVariant("性别"));
    model->setHeaderData(3,Qt::Horizontal,QVariant("年龄"));
    model->setHeaderData(6,Qt::Horizontal,QVariant("籍贯"));
    model->setHeaderData(5,Qt::Horizontal,QVariant("专业"));
    model->setEditStrategy(QSqlTableModel::OnManualSubmit); //修改模式All changes will be cached in the model until either submitAll() or revertAll() is called.
    model->select();

    ui->tableView->setModel(model);

    ui->tableView->setColumnWidth(0,80);
    ui->tableView->setColumnWidth(1,80);
    ui->tableView->setColumnWidth(2,50);
    ui->tableView->setColumnWidth(3,50);
    ui->tableView->setColumnWidth(4, 0);
    ui->tableView->setColumnWidth(5,200);
    ui->tableView->setColumnWidth(6,300);

    QString tableView_Style = "QTableView QHeaderView::section { min-height: 40px; }";
    QString headerView_Style = "QHeaderView::section { background-color: white;}";

    ui->tableView->setStyleSheet(tableView_Style);
    ui->tableView->verticalHeader()->setStyleSheet(headerView_Style);
    ui->tableView->horizontalHeader()->setStyleSheet(headerView_Style);
}

void AllStuInfo::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}


void AllStuInfo::reshow_table(){
    this->addStu_Page->hide();
    model->select();
    this->show();
}
//新增
void AllStuInfo::on_pushButton_add_clicked(){
    if(this->addStu_Page == nullptr){
        this->addStu_Page = new AddStudent();
    }
    connect(addStu_Page,&AddStudent::backToAllStuScreen,this, &AllStuInfo::reshow_table);
    this->addStu_Page->addStu_Back_Page = ADDSTU_BACK_PAGE_ALLSTU;
    this->hide();
    this->addStu_Page->show();
}

//删除
void AllStuInfo::on_pushButton_delete_clicked(){
    int current_row = ui->tableView->currentIndex().row();
    int need_del = QMessageBox::question(this,"提示","是否要删除此学生信息\n删除后数据无法恢复，请慎重考虑!", \
                                         QMessageBox::Yes | QMessageBox::No,QMessageBox::Yes);
    if(need_del == QMessageBox::Yes){
        model->removeRow(current_row);
        model->submitAll();
    }
}

//升序
void AllStuInfo::on_pushButton_asc_clicked(){
    model->sort(0, Qt::AscendingOrder);
}
//降序
void AllStuInfo::on_pushButton_desc_clicked(){
    model->sort(0, Qt::DescendingOrder);
}
//返回
void AllStuInfo::on_pushButton_back_clicked(){
    emit this->backToAdminScreen();
}
