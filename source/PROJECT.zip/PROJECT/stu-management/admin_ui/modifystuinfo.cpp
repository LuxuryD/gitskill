#include "modifystuinfo.h"
#include "ui_modifystuinfo.h"
#include "resources/pic_res.h"
#include "db/opt_sqlite3.h"
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlDatabase>
#include <QSqlQuery>


ModifyStuInfo::ModifyStuInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ModifyStuInfo)
{
    ui->setupUi(this);
    initScreen();

    this->load_province_msg();
}

ModifyStuInfo::~ModifyStuInfo()
{
    delete ui;
}

void ModifyStuInfo::initScreen()
{
    setWindowIcon(QIcon(MAINPAGE_ICON));
    setWindowTitle("修改学生信息");
    this->setFixedSize(width(), height());

    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);

    ui->radioButton_man->setAutoExclusive(true);
    ui->radioButton_woman->setAutoExclusive(true);

    ui->comboBox_province->setCurrentIndex(-1);
    ui->comboBox_city->setCurrentIndex(-1);
    ui->comboBox_county->setCurrentIndex(-1);
    ui->lineEdit_showPlace->setText("");

    ui->comboBox_college->setCurrentIndex(-1);
    ui->comboBox_major->setCurrentIndex(-1);
    ui->comboBox_class->setCurrentIndex(-1);
    ui->lineEdit_showMajor->setText("");
}

void ModifyStuInfo::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}


void ModifyStuInfo::on_pushButton_back_clicked()
{
    emit this->backToAdminScreen();
}



//查询学生信息（学号）
void ModifyStuInfo::on_pushButton_select_clicked(){
    QString query_sql = "select * from stutable where stid=\'";
    query_sql.append(ui->lineEdit_sid->text() + "\'");
    Result res = g_opt_db->query_db(query_sql);
    if(res.size() == 0){
        QMessageBox::information(this,"提示","无此学生.\n请重新输入!");
        this->can_be_modified = false;
    }else {

        ui->lineEdit_age->setText(QString::fromStdString(res[0][3]));
        ui->lineEdit_name->setText(QString::fromStdString(res[0][1]));
        if(res[0][2] == "男"){
            ui->radioButton_man->setChecked(true);
            ui->radioButton_woman->setChecked(false);
        }else {
            ui->radioButton_man->setChecked(false);
            ui->radioButton_woman->setChecked(true);
        }
        ui->lineEdit_showMajor->setText(QString::fromStdString(res[0][5]));
        ui->lineEdit_showPlace->setText(QString::fromStdString(res[0][6]));
        //ui->lineEdit_showPlace->setText(QString::fromStdString(res[0][4]));
        this->can_be_modified = true;

        ui->comboBox_college->setCurrentIndex(-1);
        ui->comboBox_major->setCurrentIndex(-1);
        ui->comboBox_class->setCurrentIndex(-1);

        QStringList qsl = QString::fromStdString(res[0][4]).split(", ");
        if(qsl.size() < 3){
            ui->comboBox_province->setCurrentIndex(-1);
            ui->comboBox_city->setCurrentIndex(-1);
            ui->comboBox_county->setCurrentIndex(-1);
            ui->lineEdit_showPlace->setText("");
            return;
        }
        uint32_t province_code =  qsl.at(0).toUInt();
        uint32_t city_code = qsl.at(1).toUInt();
        uint32_t area_code = qsl.at(2).toUInt();

        ui->comboBox_province->setCurrentIndex(province_combo_map[province_code]);
        this->load_city_msg(province_code);
        ui->comboBox_city->setCurrentIndex(city_combo_map[city_code]);
        this->load_area_msg(province_code, city_code);
        ui->comboBox_county->setCurrentIndex(area_combo_map[area_code]);
    }
}


void ModifyStuInfo::on_pushButton_clicked(){
    //setInformation();
    if(!this->can_be_modified){
        QMessageBox::information(this,"提示","无此学生.");
        return;
    }
    QString modify_sql = "update stutable set sname=\'";
    modify_sql.append(ui->lineEdit_name->text()+"\', ");
    QString sex = ui->radioButton_man->isChecked() ? "男" : "女";
    modify_sql.append("ssex=\'"+sex+"\', ");
    modify_sql.append("sage=\'"+ui->lineEdit_age->text()+"\', ");

    QString stu_place = "";
    stu_place.append(QString::number(stu_birth_msg.province) +", ");
    stu_place.append(QString::number(stu_birth_msg.city) +", ");
    stu_place.append(QString::number(stu_birth_msg.area));
    modify_sql.append("splace=\'" + stu_place +"\',");
    modify_sql.append("smajor=\'" +ui->lineEdit_showMajor->text()+"\', ");
    modify_sql.append("birth_txt=\'"+ ui->lineEdit_showPlace->text()+"\' ");
    modify_sql.append("where stid=\'" +ui->lineEdit_sid->text()+ "\';");
    qDebug() << modify_sql;
    g_opt_db->modify_db(modify_sql);

}
//选择学院
void ModifyStuInfo::on_comboBox_college_activated(int index){
    Q_UNUSED(index);
    QString query_sql = "select major from campus_tb where college=\'";
    query_sql.append(ui->comboBox_college->currentText() + "\' group by major");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);

    uint32_t college_nums = res.size();
    ui->comboBox_major->clear();
    for(uint32_t i=0; i<college_nums; i++){
        ui->comboBox_major->insertItem(i, QString::fromStdString(res[i][0]));
    }
    ui->lineEdit_showMajor->setText(ui->comboBox_college->currentText());
}
//选择专业
void ModifyStuInfo::on_comboBox_major_activated(int index){
    Q_UNUSED(index);
    QString query_sql = "select class from campus_tb where major=\'";
    query_sql.append(ui->comboBox_major->currentText() + "\' group by class");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);

    uint32_t class_nums = res.size();
    ui->comboBox_class->clear();
    for(uint32_t i=0; i<class_nums; i++){
        ui->comboBox_class->insertItem(i, QString::fromStdString(res[i][0]));
    }

    QString show_txt = "";
    show_txt.append(ui->comboBox_college->currentText());
    show_txt.append(ui->comboBox_major->currentText());
    ui->lineEdit_showMajor->setText(show_txt);

}
//选择班级
void ModifyStuInfo::on_comboBox_class_activated(int index){
    Q_UNUSED(index);
    QString show_txt = "";
    show_txt.append(ui->comboBox_college->currentText());
    show_txt.append(ui->comboBox_major->currentText());
    show_txt.append(ui->comboBox_class->currentText());
    ui->lineEdit_showMajor->setText(show_txt);
}

/********************************************/

void ModifyStuInfo::load_province_msg(){
    QString query_sql = "select * from province_tb";
    Result res = g_opt_db->query_db(query_sql);

    if(res.size() == 0){
        return;
    }
    for(uint32_t i=0; i<res.size(); i++){
        uint32_t code = atoi(res[i][0].c_str());
        std::string name = res[i][1];
        province_combo_map.insert(code, i);
        combo_province_map.insert(i, code);
        ui->comboBox_province->insertItem(i, QString::fromStdString(res[i][1]));
    }
    ui->comboBox_province->setCurrentIndex(-1);
}

void ModifyStuInfo::load_city_msg(uint32_t province_id){
    QString query_sql = "select code, name from city_tb where provinceCode=\'";
    query_sql.append(QString::number(province_id) + "\'");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);

    ui->comboBox_city->clear();
    ui->comboBox_county->clear();
    combo_city_map.clear();
    city_combo_map.clear();
    if(res.size() == 0){
        return;
    }
    for(uint32_t i=0; i<res.size(); i++){
        uint32_t city_code = atoi(res[i][0].c_str());
        std::string name = res[i][1];
        city_combo_map.insert(city_code, i);
        combo_city_map.insert(i, city_code);
        ui->comboBox_city->insertItem(i, QString::fromStdString(res[i][1]));
    }
}
void ModifyStuInfo::load_area_msg(uint32_t province_id, uint32_t city_id){
    QString query_sql = "select code, name from area_tb where cityCode=\'";
    query_sql.append(QString::number(city_id) + "\' and provinceCode=\'");
    query_sql.append(QString::number(province_id) + "\'");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);

    ui->comboBox_county->clear();
    combo_area_map.clear();
    area_combo_map.clear();
    if(res.size() == 0){
        return;
    }
    for(uint32_t i=0; i<res.size(); i++){
        uint32_t area_code = atoi(res[i][0].c_str());
        std::string name = res[i][1];
        area_combo_map.insert(area_code, i);
        combo_area_map.insert(i, area_code);
        ui->comboBox_county->insertItem(i, QString::fromStdString(res[i][1]));
    }
}


//选择省份
void ModifyStuInfo::on_comboBox_province_activated(int index){
    Q_UNUSED(index);

    uint32_t province_code = combo_province_map[ui->comboBox_province->currentIndex()];

    this->load_city_msg(province_code);
    ui->lineEdit_showPlace->setText(ui->comboBox_province->currentText());

    stu_birth_msg.province = province_code;
}

//选择城市
void ModifyStuInfo::on_comboBox_city_activated(int index){
    Q_UNUSED(index);

    uint32_t province_code = combo_province_map[ui->comboBox_province->currentIndex()];
    uint32_t city_code = combo_city_map[ui->comboBox_city->currentIndex()];

    this->load_area_msg(province_code, city_code);
    QString show_txt = "";
    show_txt.append(ui->comboBox_province->currentText());
    show_txt.append(ui->comboBox_city->currentText());
    ui->lineEdit_showPlace->setText(show_txt);

    stu_birth_msg.city = city_code;
}
//选择区
void ModifyStuInfo::on_comboBox_county_activated(int index){
    Q_UNUSED(index);
    QString show_txt = "";
    show_txt.append(ui->comboBox_province->currentText());
    show_txt.append(ui->comboBox_city->currentText());
    show_txt.append(ui->comboBox_county->currentText());
    ui->lineEdit_showPlace->setText(show_txt);

    stu_birth_msg.area = combo_area_map[ui->comboBox_county->currentIndex()];
}




