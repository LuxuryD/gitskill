#ifndef MODIFYSTUINFO_H
#define MODIFYSTUINFO_H

#include <QWidget>
#include "globle.h"
#include <QPainter>
#include <QString>
namespace Ui {
class ModifyStuInfo;
}

class ModifyStuInfo : public QWidget
{
    Q_OBJECT

public:
    explicit ModifyStuInfo(QWidget *parent = 0);
    ~ModifyStuInfo();
    void initScreen();
    void paintEvent(QPaintEvent *event);
    void getInfoAndShow();
    //void setInformation();
signals:
    void backToAdminScreen();
private slots:
    void on_pushButton_back_clicked();

    void on_comboBox_province_activated(int index);

    void on_pushButton_select_clicked();

    void on_comboBox_county_activated(int index);

    void on_pushButton_clicked();

    void on_comboBox_major_activated(int index);

    void on_comboBox_class_activated(int index);

    void on_comboBox_city_activated(int index);

    void on_comboBox_college_activated(int index);

private:
    Ui::ModifyStuInfo *ui;
    QPixmap bg;
    bool can_be_modified = false;

    void load_province_msg();
    void load_city_msg(uint32_t);
    void load_area_msg(uint32_t, uint32_t);
    QMap<uint32_t, uint32_t> combo_province_map;
    QMap<uint32_t, uint32_t> province_combo_map;

    QMap<uint32_t, uint32_t> combo_city_map;
    QMap<uint32_t, uint32_t> city_combo_map;

    QMap<uint32_t, uint32_t> combo_area_map;
    QMap<uint32_t, uint32_t> area_combo_map;

    struct {
        uint32_t province;
        uint32_t city;
        uint32_t area;
    }stu_birth_msg;
};

#endif // MODIFYSTUINFO_H
