#include "addstugrades.h"
#include "ui_addstugrades.h"
#include "resources/pic_res.h"
#include "db/opt_sqlite3.h"
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlDatabase>
#include <QSqlQuery>
AddStuGrades::AddStuGrades(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddStuGrades)
{
    ui->setupUi(this);
    initScreen();

}

AddStuGrades::~AddStuGrades(){
    delete ui;
}

void AddStuGrades::initScreen(){
    setWindowIcon(QIcon(MAINPAGE_ICON));
    setWindowTitle("添加学生成绩");
    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);
}

void AddStuGrades::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void AddStuGrades::on_pushButton_back_clicked(){
    emit this->backToAllGradesScreen();
}

void AddStuGrades::on_pushButton_submit_clicked(){
    if(ui->lineEdit_stid->text() == "" || \
       ui->lineEdit_math->text() == "" || \
       ui->lineEdit_english->text() == "" ||\
       ui->lineEdit_c->text() == ""){
        QMessageBox::critical(this,"警告","请检查输入！");
        return;
    }

    QString query_sql = "select COUNT(stid) from studentpasstable where stid=\'";
    query_sql.append(ui->lineEdit_stid->text()+"\'");
    qDebug() << query_sql;
    Result res = g_opt_db->query_db(query_sql);
    int count = atoi(res[0][0].c_str());
    if(count == 0){
        QMessageBox::critical(this,"警告","查无此账号！");
        return;
    }
    uint16_t math = ui->lineEdit_math->text().toUShort();
    uint16_t english = ui->lineEdit_english->text().toUShort();
    uint16_t cpp = ui->lineEdit_c->text().toUShort();
    if((math>100) || (english>100) || (cpp>100)){
        QMessageBox::critical(this,"警告","请检查输入！");
        return;
    }

    QString modify_sql = "update gradetable set grademath=\'";
    modify_sql.append(ui->lineEdit_math->text()+"\',");
    modify_sql.append("gradeen=\'"+ui->lineEdit_english->text()+"\',");
    modify_sql.append("gradec=\'"+ui->lineEdit_c->text()+"\'");
    modify_sql.append(" where stid=\'"+ui->lineEdit_stid->text()+"\'");
    qDebug() << modify_sql;
    g_opt_db->modify_db(modify_sql);
}
