#ifndef ALLSTUGRADES_H
#define ALLSTUGRADES_H

#include <QWidget>
#include "globle.h"
#include <QPainter>
#include <QSqlQueryModel>
#include "admin_ui/addstugrades.h"
#include <QSortFilterProxyModel>
namespace Ui {
class AllStuGrades;
}

class AllStuGrades : public QWidget
{
    Q_OBJECT

public:
    explicit AllStuGrades(QWidget *parent = 0);
    ~AllStuGrades();
    void initScreen();
    void paintEvent(QPaintEvent *event);
    void studentGradesView();
    void load_Model();

private slots:
    void on_pushButton_back_clicked();
    void on_comboBox_activated(int index);

    void on_pushButton_asc_clicked();

    void on_pushButton_desc_clicked();

    void on_pushButton_add_clicked();

    void on_pushButton_select_clicked();

signals:
    void backToAdminScreen();
private:
    Ui::AllStuGrades *ui;
    QPixmap bg;
    QSortFilterProxyModel* proxyModel = nullptr;
    QSqlQueryModel* model = nullptr;
    AddStuGrades* addstugrade = nullptr;
    uint32_t selected_index = 0;


};

#endif // ALLSTUGRADES_H
