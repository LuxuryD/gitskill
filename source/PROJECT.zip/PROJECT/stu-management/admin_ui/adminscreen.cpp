#include "adminscreen.h"
#include "ui_adminscreen.h"
#include "resources/pic_res.h"
AdminScreen::AdminScreen(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AdminScreen)
{
    ui->setupUi(this);
    iniScene();
}

AdminScreen::~AdminScreen()
{
    delete ui;
}

void AdminScreen::iniScene(){
    setWindowIcon(QIcon(MAINPAGE_ICON));
    setWindowTitle("管理员操作界面");
    this->setFixedSize(width(), height());

    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);

    QString btn_style = "font-size:16pt;";
    ui->pushButton_addGrade->setStyleSheet(btn_style);
    ui->pushButton_gradeShow->setStyleSheet(btn_style);
    ui->pushButton_infoShow->setStyleSheet(btn_style);
    ui->pushButton_addInfo->setStyleSheet(btn_style);
    ui->pushButton_modiAdPass->setStyleSheet(btn_style);
    ui->pushButton_modiStuP->setStyleSheet(btn_style);
    ui->pushButton_modyInfo->setStyleSheet(btn_style);

}

void AdminScreen::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void AdminScreen::on_pushButton_infoShow_clicked(){
    this->hide();
    if(this->allStudentInfo == nullptr){
        this->allStudentInfo = new AllStuInfo();
        connect(allStudentInfo,&AllStuInfo::backToAdminScreen,[=](){ \
            allStudentInfo->hide(); \
            this->show();});
    }
    allStudentInfo->show();
}

void AdminScreen::on_pushButton_addInfo_clicked(){
    this->hide();

    if(this->addstuInfo == nullptr){
        this->addstuInfo = new AddStudent();
        connect(addstuInfo,&AddStudent::backToAdminScreen,[=](){ \
            addstuInfo->hide(); \
            this->show();});
    }
    this->addstuInfo->addStu_Back_Page = ADDSTU_BACK_PAGE_ADMIN;
    this->addstuInfo->show();
}

void AdminScreen::on_pushButton_modiAdPass_clicked()
{
    this->hide();
    if(this->modiadminpass == nullptr){
        this->modiadminpass = new ModifyAdmPass();
        connect(modiadminpass,&ModifyAdmPass::backToAdminScreen,[=](){ \
            modiadminpass->hide(); \
            this->show();});
    }
    modiadminpass->show();
}

void AdminScreen::on_pushButton_modiStuP_clicked()
{
    this->hide();
    if(this->modistupassword == nullptr){
        this->modistupassword = new ModifyStuPass();
        connect(modistupassword,&ModifyStuPass::backToadminScreen,[=](){ \
            modistupassword->hide(); \
            this->show();});
    }
    modistupassword->show();
}

void AdminScreen::on_pushButton_addGrade_clicked()
{
    emit this->backToLoginScreen();

    //addstudentgrade->show();
}

void AdminScreen::on_pushButton_gradeShow_clicked(){
    this->hide();
    if(this->allstugradeshow == nullptr){
        this->allstugradeshow = new AllStuGrades();
        connect(allstugradeshow,&AllStuGrades::backToAdminScreen,[=](){ \
            allstugradeshow->hide(); \
            this->show();});
    }
    allstugradeshow->show();
}

void AdminScreen::on_pushButton_modyInfo_clicked(){
    this->hide();
    if(this->modistuinfo == nullptr){
        this->modistuinfo = new ModifyStuInfo();
        connect(modistuinfo,&ModifyStuInfo::backToAdminScreen,[=](){ \
            modistuinfo->hide(); \
            this->show();});
    }
    modistuinfo->show();
}
