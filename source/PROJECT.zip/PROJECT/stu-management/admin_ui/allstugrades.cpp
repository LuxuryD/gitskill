#include "allstugrades.h"
#include "ui_allstugrades.h"
#include "resources/pic_res.h"
#include "db/opt_sqlite3.h"
#include <QDebug>
#include <QMessageBox>
#include <QFile>
//#include <unistd.h>
#include <QDateTime>

AllStuGrades::AllStuGrades(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AllStuGrades)
{
    ui->setupUi(this);
    initScreen();
    this->load_Model();
}

AllStuGrades::~AllStuGrades(){
    delete ui;
}

void AllStuGrades::initScreen(){
    setWindowTitle("学生成绩展示");
    setWindowIcon(QIcon(MAINPAGE_ICON));

    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);

    QString btn_style = "height:40px; width: 80px; font-size:14pt; background-color:white";
    ui->pushButton_add->setStyleSheet(btn_style);
    ui->pushButton_asc->setStyleSheet(btn_style);
    ui->pushButton_back->setStyleSheet(btn_style);
    ui->pushButton_select->setStyleSheet(btn_style);
    ui->pushButton_desc->setStyleSheet(btn_style);
    ui->comboBox->setStyleSheet(btn_style);

}

void AllStuGrades::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void AllStuGrades::load_Model(){
    QString query_sql = "select stutable.stid,sname,grademath,gradeen,gradec,gradec+gradeen+grademath from stutable,gradetable where stutable.stid=gradetable.stid";
    if(this->model == nullptr){
        this->model = new QSqlQueryModel;
    }
    this->model->setQuery(query_sql);

    if(this->proxyModel == nullptr){
        this->proxyModel = new QSortFilterProxyModel(this);
    }
    this->proxyModel->setSourceModel(model);
    this->proxyModel->setHeaderData(0,Qt::Horizontal,tr("学号"));
    this->proxyModel->setHeaderData(1,Qt::Horizontal,tr("姓名"));
    this->proxyModel->setHeaderData(2,Qt::Horizontal,tr("数学"));
    this->proxyModel->setHeaderData(3,Qt::Horizontal,tr("英语"));
    this->proxyModel->setHeaderData(4,Qt::Horizontal,tr("C++"));
    this->proxyModel->setHeaderData(5,Qt::Horizontal,tr("总分"));

    ui->tableView->setModel(proxyModel);
    ui->tableView->show();
    ui->tableView->setColumnWidth(0,150);
    ui->tableView->setColumnWidth(1,150);
    ui->tableView->setColumnWidth(2,90);
    ui->tableView->setColumnWidth(3,90);
    ui->tableView->setColumnWidth(4,90);
    ui->tableView->setColumnWidth(5,90);
}

void AllStuGrades::on_pushButton_back_clicked(){
    emit this->backToAdminScreen();
}

void AllStuGrades::on_comboBox_activated(int index){
    this->selected_index = index;
}

void AllStuGrades::on_pushButton_asc_clicked(){
    this->proxyModel->sort(selected_index, Qt::AscendingOrder);
}

void AllStuGrades::on_pushButton_desc_clicked(){
    this->proxyModel->sort(selected_index, Qt::DescendingOrder);
}
//添加成绩
void AllStuGrades::on_pushButton_add_clicked(){

    if(this->addstugrade == nullptr){
        this->addstugrade = new AddStuGrades();
        connect(addstugrade,&AddStuGrades::backToAllGradesScreen,[=](){ \
            addstugrade->hide(); \
            this->load_Model(); \
            this->show();});
    }
    this->hide();
    addstugrade->show();
}
//导出成绩
void AllStuGrades::on_pushButton_select_clicked(){
    QString filename = "student_grade_";
    filename.append(QDateTime::currentDateTime().toString("yyyy_MM_dd_hh_mm_ss")+ ".csv");
    QFile outfile;
    outfile.setFileName(filename);
    if(!outfile.open(QIODevice::WriteOnly)){
        PRINT_STRING("目标文件创建失败！");
        return;
    }
    QTextStream out(&outfile);
    out << QStringLiteral("学号") << ",";
    out << QStringLiteral("姓名") << ",";
    out << QStringLiteral("数学") << ",";
    out << QStringLiteral("英语") << ",";
    out << QStringLiteral("C++") << ",";
    out << QStringLiteral("总分") << ",";
    out << "\n";
    QString query_sql = "select stutable.stid,sname,grademath,gradeen,gradec,gradec+gradeen+grademath from stutable,gradetable where stutable.stid=gradetable.stid";
    Result res = g_opt_db->query_db(query_sql);
    for(uint32_t i=0; i<res.size(); i++){
        out << QString::fromStdString(res[i][0]) +",";
        out << QString::fromStdString(res[i][1]) +",";
        out << QString::fromStdString(res[i][2]) +",";
        out << QString::fromStdString(res[i][3]) +",";
        out << QString::fromStdString(res[i][4]) +",";
        out << QString::fromStdString(res[i][5]) +",";
        out << "\n";
    }
    outfile.flush();
    //fsync(outfile.handle());
    outfile.close();
    QMessageBox::information(this,"提示","成绩已成功导出到"+filename+"文件！");
    PRINT_STRING("成绩导出成功！");
    //studentGradesView();
}


