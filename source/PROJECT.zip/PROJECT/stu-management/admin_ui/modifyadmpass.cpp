#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlDatabase>
#include <QSqlQuery>
#include "modifyadmpass.h"
#include "ui_modifyadmpass.h"
#include "resources/pic_res.h"
#include "db/opt_sqlite3.h"
ModifyAdmPass::ModifyAdmPass(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ModifyAdmPass)
{
    ui->setupUi(this);
    initScreen();
}

ModifyAdmPass::~ModifyAdmPass()
{
    delete ui;
}

void ModifyAdmPass::initScreen()
{
    setWindowIcon(QIcon(MAINPAGE_ICON));
    setWindowTitle("修改管理员密码");
    this->setFixedSize(width(), height());

    this->bg = QPixmap(MAINPAGE_BG);
    this->bg.scaled(QSize(width(), height()),Qt::IgnoreAspectRatio, Qt::FastTransformation);
}

void ModifyAdmPass::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setOpacity(0.5);
    painter.drawPixmap(QRect(0, 0, this->width(), this->height()), this->bg);
    painter.end();
}

void ModifyAdmPass::on_pushButton_back_clicked()
{
    emit this->backToAdminScreen();
}

void ModifyAdmPass::on_pushButton_submit_clicked(){
    QString query_sql = "select adpass from admintable where adid=\'";
    query_sql.append(g_login_name + "\'");
    Result query_res = g_opt_db->query_db(query_sql);

    int tmp = QString::compare(QString::fromStdString(query_res[0][0]), \
                               ui->lineEdit_oldPass->text());
    if(tmp != 0){
        QMessageBox::critical(this,"警告","初始密码输入错误！\n请重新输入！");
        return;
    }

    tmp = QString::compare(ui->lineEdit_newPass->text(), ui->lineEdit_againPass->text());
    if(tmp != 0){
        QMessageBox::information(this,"注意","两次密码输入不同，请重新输入！");
        return;
    }

    QString modify_sql = "update admintable set adpass =\'";
    modify_sql.append(ui->lineEdit_newPass->text()+"\' where adid=\'");
    modify_sql.append(g_login_name+"\'");
    g_opt_db->modify_db(modify_sql);

}
