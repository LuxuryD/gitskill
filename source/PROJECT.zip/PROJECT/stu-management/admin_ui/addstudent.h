#ifndef ADDSTUDENT_H
#define ADDSTUDENT_H

#include <QWidget>
#include "globle.h"
#include <QPainter>
namespace Ui {
class AddStudent;
}

typedef enum {
    ADDSTU_BACK_PAGE_ALLSTU = 1,
    ADDSTU_BACK_PAGE_ADMIN,
}AddStu_Back_Page;

class AddStudent : public QWidget
{
    Q_OBJECT

public:
    explicit AddStudent(QWidget *parent = 0);
    ~AddStudent();
    void paintEvent(QPaintEvent *event);
    void initScreen();
    void getInformation();
    bool setInformation();

    AddStu_Back_Page addStu_Back_Page;
private slots:

    void on_pushButton_2_clicked();
    void on_pushButton_submit_clicked();

    void on_comboBox_province_activated(int index);

    void on_comboBox_city_activated(int index);

    void on_comboBox_county_activated(int index);

    void on_comboBox_college_activated(int index);

    void on_comboBox_major_activated(int index);


signals:
    void backToAdminScreen();
    void backToAllStuScreen();

private:

    bool check_stu_id();
    void load_province_msg();
    void load_city_msg(uint32_t province_id);
    void load_area_msg(uint32_t province_id, uint32_t city_id);

    Ui::AddStudent *ui;
    QPixmap bg;


    QMap<uint32_t, uint32_t> combo_province_map;
    QMap<uint32_t, uint32_t> combo_city_map;
    QMap<uint32_t, uint32_t> combo_area_map;

    struct {
        uint32_t province;
        uint32_t city;
        uint32_t area;
    }stu_birth_msg;

};

#endif // ADDSTUDENT_H
