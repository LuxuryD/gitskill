#include "logscreen.h"
#include <QApplication>
#include <QScreen>
#include <QDesktopWidget>
#include "globle.h"
#include "db/opt_sqlite3.h"

QRect g_win = QRect(0, 0, 0, 0);
int main(int argc, char *argv[])
{

    if(g_opt_db == nullptr){
        g_opt_db = new Custom_Db_Opt();
    }
    QApplication a(argc, argv);

    g_win = QGuiApplication::primaryScreen()->geometry();
    LogScreen w;
    w.show();

    return a.exec();
}
