/********************************************************************************
** Form generated from reading UI file 'allstuinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ALLSTUINFO_H
#define UI_ALLSTUINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AllStuInfo
{
public:
    QTableView *tableView;
    QWidget *widget_btn;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_add;
    QPushButton *pushButton_delete;
    QPushButton *pushButton_asc;
    QPushButton *pushButton_desc;
    QPushButton *pushButton_back;

    void setupUi(QWidget *AllStuInfo)
    {
        if (AllStuInfo->objectName().isEmpty())
            AllStuInfo->setObjectName(QString::fromUtf8("AllStuInfo"));
        AllStuInfo->resize(800, 600);
        tableView = new QTableView(AllStuInfo);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(0, 0, 691, 600));
        widget_btn = new QWidget(AllStuInfo);
        widget_btn->setObjectName(QString::fromUtf8("widget_btn"));
        widget_btn->setGeometry(QRect(700, 10, 115, 511));
        verticalLayout = new QVBoxLayout(widget_btn);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButton_add = new QPushButton(widget_btn);
        pushButton_add->setObjectName(QString::fromUtf8("pushButton_add"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButton_add->sizePolicy().hasHeightForWidth());
        pushButton_add->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(pushButton_add);

        pushButton_delete = new QPushButton(widget_btn);
        pushButton_delete->setObjectName(QString::fromUtf8("pushButton_delete"));
        sizePolicy.setHeightForWidth(pushButton_delete->sizePolicy().hasHeightForWidth());
        pushButton_delete->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(pushButton_delete);

        pushButton_asc = new QPushButton(widget_btn);
        pushButton_asc->setObjectName(QString::fromUtf8("pushButton_asc"));
        sizePolicy.setHeightForWidth(pushButton_asc->sizePolicy().hasHeightForWidth());
        pushButton_asc->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(pushButton_asc);

        pushButton_desc = new QPushButton(widget_btn);
        pushButton_desc->setObjectName(QString::fromUtf8("pushButton_desc"));
        sizePolicy.setHeightForWidth(pushButton_desc->sizePolicy().hasHeightForWidth());
        pushButton_desc->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(pushButton_desc);

        pushButton_back = new QPushButton(widget_btn);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));
        sizePolicy.setHeightForWidth(pushButton_back->sizePolicy().hasHeightForWidth());
        pushButton_back->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(pushButton_back);


        retranslateUi(AllStuInfo);

        QMetaObject::connectSlotsByName(AllStuInfo);
    } // setupUi

    void retranslateUi(QWidget *AllStuInfo)
    {
        AllStuInfo->setWindowTitle(QCoreApplication::translate("AllStuInfo", "Form", nullptr));
        pushButton_add->setText(QCoreApplication::translate("AllStuInfo", "\346\267\273\345\212\240", nullptr));
        pushButton_delete->setText(QCoreApplication::translate("AllStuInfo", "\345\210\240\351\231\244", nullptr));
        pushButton_asc->setText(QCoreApplication::translate("AllStuInfo", "\345\215\207\345\272\217", nullptr));
        pushButton_desc->setText(QCoreApplication::translate("AllStuInfo", "\351\231\215\345\272\217", nullptr));
        pushButton_back->setText(QCoreApplication::translate("AllStuInfo", "\350\277\224\345\233\236", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AllStuInfo: public Ui_AllStuInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ALLSTUINFO_H
