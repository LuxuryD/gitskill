/********************************************************************************
** Form generated from reading UI file 'logscreen.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGSCREEN_H
#define UI_LOGSCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LogScreen
{
public:
    QWidget *centralWidget;
    QLabel *title;
    QLineEdit *lineEdit_id;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_password;
    QLabel *label_3;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QPushButton *pushButton_clear;
    QPushButton *pushButton_log;

    void setupUi(QMainWindow *LogScreen)
    {
        if (LogScreen->objectName().isEmpty())
            LogScreen->setObjectName(QString::fromUtf8("LogScreen"));
        LogScreen->setEnabled(true);
        LogScreen->resize(800, 600);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(LogScreen->sizePolicy().hasHeightForWidth());
        LogScreen->setSizePolicy(sizePolicy);
        centralWidget = new QWidget(LogScreen);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        title = new QLabel(centralWidget);
        title->setObjectName(QString::fromUtf8("title"));
        title->setGeometry(QRect(190, 60, 401, 51));
        title->setAlignment(Qt::AlignCenter);
        lineEdit_id = new QLineEdit(centralWidget);
        lineEdit_id->setObjectName(QString::fromUtf8("lineEdit_id"));
        lineEdit_id->setGeometry(QRect(330, 160, 180, 41));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Maximum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lineEdit_id->sizePolicy().hasHeightForWidth());
        lineEdit_id->setSizePolicy(sizePolicy1);
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(250, 160, 61, 41));
        QFont font;
        font.setPointSize(16);
        label->setFont(font);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(250, 240, 61, 28));
        label_2->setFont(font);
        lineEdit_password = new QLineEdit(centralWidget);
        lineEdit_password->setObjectName(QString::fromUtf8("lineEdit_password"));
        lineEdit_password->setGeometry(QRect(330, 230, 181, 41));
        lineEdit_password->setEchoMode(QLineEdit::Password);
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(250, 310, 73, 28));
        label_3->setFont(font);
        radioButton = new QRadioButton(centralWidget);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(340, 310, 81, 26));
        radioButton->setFont(font);
        radioButton_2 = new QRadioButton(centralWidget);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(450, 310, 61, 26));
        radioButton_2->setFont(font);
        pushButton_clear = new QPushButton(centralWidget);
        pushButton_clear->setObjectName(QString::fromUtf8("pushButton_clear"));
        pushButton_clear->setGeometry(QRect(250, 410, 113, 41));
        pushButton_clear->setFont(font);
        pushButton_log = new QPushButton(centralWidget);
        pushButton_log->setObjectName(QString::fromUtf8("pushButton_log"));
        pushButton_log->setGeometry(QRect(400, 410, 111, 41));
        pushButton_log->setFont(font);
        LogScreen->setCentralWidget(centralWidget);

        retranslateUi(LogScreen);

        QMetaObject::connectSlotsByName(LogScreen);
    } // setupUi

    void retranslateUi(QMainWindow *LogScreen)
    {
        LogScreen->setWindowTitle(QCoreApplication::translate("LogScreen", "LogScreen", nullptr));
        title->setText(QCoreApplication::translate("LogScreen", "\345\255\246\347\224\237\344\277\241\346\201\257\347\256\241\347\220\206\347\263\273\347\273\237", nullptr));
        label->setText(QCoreApplication::translate("LogScreen", "\350\264\246\345\217\267\357\274\232", nullptr));
        label_2->setText(QCoreApplication::translate("LogScreen", "\345\257\206\347\240\201\357\274\232", nullptr));
        label_3->setText(QCoreApplication::translate("LogScreen", "\350\272\253\344\273\275\357\274\232", nullptr));
        radioButton->setText(QCoreApplication::translate("LogScreen", "\347\256\241\347\220\206\345\221\230", nullptr));
        radioButton_2->setText(QCoreApplication::translate("LogScreen", "\345\255\246\347\224\237", nullptr));
        pushButton_clear->setText(QCoreApplication::translate("LogScreen", "\346\270\205\347\251\272", nullptr));
        pushButton_log->setText(QCoreApplication::translate("LogScreen", "\347\231\273\345\275\225", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LogScreen: public Ui_LogScreen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGSCREEN_H
