#ifndef __PIC_RES__
#define __PIC_RES__

#define MAINPAGE_BG       ":/resources/naruto.jpg"
#define MAINPAGE_ICON     ":/imag/icon.jpg"


#endif
