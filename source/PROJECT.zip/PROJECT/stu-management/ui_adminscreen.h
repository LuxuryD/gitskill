/********************************************************************************
** Form generated from reading UI file 'adminscreen.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINSCREEN_H
#define UI_ADMINSCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminScreen
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_infoShow;
    QPushButton *pushButton_gradeShow;
    QPushButton *pushButton_addInfo;
    QPushButton *pushButton_modiAdPass;
    QPushButton *pushButton_modyInfo;
    QPushButton *pushButton_modiStuP;
    QPushButton *pushButton_addGrade;

    void setupUi(QWidget *AdminScreen)
    {
        if (AdminScreen->objectName().isEmpty())
            AdminScreen->setObjectName(QString::fromUtf8("AdminScreen"));
        AdminScreen->resize(800, 600);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(AdminScreen->sizePolicy().hasHeightForWidth());
        AdminScreen->setSizePolicy(sizePolicy);
        widget = new QWidget(AdminScreen);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(290, 0, 181, 601));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButton_infoShow = new QPushButton(widget);
        pushButton_infoShow->setObjectName(QString::fromUtf8("pushButton_infoShow"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButton_infoShow->sizePolicy().hasHeightForWidth());
        pushButton_infoShow->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pushButton_infoShow);

        pushButton_gradeShow = new QPushButton(widget);
        pushButton_gradeShow->setObjectName(QString::fromUtf8("pushButton_gradeShow"));
        sizePolicy1.setHeightForWidth(pushButton_gradeShow->sizePolicy().hasHeightForWidth());
        pushButton_gradeShow->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pushButton_gradeShow);

        pushButton_addInfo = new QPushButton(widget);
        pushButton_addInfo->setObjectName(QString::fromUtf8("pushButton_addInfo"));
        sizePolicy1.setHeightForWidth(pushButton_addInfo->sizePolicy().hasHeightForWidth());
        pushButton_addInfo->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pushButton_addInfo);

        pushButton_modiAdPass = new QPushButton(widget);
        pushButton_modiAdPass->setObjectName(QString::fromUtf8("pushButton_modiAdPass"));
        sizePolicy1.setHeightForWidth(pushButton_modiAdPass->sizePolicy().hasHeightForWidth());
        pushButton_modiAdPass->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pushButton_modiAdPass);

        pushButton_modyInfo = new QPushButton(widget);
        pushButton_modyInfo->setObjectName(QString::fromUtf8("pushButton_modyInfo"));
        sizePolicy1.setHeightForWidth(pushButton_modyInfo->sizePolicy().hasHeightForWidth());
        pushButton_modyInfo->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pushButton_modyInfo);

        pushButton_modiStuP = new QPushButton(widget);
        pushButton_modiStuP->setObjectName(QString::fromUtf8("pushButton_modiStuP"));
        sizePolicy1.setHeightForWidth(pushButton_modiStuP->sizePolicy().hasHeightForWidth());
        pushButton_modiStuP->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pushButton_modiStuP);

        pushButton_addGrade = new QPushButton(widget);
        pushButton_addGrade->setObjectName(QString::fromUtf8("pushButton_addGrade"));
        sizePolicy1.setHeightForWidth(pushButton_addGrade->sizePolicy().hasHeightForWidth());
        pushButton_addGrade->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pushButton_addGrade);


        retranslateUi(AdminScreen);

        QMetaObject::connectSlotsByName(AdminScreen);
    } // setupUi

    void retranslateUi(QWidget *AdminScreen)
    {
        AdminScreen->setWindowTitle(QCoreApplication::translate("AdminScreen", "Form", nullptr));
        pushButton_infoShow->setText(QCoreApplication::translate("AdminScreen", "\345\255\246\347\224\237\344\277\241\346\201\257\345\261\225\347\244\272", nullptr));
        pushButton_gradeShow->setText(QCoreApplication::translate("AdminScreen", "\346\210\220\347\273\251\345\261\225\347\244\272", nullptr));
        pushButton_addInfo->setText(QCoreApplication::translate("AdminScreen", "\346\267\273\345\212\240\345\255\246\347\224\237", nullptr));
        pushButton_modiAdPass->setText(QCoreApplication::translate("AdminScreen", "\344\277\256\346\224\271\347\256\241\347\220\206\345\221\230\345\257\206\347\240\201", nullptr));
        pushButton_modyInfo->setText(QCoreApplication::translate("AdminScreen", "\344\277\256\346\224\271\345\255\246\347\224\237\344\277\241\346\201\257", nullptr));
        pushButton_modiStuP->setText(QCoreApplication::translate("AdminScreen", "\344\277\256\346\224\271\345\255\246\347\224\237\345\257\206\347\240\201", nullptr));
        pushButton_addGrade->setText(QCoreApplication::translate("AdminScreen", "\350\277\224\345\233\236", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminScreen: public Ui_AdminScreen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINSCREEN_H
