
function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 4;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
% x0  = [2*pi/180,0,0,0,0,0]; %���г�������
 x0  = [10*pi/180,0,0,0]; %���г�������
str = [];
ts  = [0 0];

function sys=mdlDerivatives(t,x,u) 
global vnorm mB_load delta_zB delta_xB delta_yB

tau4=u(1); 
% v=u(2);
v=vnorm;
w=0.885;
c=0.078;
rmda=pi*4/45;
g=9.81;

rR=0.293;
% v=1.3*pi*rR;   %�ɱ��ٶ�
mR=1.713;
IRxx=0.056;
IRyy=0.111;
xB=0.299+delta_xB;
zB=-0.521+delta_zB;
mB=8.957+mB_load;
IBxx=0.449;
IByy=0.848;
IBzz=0.430;
IBxz=-0.073;
xH=0.816;
zH=-0.579;
mH=2.435;
IHxx=0.091;
IHyy=0.072;
IHzz=0.029;
IHxz=0.016;
rF=0.293;
mF=1.713;
IFxx=0.056;
IFyy=0.111;

mT=mR+mB+mH+mF;
xT=(xB*mB+xH*mH+w*mF)/mT;
zT=(-rR*mR+zB*mB+zH*mH-rF*mF)/mT;
ITxx=IRxx+IBxx+IHxx+IFxx+mR*rR*rR+mB*zB*zB+mH*zH*zH+mF*rF*rF;
ITxz=IBxz+IHxz-mB*xB*zB-mH*xH*zH+mF*w*rF;
IRzz=IRxx;
IFzz=IFxx;
ITzz=IRzz+IBzz+IHzz+IFzz+mB*xB*xB+mH*xH*xH+mF*w*w;
mA=mH+mF;
xA=(xH*mH+w*mF)/mA;
zA=(zH*mH-rF*mF)/mA;
IAxx=IHxx+IFxx+mH*(zH-zA)*(zH-zA)+mF*(rF+zA)*(rF+zA);
IAxz=IHxz-mH*(xH-xA)*(zH-zA)+mF*(w-xA)*(rF+zA);
IAzz=IHzz+IFzz+mH*(xH-xA)*(xH-xA)+mF*(w-xA)*(w-xA);
uA=(xA-w-c)*cos(rmda)-zA*sin(rmda);
IArmdarmda=mA*uA*uA+IAxx*sin(rmda)*sin(rmda)+2*IAxz*sin(rmda)*cos(rmda)+IAzz*cos(rmda)*cos(rmda);
IArmdax=-mA*uA*zA+IAxx*sin(rmda)+IAxz*cos(rmda);
IArmdaz=mA*uA*xA+IAxz*sin(rmda)+IAzz*cos(rmda);
miu=(c/w)*cos(rmda);
SR=IRyy/rR;
SF=IFyy/rF;
ST=SR+SF;
SA=mA*uA+miu*mT*xT;

Mphiphi=ITxx;
Mphisigma=IArmdax+miu*ITxz;
Msigmaphi=Mphisigma;
Msigmasigma=IArmdarmda+2*miu*IArmdaz+miu*miu*ITzz;
M=[Mphiphi,Mphisigma;Mphisigma,Msigmasigma];

K0phiphi=mT*zT;
K0phisigma=-SA;
K0sigmaphi=K0phisigma;
K0sigmasigma=-SA*sin(rmda);
K0=[K0phiphi,K0phisigma;K0phisigma,K0sigmasigma];

K2phiphi=0;
K2phisigma=((ST-mT*zT)/w)*cos(rmda);
K2sigmaphi=0;
K2sigmasigma=((SA+SF*sin(rmda))/w)*cos(rmda);
K2=[K2phiphi,K2phisigma;K2sigmaphi,K2sigmasigma];

K=g*K0+v*v*K2;

C1phiphi=0;
C1phisigma=miu*ST+SF*cos(rmda)+(ITxz/w)*cos(rmda)-miu*mT*zT;
C1sigmaphi=-(miu*ST+SF*cos(rmda));
C1sigmasigma=(IArmdaz/w)*cos(rmda)+miu*(SA+(ITzz/w)*cos(rmda));
C1=[C1phiphi,C1phisigma;C1sigmaphi,C1sigmasigma];

C=v*C1;

%%%��Ӧ��״̬����Ϊq2 q4 dq2  dq4
A11=[0,0;0,0];
A12 = [1,0;0,1];
A21 = -inv(M)* (g*K0 + v*v*K2);
A22 = -inv(M)*v*C1;
A=[A11,A12;A21,A22];

BB1 = [0; 0];
BB2 = inv(M)*[0;1];
B = [BB1;BB2];
C=[1 0 0 0];
D=[0];
[num,den]=ss2tf(A,B,C,D)
% print(num);
% print(den);
U=u(1)+1*(rand()-0.5);
X=[x(1);x(2);x(3);x(4)];

% dE=[0;0;5*(rand()-0.5)*B(3);5*(rand()-0.5)*B(4)]; %�������
% dE=0;

pulse_B=5*B(3);  %�����������ǿ��
dE_pulse_B=[0;0;0;0];
if (t>=5) && (t<=6)
    dE_pulse_B=[0;0;pulse_B;0];
end
if (t>=20) && (t<=21)
    dE_pulse_B=-[0;0;1.2*pulse_B;0];
end

pulse_H=5*B(4);  %�����������ǿ��
dE_pulse_H=[0;0;0;0];
if (t>=10) && (t<=12)
    dE_pulse_H=-[0;0;0;pulse_H];
end
if (t>=25) && (t<=27)
    dE_pulse_H=+[0;0;0;1.2*pulse_H];
end
 
delta_phi=atan(delta_yB/(-zB));
delta_X=[delta_phi;0;0;0];

S=A*(X-delta_X)+B*U;

sys(1)=S(1);
sys(2)=S(2);
sys(3)=S(3);
sys(4)=S(4);

function sys=mdlOutputs(t,x,u)


sys(1)=x(1);
% sys(2)=x(2)+0.02*(rand()-0.5);
% sys(3)=x(3)+0.02*(rand()-0.5);
% sys(4)=x(4)+0.02*(rand()-0.5);









