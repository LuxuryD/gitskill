close all;
clc;clf;

xlabelSize=18;
ylabelSize=18;
titlelSize=18;
biaochiSize=19;

figure(1);
subplot(211);
plot(t,OUT1(:,1),'b','linewidth',2);
set(gca,'fontsize',biaochiSize);
ylabel('$$\phi/rad$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',28);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',28);
set (gcf, 'color','w');
set(gcf,'Position',[0,0,850,300]);
set(gca,'FontName','Times New Roman','FontSize',14);
grid on;

subplot(212);
plot(t,OUT1(:,3),'b','linewidth',2);
set(gca,'fontsize',biaochiSize);
ylabel('$$\dot{\phi}/(rad/s)$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',28);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',28);
set (gcf, 'color','w');
set(gcf,'Position',[0,0,850,300]);
set(gca,'FontName','Times New Roman','FontSize',14);
grid on;

figure(2);
subplot(211);
plot(t,OUT1(:,2),'b','linewidth',2);
set(gca,'fontsize',biaochiSize);
ylabel('$$\delta/rad$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',28);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',28);
set (gcf, 'color','w');
set(gcf,'Position',[0,0,850,300]);
set(gca,'FontName','Times New Roman','FontSize',14);
grid on;

subplot(212);
plot(t,OUT1(:,4),'b','linewidth',2);
set(gca,'fontsize',biaochiSize);
ylabel('$$\dot{\delta}/(rad/s)$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',28);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',28);
set (gcf, 'color','w');
set(gcf,'Position',[0,0,850,300]);
set(gca,'FontName','Times New Roman','FontSize',14);
grid on;

figure(3);
subplot(211);
plot(t,OUT2(:,1),'b','linewidth',2);
set(gca,'fontsize',biaochiSize);
ylabel('$$\tau/N.m$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',28);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',28);
set (gcf, 'color','w');
set(gcf,'Position',[0,0,850,300]);
set(gca,'FontName','Times New Roman','FontSize',14);
grid on;

figure(4);
plot(t,OUT1(:,1),'b','linewidth',2);
set(gca,'fontsize',biaochiSize);
ylabel('$$\phi/rad$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',28);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',28);
set (gcf, 'color','w');
set(gcf,'Position',[0,0,850,300]);
set(gca,'FontName','Times New Roman','FontSize',14);
grid on;
plot(t,OUT(:,1),'r','linewidth',2);
set(gca,'fontsize',biaochiSize);
ylabel('$$\phi/rad$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',28);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',28);
set (gcf, 'color','w');
set(gcf,'Position',[0,0,850,300]);
set(gca,'FontName','Times New Roman','FontSize',14);
grid on;