for i=1:6000

for j=1:4

for k=1:4

A(i,j,k)=0;

end

end

end