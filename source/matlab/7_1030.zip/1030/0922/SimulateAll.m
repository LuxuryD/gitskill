clear;
clc;
run('.\para.m')
global vnorm mB_load delta_zB delta_xB delta_yB  num den

% iMax=12;
% jMax=12;

iMax=1;
jMax=1;

for i=1:iMax
     vnorm=1.2+0.1*(i-1);%���ٵ�����ֵ
     for j=1:jMax
          mB_load=8+1*(j-1);
          delta_zB=-0.0;
          delta_xB=-0.0;
          delta_yB=-0.00; %��������ƫ��
          
          sim('SimulatorM');

          PHI(:,jMax*(i-1)+j)=OUT1(:,1);
          dPHI(:,jMax*(i-1)+j)=OUT1(:,3);
          DELTA(:,jMax*(i-1)+j)=OUT1(:,2);
          dDELTA(:,jMax*(i-1)+j)=OUT1(:,4);
          TAU(:,jMax*(i-1)+j)=OUT2;
          
          PHI_max(jMax*(i-1)+j)=max(OUT1(:,1));
          PHI_min(jMax*(i-1)+j)=min(OUT1(:,1));
          dPHI_max(jMax*(i-1)+j)=max(OUT1(:,3));
          dPHI_min(jMax*(i-1)+j)=min(OUT1(:,3));
          
          DELTA_max(jMax*(i-1)+j)=max(OUT1(:,2));
          DELTA_min(jMax*(i-1)+j)=min(OUT1(:,2));
          dDELTA_max(jMax*(i-1)+j)=max(OUT1(:,4));
          dDELTA_min(jMax*(i-1)+j)=min(OUT1(:,4));
          
          TAU_max(jMax*(i-1)+j)=max(OUT2);
          TAU_min(jMax*(i-1)+j)=min(OUT2);
                   
     end
end

PlotX;
