% close all;
% clc;clf;

xlabelSize=28;
ylabelSize=28;

figure(1);
subplot(211);
plot(t,PHI(:,7+12*0),'r','linewidth',1);
hold on;
plot(t,PHI(:,7+12*3),'g','linewidth',1);
% plot(t,PHI(:,5+12*6),'b','linewidth',1);
plot(t,PHI(:,7+12*7),'c','linewidth',1);
% plot(t,PHI(:,9+12*6),'m','linewidth',1);
plot(t,PHI(:,7+12*11),'k','linewidth',1);
ylabel('$$\phi/rad$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',36);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',36);
set(gca,'FontSize',28); 
legend('v=1.2','v=1.5','v=1.9','v=2.3');
% grid on;

subplot(212);
plot(t,dPHI(:,7+12*0),'r','linewidth',1);
hold on;
plot(t,dPHI(:,7+12*3),'g','linewidth',1);
% plot(t,PHI(:,5+12*6),'b','linewidth',1);
plot(t,dPHI(:,7+12*7),'c','linewidth',1);
% plot(t,PHI(:,9+12*6),'m','linewidth',1);
plot(t,dPHI(:,7+12*11),'k','linewidth',1);
ylabel('$$\dot{\phi}/(rad/s)$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',36);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',36);
set(gca,'FontSize',28);
legend('v=1.2','v=1.5','v=1.9','v=2.3');
% grid on;

figure(2);
subplot(211);
plot(t,DELTA(:,71+12*0),'r','linewidth',1);
hold on;
plot(t,DELTA(:,7+12*3),'g','linewidth',1);
% plot(t,DELTA(:,5+12*6),'b','linewidth',1);
plot(t,DELTA(:,7+12*7),'c','linewidth',1);
% plot(t,DELTA(:,9+12*6),'m','linewidth',1);
plot(t,DELTA(:,7+12*11),'k','linewidth',1);
ylabel('$$\delta/rad$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',36);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',36);
set(gca,'FontSize',28); 
legend('v=1.2','v=1.5','v=1.9','v=2.3');
% grid on;

subplot(212);
plot(t,dDELTA(:,7+12*0),'r','linewidth',1);
hold on;
plot(t,dDELTA(:,7+12*3),'g','linewidth',1);
% plot(t,dDELTA(:,5+12*6),'b','linewidth',1);
plot(t,dDELTA(:,7+12*7),'c','linewidth',1);
% plot(t,dDELTA(:,9+12*6),'m','linewidth',1);
plot(t,dDELTA(:,7+12*11),'k','linewidth',1);
ylabel('$$\dot{\delta}/(rad/s)$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',36);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',36);
set(gca,'FontSize',28); 
legend('v=1.2','v=1.5','v=1.9','v=2.3');
% grid on;

figure(3);
subplot(211);
plot(t,TAU(:,7+12*0),'r','linewidth',1);
hold on;
plot(t,TAU(:,7+12*3),'g','linewidth',1);
% plot(t,TAU(:,5+12*6),'b','linewidth',1);
plot(t,TAU(:,7+12*7),'c','linewidth',1);
% plot(t,TAU(:,9+12*6),'m','linewidth',1);
plot(t,TAU(:,7+12*11),'k','linewidth',1);
ylabel('$$\tau/(N.m)$$','interpreter','latex','FontName','Times New Roman',...
'FontSize',36);
xlabel('$$t/s$$','interpreter','latex','FontName',...
'Times New Roman','FontSize',36);
set(gca,'FontSize',28);
legend('v=1.2','v=1.5','v=1.9','v=2.3');
% grid on;

% subplot(212);
% loadmass=[8:19];
% plot(loadmass,TAU_max(2*12+1:2*12+12),'r','linewidth',1);
% ylabel('$$\tau_u/(N.m)$$','interpreter','latex','FontName','Times New Roman',...
% 'FontSize',28);
% xlabel('$$LaodMass/Kg$$','interpreter','latex','FontName',...
% 'Times New Roman','FontSize',28);
% set(gca,'FontSize',20) 
% % grid on;
% 
% figure(4)
% subplot(211);
% loadmass=[8:19];
% plot(loadmass,TAU_min(2*12+1:2*12+12),'r','linewidth',1);
% ylabel('$$\tau_d/(N.m)$$','interpreter','latex','FontName','Times New Roman',...
% 'FontSize',28);
% xlabel('$$LaodMass/Kg$$','interpreter','latex','FontName',...
% 'Times New Roman','FontSize',28);
% set(gca,'FontSize',20) 
% % grid on;


% figure(1);
% subplot(211);
% plot(t,PHI(:,12*7+1),'r','linewidth',1);
% hold on;
% plot(t,PHI(:,12*7+3),'g','linewidth',1);
% % plot(t,PHI(:,5+12*6),'b','linewidth',1);
% plot(t,PHI(:,12*7+7),'c','linewidth',1);
% % plot(t,PHI(:,9+12*6),'m','linewidth',1);
% plot(t,PHI(:,12*7+11),'k','linewidth',1);
% ylabel('$$\phi/rad$$','interpreter','latex','FontName','Times New Roman',...
% 'FontSize',36);
% xlabel('$$t/s$$','interpreter','latex','FontName',...
% 'Times New Roman','FontSize',36);
% set(gca,'FontSize',28); 
% legend('m=8','m=10','m=14','m=18');
% % grid on;
% 
% subplot(212);
% plot(t,dPHI(:,12*7+1),'r','linewidth',1);
% hold on;
% plot(t,dPHI(:,12*7+3),'g','linewidth',1);
% % plot(t,PHI(:,5+12*6),'b','linewidth',1);
% plot(t,dPHI(:,12*7+7),'c','linewidth',1);
% % plot(t,PHI(:,9+12*6),'m','linewidth',1);
% plot(t,dPHI(:,12*7+11),'k','linewidth',1);
% ylabel('$$\dot{\phi}/(rad/s)$$','interpreter','latex','FontName','Times New Roman',...
% 'FontSize',36);
% xlabel('$$t/s$$','interpreter','latex','FontName',...
% 'Times New Roman','FontSize',36);
% set(gca,'FontSize',28);
% legend('m=8','m=10','m=14','m=18');
% % grid on;
% 
% figure(2);
% subplot(211);
% plot(t,DELTA(:,12*7+1),'r','linewidth',1);
% hold on;
% plot(t,DELTA(:,12*7+3),'g','linewidth',1);
% % plot(t,DELTA(:,5+12*6),'b','linewidth',1);
% plot(t,DELTA(:,12*7+7),'c','linewidth',1);
% % plot(t,DELTA(:,9+12*6),'m','linewidth',1);
% plot(t,DELTA(:,12*7+11),'k','linewidth',1);
% ylabel('$$\delta/rad$$','interpreter','latex','FontName','Times New Roman',...
% 'FontSize',36);
% xlabel('$$t/s$$','interpreter','latex','FontName',...
% 'Times New Roman','FontSize',36);
% set(gca,'FontSize',28); 
% legend('m=8','m=10','m=14','m=18');
% % grid on;
% 
% subplot(212);
% plot(t,dDELTA(:,12*7+1),'r','linewidth',1);
% hold on;
% plot(t,dDELTA(:,12*7+3),'g','linewidth',1);
% % plot(t,dDELTA(:,5+12*6),'b','linewidth',1);
% plot(t,dDELTA(:,12*7+7),'c','linewidth',1);
% % plot(t,dDELTA(:,9+12*6),'m','linewidth',1);
% plot(t,dDELTA(:,12*7+11),'k','linewidth',1);
% ylabel('$$\dot{\delta}/(rad/s)$$','interpreter','latex','FontName','Times New Roman',...
% 'FontSize',36);
% xlabel('$$t/s$$','interpreter','latex','FontName',...
% 'Times New Roman','FontSize',36);
% set(gca,'FontSize',28); 
% legend('m=8','m=10','m=14','m=18');
% % grid on;
% 
% figure(3);
% subplot(211);
% plot(t,TAU(:,12*7+1),'r','linewidth',1);
% hold on;
% plot(t,TAU(:,12*7+3),'g','linewidth',1);
% % plot(t,TAU(:,5+12*6),'b','linewidth',1);
% plot(t,TAU(:,12*7+7),'c','linewidth',1);
% % plot(t,TAU(:,9+12*6),'m','linewidth',1);
% plot(t,TAU(:,12*7+11),'k','linewidth',1);
% ylabel('$$\tau/(N.m)$$','interpreter','latex','FontName','Times New Roman',...
% 'FontSize',36);
% xlabel('$$t/s$$','interpreter','latex','FontName',...
% 'Times New Roman','FontSize',36);
% set(gca,'FontSize',28);
% legend('m=8','m=10','m=14','m=18');
% % grid on;
