
// RobotDlg.h : ͷ�ļ�
//

#pragma once
#include "mscomm1.h"
#include "afxwin.h"


// CRobotDlg �Ի���
class CRobotDlg : public CDialogEx
{
// ����
public:
	CRobotDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_ROBOT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonDriversCon();
	afx_msg void OnBnClickedButtonDriversDiscon();
	afx_msg void OnBnClickedButtonImuCon();
	afx_msg void OnBnClickedButtonImuDiscon();
	afx_msg void OnBnClickedButtonDspCon();
	afx_msg void OnBnClickedButtonDspDiscon();
	afx_msg void OnBnClickedButtonZigbeeCon();
	afx_msg void OnBnClickedButtonZigbeeDiscon();
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnBnClickedButtonEnd();
	CMscomm1 m_mscomm1;
	CMscomm1 m_mscomm2;
	CMscomm1 m_mscomm3;
	CMscomm1 m_mscomm4;
	DECLARE_EVENTSINK_MAP()
	void OnCommMscomm1();
	void OnCommMscomm2();
	void OnCommMscomm3();
	void OnCommMscomm4();
	CMscomm1 m_mscomm5;
	void OnCommMscomm5();
	CButton m_button_divers_con;
	CButton m_button_divers_discon;
	CButton m_button_imu_con;
	CButton m_button_imu_discon;
	CButton m_button_dsp_con;
	CButton m_button_dsp_discon;
	CButton m_button_zigbee_con;
	CButton m_button_zigbee_discon;

	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CButton m_button_start;
	CButton m_button_end;
	afx_msg void OnBnClickedCheck_noticitems();

	void Reset_Send_to_Driver(int COM);
	void Mode_Send_to_Driver(unsigned char MODE,int COM);
	void Current_Send_to_Driver(INT16 CURRENT,INT16 PWM,int COM);
	void Velocity_Send_to_Driver(INT16 VELOCITY,INT16 PWM,int COM);
	void Position_Send_to_Driver(INT32 POSITION,INT16 PWM,int COM);
	void Data_Query_from_Driver(unsigned char PERIOD,unsigned char CTL,int COM);

	void Data_Send_to_HostPC(int LEN,double STR[],int PRECISE[],int COM);
	long int GetLen(unsigned char *s);
	void Float_to_ASCII(double n,int precise,unsigned char s[]);
	void Reverse(unsigned char s[]);

	void Get_Data_IMU(int COM);

	void Data_Query_from_SlaveDSP(int COM);
	void Data_Query_from_IMU(int COM);

	float HexToFloat(unsigned char* byteArry);
	void FloatToHex(float floatNum,unsigned char* byteArry);
	void DoubleFloatToHex(double floatNum,unsigned char* byteArry);
	void DataMount(double d1,double d2,double d3,double d4,unsigned char* str);
    void Dyte_Send_To_PC(double d1,double d2,double d3,double d4,int COM);

	void ElapseTime_Ctr_US(LARGE_INTEGER *pres,__int64 tc);
 
};

static void CALLBACK TimerCallBack(UINT TimeID,UINT msg,DWORD dwUser,DWORD dwa,DWORD dwb);