import org.junit.Test;

import java.io.StringReader;
import java.io.StringWriter;

import controller.StockInfoController;
import controller.StockInfoControllerImpl;
import model.StockModel;
import model.StockModelImpl;

import static org.junit.Assert.assertEquals;

/**
 * Testing correct output of program.
 */
public class StockInfoControllerImplTest {

  /**
   * Testing correct output.
   */
  @Test
  public void test() {
    StockModel model = new StockModelImpl();
    Readable rd = new StringReader("4" + System.lineSeparator() + "9"
            + System.lineSeparator() + "quit");
    Appendable ap = new StringWriter();
    StockInfoController testController = new StockInfoControllerImpl(model, rd, ap);
    testController.start();
    String expected = "Welcome to the Easy Stock program!"
            + System.lineSeparator()
            + "In this program, you will be able to use the following functions"
            + "to learn and build your ability in the stock trading market."
            + System.lineSeparator()
            + "You can do the following by inputting operation Number."
            + System.lineSeparator()
            + "the operation Number is provided in the Parentheses"
            + System.lineSeparator()
            + System.lineSeparator()
            + "(1) Checking the gain/loss of a stock over a period"
            + System.lineSeparator()
            + "(2) Checking the x-day moving average of a stock with specified date "
            + "and x"
            + System.lineSeparator()
            + "(3) Checking which days are x-day crossovers for a stock"
            + System.lineSeparator()
            + "(4) Portfolio operation"
            + System.lineSeparator()
            + "(5) Performance bar chart for a stock during certain period"
            + System.lineSeparator()
            + "(quit) Quit program"
            + System.lineSeparator()
            + "Please enter your operation: "
            + System.lineSeparator()
            + System.lineSeparator()
            + "Please Enter the following operation Number:"
            + System.lineSeparator()
            + "(1) Create a new portfolio"
            + System.lineSeparator()
            + "(2) Edit a current portfolio"
            + System.lineSeparator()
            + "(3) Check combination of a portfolio on a specific date"
            + System.lineSeparator()
            + "(4) Check the value of a portfolio on a specific date"
            + System.lineSeparator()
            + "(5) Check the distribution of a portfolio on a specific date"
            + System.lineSeparator()
            + "(6) Rebalance a portfolio on a specific day"
            + System.lineSeparator()
            + "(7) Demonstrate the performance as a chart in certain period"
            + System.lineSeparator()
            + "(8) Save / load "
            + System.lineSeparator()
            + "(9) Back to main menu"
            + System.lineSeparator()
            + "Please enter your operation: "
            + System.lineSeparator()
            + System.lineSeparator()
            + "(1) Checking the gain/loss of a stock over a period"
            + System.lineSeparator()
            + "(2) Checking the x-day moving average of a stock with specified date "
            + "and x"
            + System.lineSeparator()
            + "(3) Checking which days are x-day crossovers for a stock"
            + System.lineSeparator()
            + "(4) Portfolio operation"
            + System.lineSeparator()
            + "(5) Performance bar chart for a stock during certain period"
            + System.lineSeparator()
            + "(quit) Quit program"
            + System.lineSeparator()
            + "Please enter your operation: "
            + System.lineSeparator()
            + "Thank you for your using, see you next time."
            + System.lineSeparator();
    assertEquals(expected, ap.toString());
  }
}