package model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * This class tests the Portfolio class.
 */
public class PortfolioTest {
  User user;
  Portfolio p1;
  Portfolio p2;

  @Before
  public void setUp() {
    user = new UserImpl();
    p1 = new SimplePortfolio("p1");
    p2 = new SimplePortfolio("p2");
    user.addPortfolio("p1");
    user.addPortfolio("p2");
  }

  // This test checks that the addPortfolio method adds a portfolio with the given name to the user.
  @Test
  public void testAddPortfolio() {
    User user = new UserImpl();
    user.addPortfolio("p1");
    assertNotNull(user.getPortfolio("p1"));
  }

  // This test checks that the getPortfolio method returns the portfolio with the given name.
  @Test
  public void testGetPortfolio() {
    User user = new UserImpl();
    user.addPortfolio("p1");
    Portfolio p = user.getPortfolio("p1");
    assertEquals("p1", p.getName());
  }

  @Test
  public void testGetTotalValue() {
    p1.addStock("GOOG", 10);
    assertEquals(1774, p1.getTotalValue("2024-05-29"), 0.01);
  }
}
