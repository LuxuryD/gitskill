package model;

import org.junit.Before;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * This class tests the Stock class.
 */
public class StockTest {
  String testData;
  String testSymbol;
  Stock stock;
  String[][] expectedData;

  private String readCsvToString(String filePath) {
    StringBuilder stringBuilder = new StringBuilder();
    int i = 0;
    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
      String line;
      while ((line = reader.readLine()) != null) {
        if (i == 0) {
          i++;
          continue;
        }
        stringBuilder.append(line).append("\n");
      }
    } catch (IOException e) {
      System.out.println("Error reading file: " + e.getMessage());
    }
    return stringBuilder.toString();
  }


  @Before
  public void setUp() {
    testData = readCsvToString("./test/model/GOOG_raw.csv");
    testSymbol = "GOOG";
    stock = new Stock(testSymbol, testData);
    String[] lines = readCsvToString("./test/model/GOOG_test.csv").split("\n");
    expectedData = new String[lines.length][];
    for (int i = 0; i < lines.length; i++) {
      expectedData[i] = lines[i].split(",");
    }
  }

  @Test
  public void testGainOrLoss() {
    try {
      for (int i = 1; i < expectedData.length - 5; i++) {
        String startDate = expectedData[i][0];
        String endDate = expectedData[i + 5][0];
        double expected = Double.parseDouble(expectedData[i][1]);
        double actual = stock.getGainOrLoss(startDate, endDate);
        assertEquals(expected, actual, 0.01);
      }
    } catch (IllegalArgumentException e) {
      // pass
    }

    try {
      stock.getGainOrLoss("2018-09-08", "2018-09-07");
    } catch (IllegalArgumentException e) {
      assertEquals("Start date must be before end date", e.getMessage());
    }

    try {
      stock.getGainOrLoss("2018-09-06", "2018-09-08");
    } catch (IllegalArgumentException e) {
      assertEquals("The end date is not found in database", e.getMessage());
    }

    try {
      stock.getGainOrLoss("2018-09-08", "2018-09-09");
    } catch (IllegalArgumentException e) {
      assertEquals("The start date is not found in database", e.getMessage());
    }
  }

  @Test
  public void testFiveDaysMovingAverage() {
    try {
      for (int i = 1; i < expectedData.length - 5; i++) {
        String date = expectedData[i][0];
        double expected = Double.parseDouble(expectedData[i][2]);
        double actual = stock.calculateMovingAverage(date, 5);
        assertEquals(expected, actual, 0.01);
      }
    } catch (IllegalArgumentException e) {
      // pass
    }
  }

  @Test
  public void testThirtyDaysMovingAverage() {
    try {
      for (int i = 1; i < expectedData.length - 30; i++) {
        String date = expectedData[i][0];
        double expected = Double.parseDouble(expectedData[i][3]);
        double actual = stock.calculateMovingAverage(date, 30);
        assertEquals(expected, actual, 0.01);
      }
    } catch (IllegalArgumentException e) {
      // pass
    }
  }

  @Test
  public void testInvalidMovingAverage() {
    try {
      stock.calculateMovingAverage("2018-09-08", 0);
    } catch (IllegalArgumentException e) {
      assertEquals("Days must be greater than 0", e.getMessage());
    }

    try {
      stock.calculateMovingAverage("2014-03-28", 5);
    } catch (IllegalArgumentException e) {
      assertEquals("Not enough data to calculate average", e.getMessage());
    }
  }

  @Test
  public void testAll30CrossOverDays() {
    List<String> expected = new ArrayList<>();
    for (int i = 0; i < expectedData.length - 30; i++) {
      if (expectedData[i][4].equals("Yes")) {
        expected.add(expectedData[i][0]);
      }
    }

    try {
      List<String> actual = stock.findCrossoverDays("2014-05-09", "2024-05-29", 30);
      assertEquals(expected, actual);
    } catch (IllegalArgumentException e) {
      // pass
    }
  }
}