package model;

import org.junit.Before;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * This class tests the StockModelImpl class.
 */
public class StockModelImplTest {
  String testData;
  String testSymbol;
  Stock stock;
  String[][] expectedData;
  StockModelImpl stockModel;

  private String readCsvToString(String filePath) {
    StringBuilder stringBuilder = new StringBuilder();
    int i = 0;
    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
      String line;
      while ((line = reader.readLine()) != null) {
        if (i == 0) {
          i++;
          continue;
        }
        stringBuilder.append(line).append("\n");
      }
    } catch (IOException e) {
      System.out.println("Error reading file: " + e.getMessage());
    }
    return stringBuilder.toString();
  }


  @Before
  public void setUp() {
    testData = readCsvToString("./test/model/GOOG_raw.csv");
    testSymbol = "GOOG";
    stock = new Stock(testSymbol, testData);
    String[] lines = readCsvToString("./test/model/GOOG_test.csv").split("\n");
    expectedData = new String[lines.length][];
    for (int i = 0; i < lines.length; i++) {
      expectedData[i] = lines[i].split(",");
    }
    stockModel = new StockModelImpl();
  }

  @Test
  public void addStock() {
    assertTrue(stockModel.addStock("GOOG"));
    assertFalse(stockModel.addStock("GOOG"));
  }

  @Test
  public void getGainOrLoss() {
    assertTrue(stockModel.addStock("GOOG"));
    try {
      for (int i = 1; i < expectedData.length - 5; i++) {
        String startDate = expectedData[i][0];
        String endDate = expectedData[i + 5][0];
        double expected = Double.parseDouble(expectedData[i][1]);
        double actual = stockModel.getGainOrLoss("GOOG", startDate, endDate);
        assertEquals(expected, actual, 0.01);
      }
    } catch (IllegalArgumentException e) {
      // pass
    }
  }

  @Test
  public void examineXDaysMovingAverage() {
    assertTrue(stockModel.addStock("GOOG"));
    try {
      for (int i = 1; i < expectedData.length - 5; i++) {
        String date = expectedData[i][0];
        double expected = Double.parseDouble(expectedData[i][2]);
        double actual = stockModel.examineXDaysMovingAverage("GOOG", date, 5);
        assertEquals(expected, actual, 0.01);
      }
    } catch (IllegalArgumentException e) {
      // pass
    }
  }

  @Test
  public void getXDaysCrossover() {
    assertTrue(stockModel.addStock("GOOG"));
    try {
      for (int i = 1; i < expectedData.length - 30; i++) {
        String date = expectedData[i][0];
        double expected = Double.parseDouble(expectedData[i][3]);
        double actual = stock.calculateMovingAverage(date, 30);
        assertEquals(expected, actual, 0.01);
      }
    } catch (IllegalArgumentException e) {
      // pass
    }
  }

  @Test
  public void addPortfolio() {
    assertTrue(stockModel.addPortfolio("portfolio1"));
    assertFalse(stockModel.addPortfolio("portfolio1"));
  }
}