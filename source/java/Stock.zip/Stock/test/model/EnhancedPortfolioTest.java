package model;

import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * This class tests the EnhancedPortfolio class.
 */
public class EnhancedPortfolioTest {
  User user;
  PortfolioEnhanced p1;
  PortfolioEnhanced p2;

  @Before
  public void setUp() {
    user = new UserImpl();
    p1 = new EnhancedPortfolio("p1");
    p2 = new EnhancedPortfolio("p2");
    user.addPortfolio("p1");
    user.addPortfolio("p2");
  }

  @Test
  public void testBuyAndSellStocks() {
    p1.buyStock("GOOG", "2024-05-22", 10);
    assertEquals(178 * 10, p1.getTotalValue("2024-05-22"), 0.01);
    p1.sellStock("GOOG", "2024-05-22", 5);

    try {
      p1.sellStock("GOOG", "2024-05-22", 6);
    } catch (IllegalArgumentException e) {
      assertEquals("Not enough stock to sell", e.getMessage());
    }

    p1.buyStock("GOOG", "2024-05-23", 10);
    p1.buyStock("GOOG", "2024-05-24", 10);
    assertEquals(178 * 5, p1.getTotalValue("2024-05-22"), 0.01);
    assertEquals(175.06 * 15, p1.getTotalValue("2024-05-23"), 0.01);
    assertEquals(176.33 * 25, p1.getTotalValue("2024-05-24"), 0.01);

    try {
      p1.sellStock("GOOG", "2024-05-22", 6);
    } catch (IllegalArgumentException e) {
      assertEquals("The date of new transaction should not be before the "
                      + "last transaction date. The transaction should be in chronological order.",
              e.getMessage());
    }

    try {
      p1.sellStock("ABCD", "2024-05-22", 6);
      fail("The stock should not exist");
    } catch (IllegalArgumentException e) {
      // pass
    }
  }

  @Test
  public void testGetComposition() {
    p1.buyStock("GOOG", "2024-05-22", 10);
    p1.buyStock("AAPL", "2024-05-22", 10);
    p1.sellStock("AAPL", "2024-05-23", 5);
    Map<String, Double> expected = Map.of("GOOG", 10.0, "AAPL", 10.0);
    Map<String, Double> expected2 = Map.of("GOOG", 10.0, "AAPL", 5.0);
    assertEquals(expected, p1.getPortfolioComposition("2024-05-22"));
    assertEquals(expected2, p1.getPortfolioComposition("2024-05-23"));
  }

  @Test
  public void testGetTotalValue() {
    p1.buyStock("GOOG", "2024-05-22", 10);
    p1.buyStock("AAPL", "2024-05-22", 10);
    p1.sellStock("AAPL", "2024-05-23", 5);

    // The total value before the first transaction should be 0.
    assertEquals(0.0, p1.getTotalValue("2024-05-21"), 0.01);
    assertEquals(178 * 10 + 190.9 * 10, p1.getTotalValue("2024-05-22"), 0.01);
    assertEquals(175.06 * 10 + 186.88 * 5, p1.getTotalValue("2024-05-23"), 0.01);

    // Test on weekends
    assertEquals(p1.getTotalValue("2024-05-24"), p1.getTotalValue("2024-05-26"), 0.01);
  }

  @Test
  public void testGetDistribution() {
    p1.buyStock("GOOG", "2024-05-22", 10);
    p1.buyStock("AAPL", "2024-05-22", 10);
    p1.sellStock("AAPL", "2024-05-23", 5);

    Map<String, Double> expected = Map.of("GOOG", 1780.0, "AAPL", 1909.0);
    Map<String, Double> expected2 = Map.of("GOOG", 175.06 * 10, "AAPL", 186.88 * 5);
    assertEquals(expected, p1.getPortfolioDistribution("2024-05-22"));
    assertEquals(expected2, p1.getPortfolioDistribution("2024-05-23"));
  }

  @Test
  public void testSavePortfolio() {
    p1.buyStock("GOOG", "2024-05-22", 10);
    p1.buyStock("AAPL", "2024-05-22", 10);
    p1.sellStock("AAPL", "2024-05-23", 4);
    try {
      p1.savePortfolio();
    } catch (IllegalArgumentException e) {
      assertEquals("Error saving portfolio to file: " + e.getMessage(), e.getMessage());
      fail("The portfolio should be saved");
    }
  }

  @Test
  public void testLoadPortfolio() {
    p1.buyStock("GOOG", "2024-05-22", 10);
    p1.buyStock("AAPL", "2024-05-22", 10);
    p1.sellStock("AAPL", "2024-05-23", 4);
    p1.savePortfolio();
    PortfolioEnhanced p3 = PortfolioEnhanced.loadPortfolio("p1");
    assertEquals(p1.getPortfolioComposition("2024-05-23"),
            p3.getPortfolioComposition("2024-05-23"));
  }

  @Test
  public void testRebalancePortfolio() {
    p1.buyStock("GOOG", "2024-05-22", 10);
    p1.buyStock("AAPL", "2024-05-22", 10);

    Map<String, Double> expected = Map.of("GOOG", 1780.0, "AAPL", 1909.0);
    assertEquals(expected, p1.getPortfolioDistribution("2024-05-22"));
    List<Double> weights = List.of(0.5, 0.5);

    p1.rebalancePortfolio("2024-05-22", weights);

    Map<String, Double> expected2 = Map.of("GOOG", 1844.5, "AAPL", 1844.5);
    for (String stockName : expected2.keySet()) {
      assertEquals(expected2.get(stockName),
              p1.getPortfolioDistribution("2024-05-22").get(stockName), 0.0001);
    }
  }

  @Test
  public void testDrawBarChart() {
    p1.buyStock("GOOG", "2024-05-22", 100);
    p1.buyStock("AAPL", "2024-05-22", 10);
    p1.sellStock("AAPL", "2024-05-23", 5);
    String expected = "Performance of portfolio p1 from 2024-05-22 to 2024-05-29"
            + System.lineSeparator() + System.lineSeparator()
            + "May 22 2024: *************************************************"
            + System.lineSeparator()
            + "May 23 2024: *******" + System.lineSeparator()
            + "May 24 2024: ***********" + System.lineSeparator()
            + "May 25 2024: ***********" + System.lineSeparator()
            + "May 26 2024: ***********" + System.lineSeparator()
            + "May 27 2024: ***********" + System.lineSeparator()
            + "May 28 2024: *****************" + System.lineSeparator()
            + "May 29 2024: ***************" + System.lineSeparator() + System.lineSeparator()
            + "Scale: * = $30 more than a base amount of $18350" + System.lineSeparator();

    assertEquals(expected, p1.getBarChartPerformance("2024-05-22", "2024-05-29"));
  }
}