package controller;

public class StockControllerWithGui implements StockInfoController{
  /**
   * Start the program from controller.
   */
  @Override
  public void start() {

  }
}
