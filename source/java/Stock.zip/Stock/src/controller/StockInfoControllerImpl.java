package controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import model.StockModel;
import view.StockInfoView;

/**
 * This class represents the controller of a getting stock information application.
 * This controller offers a text interface in which the user can type instructions to get
 * specific stock information. It has the following features:
 *
 * <p>1. Allow a user to examine the gain or loss of a stock over a specified period.
 * 2. Allow a user to examine the x-day moving average of a stock for a
 * specified date and a specified value of x.
 * 3. Allow a user to determine which days are x-day crossovers for a specified stock
 * over a specified date range and a specified value of x.
 * 4. Allow a user to create one or more portfolios with shares of one or more stock,
 * and find the value of that portfolio on a specific date. You can assume that all the stocks
 * and their quantities will exist on that date.
 */
public class StockInfoControllerImpl implements StockInfoController {
  private final Appendable appendable;
  private final Readable readable;
  private final StockModel model;
  private final view.StockInfoView view = new StockInfoView();

  /**
   * Constructor that accept input, initialize the program.
   *
   * @param model      a Stock model.
   * @param readable   input
   * @param appendable output
   */
  public StockInfoControllerImpl(StockModel model, Readable readable, Appendable appendable) {
    if (model == null || readable == null || appendable == null) {
      throw new IllegalArgumentException("Null arguments are invalid");
    }
    this.appendable = appendable;
    this.readable = readable;
    this.model = model;
  }

  private void writeMessage(String message) throws IllegalArgumentException {
    try {
      appendable.append(message);
    } catch (IOException e) {
      throw new IllegalStateException(e.getMessage());
    }
  }


  /**
   * When running to program, call this method to start the program.
   */
  public void start() {
    Scanner sc = new Scanner(readable);

    File directory = new File("data");
    if (!directory.exists()) {
      directory.mkdirs();
    }

    File directoryPortfolio = new File("portfolios");
    if (!directoryPortfolio.exists()) {
      directoryPortfolio.mkdirs();
    }

    writeMessage(view.welcomeMessage());
    writeMessage(view.instructionMenuMessage());
    boolean quit = false;
    while (!quit) {
      String inputOperation;
      writeMessage(System.lineSeparator());
      writeMessage(view.operationMenuMessage());
      writeMessage(view.inputMessage());
      inputOperation = sc.next();
      switch (inputOperation) {
        case "1":
          checkStock(sc);
          break;
        case "2":
          checkAverageX(sc);
          break;
        case "3":
          checkCrossOverX(sc);
          break;
        case "4":
          portfolioOperation(sc);
          break;
        case "5":
          plotBarChartStock(sc);
          break;
        case "quit":
          writeMessage(view.quitMessage());
          quit = true;
          break;
        default:
          writeMessage(view.invalidInputMessage());
          break;
      }
    }
    String directoryPath = "data";
    directory = new File(directoryPath);
    if (directory.exists() && directory.isDirectory()) {
      File[] files = directory.listFiles();
      if (files != null) {
        for (File file : files) {
          if (file.isFile()) {
            file.delete();
          }
        }
      }
    }
  }

  private void checkStock(Scanner sc) {
    writeMessage(view.inputCodeMessage());
    try {
      List<String> inputResult = inputCodeStartDateEndDate(sc);
      gainLossOutput(inputResult.get(0), inputResult.get(1), inputResult.get(2));
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void checkAverageX(Scanner sc) {
    writeMessage(view.inputCodeMessage());
    try {
      String stockCode = sc.next();
      readStock(stockCode);
      model.addStock(stockCode);
      writeMessage(view.inputEndDateMessage());
      String endDate = getEndDate(sc);
      int x = inputX(sc);
      String outPut = String.format("The X-day moving average for %s is %4f",
              stockCode,
              model.examineXDaysMovingAverage(stockCode, endDate, x));
      writeMessage(outPut + System.lineSeparator());
      writeMessage(view.doneMessage());
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void checkCrossOverX(Scanner sc) {
    writeMessage(view.inputCodeMessage());
    try {
      List<String> resultNormalInput =
              inputCodeStartDateEndDate(sc);
      int x = inputX(sc);
      List<String> result = model.getXDaysCrossover(resultNormalInput.get(0),
              resultNormalInput.get(1),
              resultNormalInput.get(2),
              x);
      if (result == null) {
        writeMessage("No crossovers found in the range." + System.lineSeparator());
      } else {
        StringBuilder output = new StringBuilder(String.format(
                "The dates of x-day crossovers for %s are(is): ",
                resultNormalInput.get(0)
        ));
        for (String value : result) {
          output.append(System.lineSeparator());
          output.append(value);
        }
        writeMessage(output.toString() + System.lineSeparator());
      }
      writeMessage(view.doneMessage());
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }

  }

  private int inputX(Scanner sc) {
    writeMessage(view.inputXMessage());
    boolean isRunning = true;
    int x = 0;
    while (isRunning) {
      try {
        x = sc.nextInt();
        isRunning = false;
      } catch (Exception e) {
        writeMessage("Please enter an integer." + System.lineSeparator());
        sc.next();
      }
    }
    return x;
  }

  private void plotBarChartStock(Scanner sc) {
    try {
      writeMessage(view.inputCodeMessage());
      List<String> input = inputCodeStartDateEndDate(sc);
      String result = model.getPerformanceBarChartStock(input.get(0), input.get(1),
              input.get(2));
      writeMessage(result + System.lineSeparator());
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void portfolioOperation(Scanner sc) {
    boolean isRunning = true;
    while (isRunning) {
      writeMessage(System.lineSeparator());
      writeMessage(view.getPortfolioSubMenu());
      writeMessage(view.inputMessage());
      String operation = sc.next();
      switch (operation) {
        case "1":
          createPortfolio(sc);
          break;
        case "2":
          editPortfolio(sc);
          break;
        case "3":
          checkCombination(sc);
          break;
        case "4":
          checkValue(sc);
          break;
        case "5":
          checkDistribution(sc);
          break;
        case "6":
          reBalancePortfolio(sc);
          break;
        case "7":
          plotBarChartPortfolio(sc);
          break;
        case "8":
          saveLoad(sc);
          break;
        case "9":
          isRunning = false;
          break;
        default:
          writeMessage(view.invalidInputMessage());
      }
    }
  }

  private void createPortfolio(Scanner sc) {
    try {
      writeMessage(view.inputPortfolioNameMessage());
      String name = sc.next();
      if (!model.addPortfolio(name)) {
        throw new IllegalArgumentException("This portfolio is already existed."
                + " Choose edit to work on it");
      }
      writeMessage(view.successfulCreatingPortfolioMessage());
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private String getPortfolioName(Scanner sc) {
    List<String> currentNameList = model.getAllPortfoliosNames();
    if (currentNameList.isEmpty()) {
      throw new IllegalStateException("No portfolio found");
    }
    boolean isRunning = true;
    int index = -1;
    while (isRunning) {
      try {
        writeMessage("Please enter the number index of portfolio as listed"
                + System.lineSeparator());
        for (int i = 0; i < currentNameList.size(); i++) {
          writeMessage("(" + (i + 1) + ") " + currentNameList.get(i) + System.lineSeparator());
        }
        index = sc.nextInt();
        isRunning = false;
      } catch (Exception e) {
        writeMessage("Invalid input, please try again" + System.lineSeparator());
        sc.nextLine();
      }
    }
    String name = currentNameList.get(index - 1);
    if (!currentNameList.contains(name)) {
      throw new IllegalStateException("This portfolio doesn't exist, please create or load it"
              + " before you apply operation to it");
    }
    return name;
  }

  private void editPortfolio(Scanner sc) {
    try {
      String name = getPortfolioName(sc);
      boolean isRunning = true;
      while (isRunning) {
        writeMessage(view.purchaseOrSellMessage());
        String editOperation = sc.next();
        try {
          switch (editOperation) {
            case "1":
              purchaseStock(sc, name);
              break;
            case "2":
              sellStock(sc, name);
              break;
            default:
              throw new IllegalStateException("Invalid input");
          }
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
        if (!keepWorking(sc)) {
          isRunning = false;
        }
      }
    } catch (IndexOutOfBoundsException e) {
      writeMessage("Invalid index chosen, please try again");
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void purchaseStock(Scanner sc, String portfolioName) {
    boolean isRunning = true;
    while (isRunning) {
      try {
        List<String> stockCodeAndDate = getStockCodeAndDate(sc);
        writeMessage(view.purchaseQuantityMessage());
        int quantity = checkInputInteger(sc);
        model.buyStockToPortfolio(portfolioName, stockCodeAndDate.get(0), stockCodeAndDate.get(1),
                quantity);
        writeMessage(view.successfullOperationMessage());
        isRunning = false;
      } catch (Exception e) {
        writeMessage(e.getMessage() + System.lineSeparator());
      }
    }
  }

  private void sellStock(Scanner sc, String portfolioName) {
    boolean isRunning = true;
    while (isRunning) {
      try {
        List<String> stockCodeAndDate = getStockCodeAndDate(sc);
        writeMessage(view.sellQuantityMessage());
        double quantity = checkInputDouble(sc);
        model.sellStockFromPortfolio(portfolioName, stockCodeAndDate.get(0),
                stockCodeAndDate.get(1), quantity);
        writeMessage(view.successfullOperationMessage());
        isRunning = false;
      } catch (IllegalArgumentException e) {
        isRunning = false;
        writeMessage(e.getMessage() + System.lineSeparator());
      } catch (Exception e) {
        writeMessage(e.getMessage() + System.lineSeparator());
      }
    }
  }

  private boolean keepWorking(Scanner sc) {
    boolean isRunning = true;
    boolean result = false;
    while (isRunning) {
      writeMessage(view.keepWorkingOnCurrentPortfolioMessage());
      try {
        String next = sc.next();
        switch (next) {
          case "Yes":
            result = true;
            isRunning = false;
            break;
          case "No":
            isRunning = false;
            break;
          default:
            throw new IllegalStateException("Invalid input, please try again.");
        }
      } catch (Exception e) {
        writeMessage(e.getMessage() + System.lineSeparator());
      }
    }
    return result;
  }

  private void checkCombination(Scanner sc) {
    try {
      String name = getPortfolioName(sc);
      boolean isRunning = true;
      while (isRunning) {
        try {
          writeMessage(view.askForDateMessage());
          String date = inputDate(sc);
          Map<String, Double> result = model.getPortfolioComposition(name, date);
          if (result.isEmpty()) {
            isRunning = false;
            throw new IllegalStateException("No data found");
          }
          writeMessage(String.format(
                  "Your composition for %s on %s is: ",
                  name,
                  date
          ) + System.lineSeparator());
          outputMapValue(result);
          isRunning = false;
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
      }
    } catch (IndexOutOfBoundsException e) {
      writeMessage("Invalid index chosen, please try again");
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void checkValue(Scanner sc) {
    try {
      String name = getPortfolioName(sc);
      boolean isRunning = true;
      while (isRunning) {
        try {
          writeMessage(view.askForDateMessage());
          String date = inputDate(sc);
          double result = model.getTotalValue(name, date);
          writeMessage(
                  String.format(
                          "The value of portfolio %s on %s is: %.4f",
                          name,
                          date,
                          result
                  )
                          + System.lineSeparator()
          );
          isRunning = false;
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
      }
    } catch (IndexOutOfBoundsException e) {
      writeMessage("Invalid index chosen, please try again");
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void checkDistribution(Scanner sc) {
    try {
      String name = getPortfolioName(sc);
      boolean isRunning = true;
      while (isRunning) {
        try {
          writeMessage(view.askForDateMessage());
          String date = inputDate(sc);
          Map<String, Double> result = model.getPortfolioDistribution(name, date);
          if (result.isEmpty()) {
            isRunning = false;
            throw new IllegalStateException("No data found");
          }
          writeMessage(
                  String.format(
                          "You distribution for %s on %s is:",
                          name,
                          date
                  )
                          + System.lineSeparator()
          );
          outputMapValue(result);
          isRunning = false;
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
      }
    } catch (IndexOutOfBoundsException e) {
      writeMessage("Invalid index chosen, please try again");
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void reBalancePortfolio(Scanner sc) {
    try {
      String name = getPortfolioName(sc);
      boolean isRunning = true;
      while (isRunning) {
        try {
          writeMessage(view.askForDateMessage());
          String date = inputDate(sc);
          Map<String, Double> result = model.getPortfolioDistribution(name, date);
          if (result.isEmpty()) {
            isRunning = false;
            throw new IllegalStateException("No data found");
          }
          writeMessage(
                  String.format(
                          "You current distribution for %s on %s is:",
                          name,
                          date
                  )
                          + System.lineSeparator()
          );
          outputMapValue(result);
          if (askForBalance(sc)) {
            List<Double> weight = inputWeight(sc, result);
            model.balancePortfolio(name, date, weight);
            result = model.getPortfolioDistribution(name, date);
            outputMapValue(result);
          }
          isRunning = false;
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
      }
    } catch (IndexOutOfBoundsException e) {
      writeMessage("Invalid index chosen, please try again");
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void plotBarChartPortfolio(Scanner sc) {
    try {
      String name = getPortfolioName(sc);
      writeMessage(view.inputStartDateMessage());
      String startDate = getStartDate(sc);
      String endDate = getEndDate(sc);
      String result = model.getPerformanceBarChartPortfolio(name, startDate, endDate);
      writeMessage(result + System.lineSeparator());
    } catch (IndexOutOfBoundsException e) {
      writeMessage("Invalid index chosen, please try again");
    } catch (Exception e) {
      writeMessage(e.getMessage() + System.lineSeparator());
    }
  }

  private void saveLoad(Scanner sc) {
    boolean isRunning = true;
    while (isRunning) {
      writeMessage(view.askForSaveLoad());
      try {
        String option = sc.next();
        switch (option) {
          case "1":
            saveFile(sc);
            break;
          case "2":
            loadFile(sc);
            break;
          default:
            throw new IllegalStateException("Invalid Input, Please try again.");
        }
        isRunning = false;
      } catch (IndexOutOfBoundsException e) {
        writeMessage("Invalid index, please try agian" + System.lineSeparator());
      } catch (Exception e) {
        writeMessage(e.getMessage() + System.lineSeparator());
        isRunning = false;
      }
    }
  }

  private void saveFile(Scanner sc) {
    List<String> currentPortfoliosName = model.getAllPortfoliosNames();
    if (currentPortfoliosName.isEmpty()) {
      throw new IllegalStateException("No portfolio found");
    }
    List<String> dulplicatePortfolios = dulplicateFileName();
    String name = getPortfolioName(sc);
    boolean isRunning = true;
    while (isRunning) {
      if (dulplicatePortfolios.contains(name)) {
        try {
          writeMessage(view.saveFileAlreadyExistMessage());
          writeMessage(view.keepSavingFileMessage());
          String option = sc.next();
          switch (option) {
            case "Yes":
              model.savePortfolio(name);
              break;
            case "No":
              break;
            default:
              throw new IllegalStateException("Invalid input, please try again");
          }
          writeMessage(view.successfullOperationMessage());
          isRunning = false;
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
      } else {
        try {
          model.savePortfolio(name);
          writeMessage(view.successfullOperationMessage());
          isRunning = false;
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
      }
    }
  }

  private void loadFile(Scanner sc) {
    File portfoliosDirectory = new File("portfolios");
    File[] listOfFiles = portfoliosDirectory.listFiles();
    List<String> fileNames = new ArrayList<>();
    if (listOfFiles != null) {
      for (File file : listOfFiles) {
        if (file.isFile()) {
          fileNames.add(file.getName());
        }
      }
    }
    if (fileNames.isEmpty()) {
      throw new IllegalStateException("No portfolio found in portfolios directory.");
    }
    List<String> currentPortfoliosName = model.getAllPortfoliosNames();
    List<String> dulplicatePortfolios = new ArrayList<>();
    writeMessage("Please select the portfolio you want to load from the following list.");
    boolean isRunning = true;
    int index = -1;
    while (isRunning) {
      try {
        writeMessage("Please enter the number index of portfolio as listed"
                + System.lineSeparator());
        for (int i = 0; i < fileNames.size(); i++) {
          writeMessage("(" + (i + 1) + ") " + fileNames.get(i) + System.lineSeparator());
        }
        index = sc.nextInt();
        isRunning = false;
      } catch (Exception e) {
        writeMessage("Invalid input, please try again" + System.lineSeparator());
        sc.nextLine();
      }
    }
    String name = fileNames.get(index - 1);
    if (!fileNames.contains(name)) {
      throw new IllegalStateException("Invalid index. Please try again");
    }
    for (String portfolioName : currentPortfoliosName) {
      if (fileNames.contains(portfolioName + ".xml")) {
        dulplicatePortfolios.add(portfolioName + ".xml");
      }
    }
    isRunning = true;
    while (isRunning) {
      if (dulplicatePortfolios.contains(name)) {
        try {
          writeMessage(view.loadFileAlreadyExistMessage());
          writeMessage(name + System.lineSeparator());
          writeMessage(view.keepLoadingFileMessage());
          String option = sc.next();
          switch (option) {
            case "Yes":
              String[] pName = name.split("\\.");
              name = pName[0];
              model.loadPortfolio(name);
              break;
            case "No":
              break;
            default:
              throw new IllegalStateException("Invalid input, please try again");
          }
          writeMessage(view.successfullOperationMessage());
          isRunning = false;
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
      } else {
        try {
          String[] pName = name.split("\\.");
          name = pName[0];
          model.loadPortfolio(name);
          writeMessage(view.successfullOperationMessage());
          isRunning = false;
        } catch (Exception e) {
          writeMessage(e.getMessage() + System.lineSeparator());
        }
      }
    }
  }

  private List<String> dulplicateFileName() {
    File portfoliosDirectory = new File("portfolios");
    File[] listOfFiles = portfoliosDirectory.listFiles();
    List<String> fileNames = new ArrayList<>();
    if (listOfFiles != null) {
      for (File file : listOfFiles) {
        if (file.isFile()) {
          fileNames.add(file.getName());
        }
      }
    }
    List<String> currentPortfoliosName = model.getAllPortfoliosNames();
    List<String> dulplicatePortfolios = new ArrayList<>();
    for (String name : currentPortfoliosName) {
      if (fileNames.contains(name + ".xml")) {
        dulplicatePortfolios.add(name);
      }
    }
    return dulplicatePortfolios;
  }

  private boolean askForBalance(Scanner sc) {
    boolean result = true;
    boolean isRunning = true;
    while (isRunning) {
      try {
        writeMessage(view.askForRebalanceMessage());
        String input = sc.next();
        switch (input) {
          case "Yes":
            isRunning = false;
            break;
          case "No":
            result = false;
            isRunning = false;
            break;
          default:
            throw new IllegalStateException("Invalid input, please try again.");
        }
      } catch (Exception e) {
        writeMessage(e.getMessage() + System.lineSeparator());
      }
    }
    return result;
  }

  private List<Double> inputWeight(Scanner sc, Map<String, Double> resultMap) {
    boolean isRunning = true;
    List<Double> result = new ArrayList<>();
    List<String> stockName = new ArrayList<>();
    for (Map.Entry<String, Double> entry : resultMap.entrySet()) {
      stockName.add(entry.getKey());
    }
    while (isRunning) {
      result = new ArrayList<>();
      writeMessage(view.weightMessage());
      try {
        writeMessage("You totally have " + stockName.size() + " stocks to assign weight"
                + System.lineSeparator());
        for (String name : stockName) {
          writeMessage("Please enter weight for " + name + System.lineSeparator());
          result.add(sc.nextDouble());
        }
        double total = 0;
        for (Double weight : result) {
          total += weight;
        }
        if (total != 1) {
          throw new IllegalStateException("Invalid input");
        }
        isRunning = false;
      } catch (Exception e) {
        writeMessage("Invalid weight input." + System.lineSeparator());
      }
    }
    return result;
  }

  private void outputMapValue(Map<String, Double> result) {
    for (Map.Entry<String, Double> entry : result.entrySet()) {
      writeMessage(
              String.format(
                      "%s: %.4f",
                      entry.getKey(),
                      entry.getValue()
              )
                      + System.lineSeparator()
      );
    }
  }

  private List<String> getStockCodeAndDate(Scanner sc) {
    writeMessage(view.inputCodeMessage());
    String stockCode = sc.next();
    readStock(stockCode);
    writeMessage(view.askForDateMessage());
    String date = inputDate(sc);
    return List.of(stockCode, date);
  }

  private int checkInputInteger(Scanner sc) {
    boolean isRunning = true;
    int result = 0;
    while (isRunning) {
      try {
        result = sc.nextInt();
        isRunning = false;
      } catch (InputMismatchException e) {
        writeMessage("Please enter an Integer" + System.lineSeparator());
        sc.nextLine();
      }
    }
    return result;
  }

  private double checkInputDouble(Scanner sc) {
    boolean isRunning = true;
    double result = 0;
    while (isRunning) {
      try {
        String input = sc.nextLine();
        if (!input.matches("^\\d+(\\.\\d{1,4})?$")) {
          throw new IllegalArgumentException("your input should not exceed 4 decimal places");
        }
        result = Double.parseDouble(input);
        isRunning = false;
      } catch (Exception e) {
        if (e.getClass().equals(IllegalArgumentException.class)) {
          writeMessage(e.getMessage() + System.lineSeparator());
        } else {
          writeMessage("Please enter a valid value");
        }
        sc.nextLine();
      }
    }
    return result;
  }

  private String inputDate(Scanner sc) {

    writeMessage(view.askForYearMessage());
    String year = sc.next();
    writeMessage(view.askForMonthMessage());
    String month = sc.next();
    writeMessage(view.askForDayMessage());
    String day = sc.next();
    if (year.length() > 4 || month.length() > 2 || day.length() > 2) {
      throw new IllegalStateException("Invalid Date formate");
    }
    if (month.length() == 1) {
      month = "0" + month;
    }
    if (day.length() == 1) {
      day = "0" + day;
    }
    String date = year + "-" + month + "-" + day;
    checkDateFormat(date);
    return date;
  }

  private void readStock(String stock) throws IllegalArgumentException {
    if (!containsFile(stock)) {
      stockReader(stock);
    }
  }

  private void checkDateFormat(String inputDate) throws IllegalArgumentException {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    try {
      Date date = formatter.parse(inputDate);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date format");
    }
  }

  private boolean containsFile(String stockCode) {
    stockCode = stockCode.toUpperCase();
    File directory = new File("data");
    if (!directory.exists() || !directory.isDirectory()) {
      throw new IllegalArgumentException("Provided path is not a valid directory");
    }
    String fileName = String.format("%s.csv", stockCode);
    String[] files = directory.list();
    assert files != null;
    for (String fileNames : files) {
      if (fileNames.equals(fileName)) {
        return true;
      }
    }
    return false;
  }

  private List<String> inputCodeStartDateEndDate(Scanner sc) {
    String stockCode = sc.next();
    readStock(stockCode);
    model.addStock(stockCode);
    writeMessage(view.inputStartDateMessage());
    String startDate = getStartDate(sc);
    String endDate = getEndDate(sc);
    return List.of(stockCode, startDate, endDate);
  }

  private String getEndDate(Scanner sc) {
    boolean isRunning = true;
    String endDate = "";
    while (isRunning) {
      try {
        endDate = inputDate(sc);
        checkDateFormat(endDate);
        isRunning = false;
      } catch (IllegalArgumentException e) {
        writeMessage(e.getMessage() + System.lineSeparator());
        writeMessage("Please try again" + System.lineSeparator());
      }
    }
    return endDate;
  }

  private String getStartDate(Scanner sc) {
    boolean isRunning = true;
    String startDate = "";
    while (isRunning) {
      try {
        startDate = inputDate(sc);
        checkDateFormat(startDate);
        isRunning = false;
      } catch (IllegalArgumentException e) {
        writeMessage(e.getMessage() + System.lineSeparator());
        writeMessage("Please try again" + System.lineSeparator());
      }
    }
    writeMessage(view.inputEndDateMessage());
    return startDate;
  }


  private void stockReader(String stockCode) throws IllegalArgumentException {
    stockCode = stockCode.toUpperCase();
    String apiKey = "YBLZFBT01STVSWTF";
    String stockSymbol = stockCode; //ticker symbol for Google
    URL url;

    try {
      url = new URL("https://www.alphavantage"
              + ".co/query?function=TIME_SERIES_DAILY"
              + "&outputsize=full"
              + "&symbol"
              + "=" + stockSymbol + "&apikey=" + apiKey + "&datatype=csv");
    } catch (MalformedURLException e) {
      throw new RuntimeException("the alphavantage API has either changed or "
              + "no longer works");
    }

    InputStream in = null;
    StringBuilder output = new StringBuilder();

    try {
      in = url.openStream();
      int b;

      while ((b = in.read()) != -1) {
        output.append((char) b);
      }

      String outputString = output.toString();
      if (outputString.contains("Error Message")) {
        throw new IllegalArgumentException("No price data found for " + stockSymbol);
      }

      // Only write to file if data was successfully read
      String filePath = String.format("data/%s.csv", stockSymbol);

      try (FileWriter writer = new FileWriter(filePath)) {
        writer.write(output.toString());
        writer.flush();
      } catch (IOException e) {
        e.printStackTrace();
      }

    } catch (IOException e) {
      // If an error occurs during data retrieval, do not write to file
      throw new IllegalArgumentException("No price data found for " + stockSymbol, e);
    }
  }

  private void gainLossOutput(String stockCode, String startDate, String endDate)
          throws IllegalArgumentException {
    double result = model.getGainOrLoss(stockCode, startDate, endDate);
    String output;
    if (result < 0) {
      output = String.format("Your loss for %s is: $%.4f",
              stockCode,
              Math.abs(result));
    } else {
      output = String.format("Your gain for %s is: $%.4f",
              stockCode,
              result);
    }
    writeMessage(output + System.lineSeparator());
  }

}