package controller;

/**
 * This interface represents the controller for the stock information program. The controller
 * provides methods to start the program.
 */
public interface StockInfoController {
  /**
   * Start the program from controller.
   */
  void start();
}
