import java.io.InputStreamReader;

import controller.StockInfoController;
import controller.StockInfoControllerImpl;
import model.StockModel;
import model.StockModelImpl;

/**
 * Main class for this program.
 */
public class StockInfoProgram {
  /**
   * Main method that run the program.
   *
   * @param args Arguments in Main method.
   */
  public static void main(String[] args) {

    StockModel model = new StockModelImpl();
    Readable rd = new InputStreamReader(System.in);
    Appendable ap = System.out;
    StockInfoController controller = new StockInfoControllerImpl(model, rd, ap);
    controller.start();


  }
}
