package model;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * This interface represents an enhanced portfolio of stocks which allows the user to add stocks to
 * the portfolio, get the total value of the portfolio, save the portfolio to a file, load the
 * portfolio from a file, buy a stock, sell a stock, get the composition of the portfolio,
 * and get the total value of the portfolio.
 */
public interface PortfolioEnhanced extends Portfolio {
  /**
   * Saves the given portfolio to the given file.
   *
   * @throws IllegalArgumentException if the portfolio is null or the file name is null or empty
   */
  void savePortfolio() throws IllegalArgumentException;

  /**
   * Loads the portfolio from the given file, interpreting XML data to create portfolio entries.
   *
   * @param fileName the name of the file from which the portfolio is to be loaded
   * @return the portfolio loaded from the file
   * @throws IllegalArgumentException if the file name is null or empty
   */
  static PortfolioEnhanced loadPortfolio(String fileName) throws IllegalArgumentException {
    if (fileName == null || fileName.isEmpty()) {
      throw new IllegalArgumentException("File name cannot be null or empty.");
    }
    try {
      File xmlFile = new File("./portfolios/" + fileName + ".xml");
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
      Document doc = builder.parse(xmlFile);
      doc.getDocumentElement().normalize();

      NodeList stockList = doc.getElementsByTagName("Stock");
      EnhancedPortfolio portfolio = new EnhancedPortfolio(doc.getDocumentElement()
              .getAttribute("name"));

      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
      for (int i = 0; i < stockList.getLength(); i++) {
        Node stockNode = stockList.item(i);
        if (stockNode.getNodeType() == Node.ELEMENT_NODE) {
          Element stockElement = (Element) stockNode;
          String stockName = stockElement.getAttribute("symbol");
          StockModelImpl.stockReader(stockName);
          NodeList transactionList = stockElement.getElementsByTagName("Transaction");

          for (int j = 0; j < transactionList.getLength(); j++) {
            Element transaction = (Element) transactionList.item(j);
            Date date = dateFormat.parse(transaction.getAttribute("date"));
            double nowQuantity = Double.parseDouble(transaction.getAttribute("quantity"));
            String type = transaction.getAttribute("type");
            boolean isBuy = "BUY".equals(type);

            // Use the buyStock or sellStock methods depending on the transaction type
            if (isBuy) {
              portfolio.buyStock(stockName, dateFormat.format(date), (int) nowQuantity);
            } else {
              portfolio.sellStock(stockName, dateFormat.format(date), nowQuantity);
            }
          }
        }
      }
      return portfolio;
    } catch (Exception e) {
      throw new IllegalArgumentException("Error loading portfolio from file: " + e.getMessage());
    }
  }

  /**
   * Buys the given stock with the given quantity on the given date.
   *
   * @param stockName the name of the stock to be bought
   * @param date      the date on which the stock is to be bought
   * @param quantity  the quantity of the stock to be bought
   * @throws IllegalArgumentException if the stock is not found or the date is not found
   */
  void buyStock(String stockName, String date, int quantity) throws IllegalArgumentException;

  /**
   * Sells the given stock with the given quantity on the given date.
   *
   * @param stockName the name of the stock to be sold
   * @param date      the date on which the stock is to be sold
   * @param quantity  the quantity of the stock to be sold
   * @throws IllegalArgumentException if the stock is not found or the date is not found
   */
  void sellStock(String stockName, String date, double quantity) throws IllegalArgumentException;

  /**
   * Determine the composition of a portfolio at a specific date. Note that the composition
   * may change over time. The composition must include (a) the list of stocks and (b) the
   * number of shares of each stock
   *
   * @param date the date for which the composition of the portfolio is to be calculated
   * @return the composition of the portfolio
   */
  Map<String, Double> getPortfolioComposition(String date);

  /**
   * Returns the total value of the portfolio.
   * The value for a portfolio before the date of its first purchase would be 0,
   * since each stock in the portfolio now was purchased at a specific point in time.
   *
   * @param date the date for which the total value of the portfolio is to be calculated
   * @return the total value of the portfolio
   */
  double getTotalValue(String date);

  /**
   * The distribution of value of a portfolio on a specific date (to be exact, the end of that day).
   * The distribution of value should include (a) the stock itself (b) the value of each individual
   * stock in the portfolio. The sum of the values in (b) should equal to the value of that
   * portfolio on that date.
   *
   * @param date the date for which the distribution of the portfolio is to be calculated
   * @return the distribution of the portfolio
   */
  Map<String, Double> getPortfolioDistribution(String date);

  /**
   * Rebalances the portfolio with intended weights of the stocks.
   * After balancing, the distribution of value of the portfolio should match the intended weights
   * of the stocks. Assume that the weights are in order of the stocks in the portfolio.
   *
   * @param date    the date on which the portfolio is to be rebalanced
   * @param weights the weights of the stocks in the portfolio
   */
  void rebalancePortfolio(String date, List<Double> weights);

  /**
   * Generates a horizontal bar chart representing the performance of a portfolio between the
   * specified start and end dates. Each line of the chart corresponds to a specific timestamp
   * within the given range, showing the value of the portfolio at that point in time through
   * a series of asterisks.
   *
   * <p>Example of returned format:
   * Performance of portfolio XXX from Jan 2010 to Dec 2010
   * Jan 2010: *****
   * Feb 2010: ***
   * ...
   * Dec 2010: **************
   * Scale: * = $1000
   *
   * @param startDate The starting date of the time range for the performance chart,
   *                  formatted as "MMM yyyy" (e.g., "Jan 2010").
   *                  The date must be valid and precede the endDate.
   * @param endDate   The ending date of the time range for the performance chart,
   *                  formatted as "MMM yyyy" (e.g., "Dec 2010").
   *                  The date must be valid and follow the startDate.
   * @return The performance chart of the portfolio between the specified dates.
   * @throws IllegalArgumentException if the startDate or endDate are invalid, if the endDate
   *                                  is before the startDate, if the format of the dates does not
   *                                  match "MMM yyyy".
   */
  String getBarChartPerformance(String startDate, String endDate) throws IllegalArgumentException;
}
