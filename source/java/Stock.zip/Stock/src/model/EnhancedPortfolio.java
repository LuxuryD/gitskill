package model;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 * This class represents an enhanced portfolio of stocks which allows the user to add stocks to
 * the portfolio, get the total value of the portfolio, save the portfolio to a file, load the
 * portfolio from a file, buy a stock, sell a stock, get the composition of the portfolio,
 * and get the total value of the portfolio.
 */
public class EnhancedPortfolio implements PortfolioEnhanced {
  private final String name;
  private final List<PortfolioStock> portfolio;

  /**
   * Create a new portfolio with the given name.
   *
   * @param name the name of the portfolio
   */
  public EnhancedPortfolio(String name) {
    this.name = name;
    this.portfolio = new ArrayList<>();
  }

  @Override
  public void savePortfolio() {
    try {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
      Document doc = builder.newDocument();

      Element rootElement = doc.createElement("Portfolio");
      doc.appendChild(rootElement);

      rootElement.setAttribute("name", name);

      for (PortfolioStock ps : portfolio) {
        Element stockElement = doc.createElement("Stock");
        stockElement.setAttribute("symbol", ps.getStockName());

        for (int i = 0; i < ps.getStockHistory().size(); i++) {
          Element transactionElement = doc.createElement("Transaction");
          transactionElement.setAttribute("date", dateFormat.format(ps.getStockHistory().get(i)));
          transactionElement.setAttribute("type", ps.getTransactionsType().get(i).toString());
          transactionElement.setAttribute("quantity", String.valueOf(ps
                  .getStockTransactionQTY().get(i)));
          stockElement.appendChild(transactionElement);
        }

        rootElement.appendChild(stockElement);
      }

      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      transformer.setOutputProperty(OutputKeys.INDENT, "yes");
      DOMSource source = new DOMSource(doc);
      StreamResult result = new StreamResult(new File("portfolios/" + name + ".xml"));

      transformer.transform(source, result);
    } catch (Exception e) {
      throw new IllegalArgumentException("Error saving portfolio: " + e.getMessage());
    }
  }

  private void buyStock(String stockName, String date, double quantity) throws
          IllegalArgumentException {
    try {
      StockInfo stock = new Stock(stockName, StockModelImpl.getData(stockName));
      Date purchaseDate = StockModelImpl.dateStrToDate(date);
      for (PortfolioStock p : portfolio) {
        if (p.getStockName().equals(stockName)) {
          p.addStockHistory(purchaseDate, quantity, true);
          p.updateStockData(stock);
          return;
        }
      }
      PortfolioStock newStock = new PortfolioStock(stock);
      newStock.addStockHistory(purchaseDate, quantity, true);
      portfolio.add(newStock);
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException(e.getMessage());
    }
  }

  @Override
  public void buyStock(String stockName, String date, int quantity) throws
          IllegalArgumentException {
    buyStock(stockName, date, (double) quantity);
  }

  @Override
  public void sellStock(String stockName, String date, double quantity) throws
          IllegalArgumentException {
    try {
      Stock stock = new Stock(stockName, StockModelImpl.getData(stockName));
      Date sellDate = StockModelImpl.dateStrToDate(date);
      for (PortfolioStock p : portfolio) {
        if (p.getStockName().equals(stockName)) {
          p.addStockHistory(sellDate, quantity, false);
          p.updateStockData(stock);
          return;
        }
      }
      throw new IllegalArgumentException("Stock not found");
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException(e.getMessage());
    }
  }

  @Override
  public Map<String, Double> getPortfolioComposition(String date) {
    Map<String, Double> composition = new HashMap<>();
    Date d = StockModelImpl.dateStrToDate(date);
    for (PortfolioStock p : portfolio) {
      List<Date> stockHistory = p.getStockHistory();
      List<Double> stockQuantity = p.getStockQuantityHistory();
      int i = 0;
      boolean found = false;
      while (i < stockHistory.size() && (stockHistory.get(i).before(d)
              || stockHistory.get(i).equals(d))) {
        found = stockQuantity.get(i) != 0;
        i++;
      }
      if (found) {
        i = i - 1;
        composition.put(p.getStockName(), stockQuantity.get(i));
      }
    }
    return composition;
  }


  @Override
  public double getTotalValue(String date) {
    double totalValue = 0;
    Map<String, Double> composition = getPortfolioComposition(date);
    for (String stockName : composition.keySet()) {
      Stock stock = new Stock(stockName, StockModelImpl.getData(stockName));
      totalValue += stock.getClosePrice(date) * composition.get(stockName);
    }
    return totalValue;
  }

  @Override
  public Map<String, Double> getPortfolioDistribution(String date) {
    Map<String, Double> composition = getPortfolioComposition(date);
    Map<String, Double> distribution = new HashMap<>();
    for (String stockName : composition.keySet()) {
      Stock stock = new Stock(stockName, StockModelImpl.getData(stockName));
      distribution.put(stockName, stock.getClosePrice(date) * composition.get(stockName));
    }
    return distribution;
  }

  @Override
  public void rebalancePortfolio(String date, List<Double> weights) {
    Map<String, Double> distribution = getPortfolioDistribution(date);
    double totalValue = getTotalValue(date);
    int i = 0;
    for (String stockName : distribution.keySet()) {
      double intendedValue = totalValue * weights.get(i);
      double nowValue = distribution.get(stockName);
      double diff = intendedValue - nowValue;
      double changeQuantity = diff / new Stock(stockName, StockModelImpl.getData(stockName))
              .getClosePrice(date);
      if (diff > 0) {
        buyStock(stockName, date, changeQuantity);
      } else if (diff < 0) {
        sellStock(stockName, date, -changeQuantity);
      }
    }
  }

  @Override
  public String getBarChartPerformance(String startDate, String endDate)
          throws IllegalArgumentException {
    StockModelImpl.ChartScale scale;
    List<Double> data;
    List<String> dateLabels;
    LocalDate start;
    LocalDate end;
    LocalDate date;
    try {
      scale = StockModelImpl.determineScale(startDate, endDate);
      data = new ArrayList<>();
      dateLabels = new ArrayList<>();
      start = LocalDate.parse(startDate);
      end = LocalDate.parse(endDate);
      switch (scale) {
        case DAILY:
          while (!start.isAfter(end)) {
            data.add(getTotalValue(start.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd yyyy");
            dateLabels.add(start.format(formatter));
            start = start.plusDays(1);
          }
          break;
        case WEEKLY:
          date = start.with(TemporalAdjusters.nextOrSame(DayOfWeek.FRIDAY));
          while (!date.isAfter(end)) {
            data.add(getTotalValue(date.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd yyyy");
            dateLabels.add(date.format(formatter));
            date = date.plusWeeks(1);
          }
          break;
        case MONTHLY:
          date = start.with(TemporalAdjusters.lastDayOfMonth());
          while (!date.isAfter(end)) {
            data.add(getTotalValue(date.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yyyy");
            dateLabels.add(date.format(formatter));
            date = date.plusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
          }
          break;
        case QUARTERLY:
          date = start.with(TemporalAdjusters.lastDayOfMonth());
          while (!date.isAfter(end)) {
            data.add(getTotalValue(date.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yyyy");
            dateLabels.add(date.format(formatter));
            date = date.plusMonths(3).with(TemporalAdjusters.lastDayOfMonth());
          }
          break;
        case YEARLY:
          date = start.with(TemporalAdjusters.lastDayOfYear());
          while (!date.isAfter(end)) {
            data.add(getTotalValue(date.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy");
            dateLabels.add(date.format(formatter));
            date = date.plusYears(1).with(TemporalAdjusters.lastDayOfYear());
          }
          break;
        default:
          throw new IllegalArgumentException("Invalid scale");
      }
      start = LocalDate.parse(startDate);
      end = LocalDate.parse(endDate);
      return StockModelImpl.drawBarChart(data, dateLabels, name, start, end, true);
    } catch (Exception e) {
      throw new IllegalArgumentException(e.getMessage());
    }
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public void addStock(String stockName, int quantity) {
    throw new IllegalArgumentException("This operation is not supported in EnhancedPortfolio");
  }

  private static class PortfolioStock {
    StockInfo stock;
    String stockName;
    List<Date> stockHistory;
    List<Double> stockTransactionQTY;
    List<Transaction> transactionsType;
    List<Double> stockQuantityHistory;
    double nowQuantity;

    private PortfolioStock(StockInfo stock) {
      this.stock = stock;
      this.stockName = stock.getSymbol();
      this.stockHistory = new ArrayList<>();
      this.stockTransactionQTY = new ArrayList<>();
      this.transactionsType = new ArrayList<>();
      this.stockQuantityHistory = new ArrayList<>();
      nowQuantity = 0;
    }

    private void addStockHistory(Date date, double quantity, boolean isBuy) {
      if (stockHistory.isEmpty()) {
        stockHistory.add(date);
        stockTransactionQTY.add(quantity);
        transactionsType.add(isBuy ? Transaction.BUY : Transaction.SELL);
        nowQuantity += isBuy ? quantity : -quantity;
        stockQuantityHistory.add(nowQuantity);
      } else {
        if (date.before(stockHistory.get(stockHistory.size() - 1))) {
          throw new IllegalArgumentException("The date of new transaction should not be before the "
                  + "last transaction date. The transaction should be in chronological order.");
        }
        if (isBuy) {
          stockHistory.add(date);
          stockTransactionQTY.add(quantity);
          transactionsType.add(Transaction.BUY);
          nowQuantity += quantity;
          stockQuantityHistory.add(nowQuantity);
        } else {
          if (nowQuantity - quantity < 0) {
            throw new IllegalArgumentException("Not enough stock to sell");
          }
          stockHistory.add(date);
          stockTransactionQTY.add(quantity);
          transactionsType.add(Transaction.SELL);
          nowQuantity -= quantity;
          stockQuantityHistory.add(nowQuantity);
        }
      }
    }

    private void updateStockData(StockInfo s) {
      this.stock = s;
    }

    private StockInfo getStock() {
      return stock;
    }

    private String getStockName() {
      return stockName;
    }

    private List<Date> getStockHistory() {
      return stockHistory;
    }

    private List<Double> getStockTransactionQTY() {
      return stockTransactionQTY;
    }

    private List<Transaction> getTransactionsType() {
      return transactionsType;
    }

    private double getNowQuantity() {
      return nowQuantity;
    }

    private List<Double> getStockQuantityHistory() {
      return stockQuantityHistory;
    }

    private enum Transaction {
      BUY, SELL;

      /**
       * Returns a string representation of the transaction type.
       *
       * @return a string representation of the transaction type
       */
      public String toString() {
        return this == BUY ? "BUY" : "SELL";
      }
    }
  }
}
