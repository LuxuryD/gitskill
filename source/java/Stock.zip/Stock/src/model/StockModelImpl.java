package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * This class implements the StockModel interface. This class directly interacts with the stock
 * model and implements the portfolio feature. It allows the user to add stocks to the system,
 * examine the gain or loss of a stock over a specified period, examine the x-day moving average of
 * a stock for a specified date and a specified value of x, determine which days are x-day
 * crossovers for a specified stock over a specified date range and a specified value of x,
 * create one or more portfolios, and add stocks to them.
 */
public class StockModelImpl implements StockModel {
  private final List<PortfolioEnhanced> portfolios;
  private final List<String> stocks;

  /**
   * Constructs a StockModelImpl object.
   */
  public StockModelImpl() {
    this.portfolios = new ArrayList<>();
    this.stocks = new ArrayList<>();
  }

  /**
   * Converts a date string to a Date object.
   *
   * @param date the date string to be converted
   * @return the Date object
   * @throws IllegalArgumentException if the date string is invalid
   */
  protected static Date dateStrToDate(String date) throws IllegalArgumentException {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return formatter.parse(date);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date format");
    }
  }

  protected static String getData(String stockName) throws IllegalArgumentException {
    try {
      String filePath = "./data/" + stockName + ".csv";
      return readCsvToString(filePath);
    } catch (Exception e) {
      throw new IllegalArgumentException("Stock data not found in data folder");
    }
  }

  protected static String readCsvToString(String filePath) {
    Appendable stringBuilder = new StringBuilder();
    int i = 0;
    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
      String line;
      while ((line = reader.readLine()) != null) {
        if (i == 0) {
          i++;
          continue;
        }
        stringBuilder.append(line).append(System.lineSeparator());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Error reading file: " + e.getMessage());
    }
    return stringBuilder.toString();
  }


  @Override
  public void loadPortfolio(String portfolioName) throws IllegalArgumentException {
    boolean found = false;
    for (int i = 0; i < portfolios.size(); i++) {
      PortfolioEnhanced portfolio = portfolios.get(i);
      if (portfolio.getName().equals(portfolioName)) {
        PortfolioEnhanced newP = PortfolioEnhanced.loadPortfolio(portfolioName);
        portfolios.set(i, newP);
        found = true;
        break;
      }
    }

    if (!found) {
      PortfolioEnhanced portfolio = PortfolioEnhanced.loadPortfolio(portfolioName);
      portfolios.add(portfolio);
    }
  }

  @Override
  public double getGainOrLoss(String symbol, String startDate, String endDate)
          throws IllegalArgumentException {
    if (!stocks.contains(symbol)) {
      throw new IllegalArgumentException("Stock not found");
    }
    Stock stock = new Stock(symbol, getData(symbol));
    double result;
    try {
      result = stock.getGainOrLoss(startDate, endDate);
    } catch (Exception e) {
      throw new IllegalArgumentException(e.getMessage());
    }
    return result;
  }


  @Override
  public double examineXDaysMovingAverage(String symbol, String date, int x)
          throws IllegalArgumentException {
    if (!stocks.contains(symbol)) {
      throw new IllegalArgumentException("Stock not found");
    }
    Stock stock = new Stock(symbol, getData(symbol));
    return stock.calculateMovingAverage(date, x);
  }

  @Override
  public List<String> getXDaysCrossover(String symbol, String startDate, String endDate, int x)
          throws IllegalArgumentException {
    if (!stocks.contains(symbol)) {
      throw new IllegalArgumentException("Stock not found");
    }
    Stock stock = new Stock(symbol, getData(symbol));
    return stock.findCrossoverDays(startDate, endDate, x);
  }

  @Override
  public boolean addPortfolio(String name) {
    for (Portfolio portfolio : portfolios) {
      if (portfolio.getName().equals(name)) {
        return false;
      }
    }
    portfolios.add(new EnhancedPortfolio(name));
    return true;
  }

  @Override
  public void balancePortfolio(String name, String date, List<Double> weights)
          throws IllegalArgumentException {
    for (PortfolioEnhanced portfolio : portfolios) {
      if (portfolio.getName().equals(name)) {
        portfolio.rebalancePortfolio(date, weights);
        return;
      }
    }
    throw new IllegalArgumentException("Portfolio not found");
  }

  @Override
  public String getPerformanceBarChartPortfolio(String name, String startDate, String endDate)
          throws IllegalArgumentException {
    for (PortfolioEnhanced portfolio : portfolios) {
      if (portfolio.getName().equals(name)) {
        return portfolio.getBarChartPerformance(startDate, endDate);
      }
    }
    throw new IllegalArgumentException("Portfolio not found");
  }

  @Override
  public String getPerformanceBarChartStock(String name, String startDate, String endDate)
          throws IllegalArgumentException {
    if (!stocks.contains(name)) {
      throw new IllegalArgumentException("Stock not found");
    }
    Stock stock = new Stock(name, getData(name));
    return stock.getBarChartPerformance(startDate, endDate);
  }

  protected static String drawBarChart(List<Double> data, List<String> dateLabels, String title,
                                       LocalDate startDate, LocalDate endDate,
                                       boolean isPortfolio) {
    Appendable sb = new StringBuilder();
    double total = 0;
    double max = data.get(0);
    double min = data.get(0);
    int scale;
    boolean isRelative = false;
    int base = 0;
    for (double d : data) {
      total += d;
      if (d > max) {
        max = d;
      }
      if (d < min) {
        min = d;
      }
    }

    if (max <= 50) {
      scale = 1;
    } else if (max <= 200) {
      scale = 50;
    } else if (max <= 5000) {
      scale = 100;
    } else {
      isRelative = true;
      double diff = max - min;
      double asterisks = diff / 40.0;
      double multiplier = 1.0;
      while (asterisks / multiplier >= 10) {
        multiplier *= 10;
      }
      scale = (int) ((int) Math.round(asterisks / multiplier) * multiplier);
      base = (int) (min - 3 * scale);
    }

    try {
      sb.append("Performance of ").append(isPortfolio ? "portfolio" : "stock").append(" ")
              .append(title).append(" from ").append(startDate.toString()).append(" to ")
              .append(endDate.toString()).append(System.lineSeparator())
              .append(System.lineSeparator());

      for (int i = 0; i < data.size(); i++) {
        sb.append(dateLabels.get(i)).append(": ");
        int numAsterisks;
        if (!isRelative) {
          numAsterisks = (int) Math.round(data.get(i) / scale);
        } else {
          numAsterisks = 3 + (int) Math.ceil((data.get(i) - base) / scale);
        }
        sb.append("*".repeat(numAsterisks));
        sb.append(System.lineSeparator());
      }

      sb.append(System.lineSeparator());
      sb.append("Scale: * = ")
              .append(isRelative ? ("$" + scale + " more than a base amount of $"
                      + base) : ("$" + scale)).append(System.lineSeparator());
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    return sb.toString();
  }

  protected enum ChartScale {
    DAILY, WEEKLY, MONTHLY, QUARTERLY, YEARLY
  }

  protected static ChartScale determineScale(String startDate, String endDate) {
    LocalDate start = LocalDate.parse(startDate);
    LocalDate end = LocalDate.parse(endDate);
    Period period = Period.between(start, end);
    ChartScale scale;
    long totalDays = ChronoUnit.DAYS.between(start, end);
    if (totalDays < 0) {
      throw new IllegalArgumentException("Start date must be before end date");
    }
    if (period.getYears() > 30) {
      throw new IllegalArgumentException("The time period is too long to draw a bar chart");
    }

    if (period.getYears() >= 5) {
      scale = ChartScale.YEARLY;
    } else if (period.getYears() >= 3) {
      scale = ChartScale.QUARTERLY;
    } else if (period.getYears() > 0 || (period.getYears() == 0 && period.getMonths() >= 5)) {
      scale = ChartScale.MONTHLY;
    } else if (totalDays > 30) {
      scale = ChartScale.WEEKLY;
    } else {
      scale = ChartScale.DAILY;
    }
    return scale;
  }

  @Override
  public List<String> getAllPortfoliosNames() {
    List<String> names = new ArrayList<>();
    for (PortfolioEnhanced portfolio : portfolios) {
      names.add(portfolio.getName());
    }
    return names;
  }


  @Override
  public boolean addStock(String symbol) throws IllegalArgumentException {
    try {
      getData(symbol);
    } catch (Exception e) {
      throw new IllegalArgumentException("Stock data not found");
    }
    for (String stock : stocks) {
      if (stock.equals(symbol)) {
        return false;
      }
    }
    stocks.add(symbol);
    return true;
  }

  @Override
  public void buyStockToPortfolio(String portfolioName, String stockName, String date, int quantity)
          throws IllegalArgumentException {
    for (PortfolioEnhanced portfolio : portfolios) {
      if (portfolio.getName().equals(portfolioName)) {
        portfolio.buyStock(stockName, date, quantity);
        return;
      }
    }
    throw new IllegalArgumentException("Portfolio not found");
  }

  @Override
  public void sellStockFromPortfolio(String portfolioName, String stockName, String date,
                                     double quantity) throws IllegalArgumentException {
    for (PortfolioEnhanced portfolio : portfolios) {
      if (portfolio.getName().equals(portfolioName)) {
        portfolio.sellStock(stockName, date, quantity);
        return;
      }
    }
    throw new IllegalArgumentException("Portfolio not found");
  }

  @Override
  public Map<String, Double> getPortfolioComposition(String name, String date) {
    for (PortfolioEnhanced portfolio : portfolios) {
      if (portfolio.getName().equals(name)) {
        return portfolio.getPortfolioComposition(date);
      }
    }
    return null;
  }

  @Override
  public double getTotalValue(String portfolioName, String date) {
    for (Portfolio portfolio : portfolios) {
      if (portfolio.getName().equals(portfolioName)) {
        return portfolio.getTotalValue(date);
      }
    }
    return -1;
  }

  @Override
  public Map<String, Double> getPortfolioDistribution(String name, String date) {
    for (PortfolioEnhanced portfolio : portfolios) {
      if (portfolio.getName().equals(name)) {
        return portfolio.getPortfolioDistribution(date);
      }
    }
    return null;
  }

  @Override
  public void savePortfolio(String name) throws IllegalArgumentException {
    for (PortfolioEnhanced portfolio : portfolios) {
      if (portfolio.getName().equals(name)) {
        portfolio.savePortfolio();
        return;
      }
    }
    throw new IllegalArgumentException("Portfolio not found");
  }

  protected static void stockReader(String stockCode) throws IllegalArgumentException {
    stockCode = stockCode.toUpperCase();
    String apiKey = "W0M1JOKC82EZEQA8";
    String stockSymbol = stockCode; //ticker symbol for Google
    URL url;

    try {
      url = new URL("https://www.alphavantage"
              + ".co/query?function=TIME_SERIES_DAILY"
              + "&outputsize=full"
              + "&symbol"
              + "=" + stockSymbol + "&apikey=" + apiKey + "&datatype=csv");
    } catch (MalformedURLException e) {
      throw new RuntimeException("the alphavantage API has either changed or "
              + "no longer works");
    }

    InputStream in = null;
    StringBuilder output = new StringBuilder();

    try {
      in = url.openStream();
      int b;

      while ((b = in.read()) != -1) {
        output.append((char) b);
      }

      String outputString = output.toString();
      if (outputString.contains("Error Message")) {
        throw new IllegalArgumentException("No price data found for " + stockSymbol);
      }

      // Only write to file if data was successfully read
      String filePath = String.format("data/%s.csv", stockSymbol);

      try (FileWriter writer = new FileWriter(filePath)) {
        writer.write(output.toString());
        writer.flush();
      } catch (IOException e) {
        e.printStackTrace();
      }

    } catch (IOException e) {
      // If an error occurs during data retrieval, do not write to file
      throw new IllegalArgumentException("No price data found for " + stockSymbol, e);
    }
  }
}
