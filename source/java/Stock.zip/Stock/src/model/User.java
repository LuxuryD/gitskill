package model;

/**
 * This interface represents a user of the stock market system which allows the user to add
 * portfolios and get a portfolio by name.
 */
public interface User {
  /**
   * Adds a portfolio with the given name to the user.
   *
   * @param name the name of the portfolio to be added
   */
  void addPortfolio(String name);

  /**
   * Returns the portfolio with the given name.
   *
   * @param name the name of the portfolio to be returned
   * @return the portfolio with the given name
   */
  Portfolio getPortfolio(String name);
}
