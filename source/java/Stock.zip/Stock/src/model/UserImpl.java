package model;

import java.util.HashMap;
import java.util.Map;

/**
 * This class implements the User interface.
 * It represents a user of the stock market system which allows the user to add portfolios and get a
 * portfolio by name.
 */
public class UserImpl implements User {
  private final Map<String, Portfolio> portfolios;

  /**
   * Create a new user with no portfolios.
   */
  public UserImpl() {
    this.portfolios = new HashMap<>();
  }

  @Override
  public void addPortfolio(String name) {
    portfolios.put(name, new SimplePortfolio(name));
  }

  @Override
  public Portfolio getPortfolio(String name) {
    return portfolios.get(name);
  }
}
