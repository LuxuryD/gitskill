package model;

/**
 * This interface represents a portfolio of stocks which allows the user to add stocks to the
 * portfolio and get the total value of the portfolio.
 */
public interface Portfolio {
  /**
   * Adds the given stock to the portfolio with the given quantity.
   *
   * @param stockName the name of the stock to be added
   * @param quantity  the quantity of the stock to be added
   */
  void addStock(String stockName, int quantity);

  /**
   * Returns the total value of the portfolio.
   *
   * @param date the date for which the total value of the portfolio is to be calculated
   * @return the total value of the portfolio
   */
  double getTotalValue(String date);

  /**
   * Returns the name of the portfolio.
   *
   * @return the name of the portfolio
   */
  String getName();
}
