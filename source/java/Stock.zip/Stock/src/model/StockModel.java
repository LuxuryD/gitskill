package model;

import java.util.List;
import java.util.Map;

/**
 * This interface represents a stock in the stock market system which allows the user to get the
 * stock's name, price, and date. This model is directly used by the controller to get the stock's
 * information, and implements the portfolio feature.
 */
public interface StockModel {
  /**
   * Create a stock to the system. Assuming that the stock data is already created in data folder in
   * the format of symbol.csv.
   *
   * @param symbol the symbol of the stock
   * @return true if the stock is successfully added, false if the stock already exists.
   * @throws IllegalArgumentException if the stock data is not found in the data folder
   */
  boolean addStock(String symbol) throws IllegalArgumentException;

  /**
   * Purchase a specific number of shares of a specific stock on a specified date,
   * and add them to the portfolio.
   * WARNING: All purchases must be made in chronological order.
   *
   * @param portfolioName the name of the portfolio
   * @param stockName     the name of the stock
   * @param date          the date of the purchase
   * @param quantity      the number of shares to purchase
   * @throws IllegalArgumentException if the portfolio name is null or empty,
   *                                  the stock name is null or empty, the date is null or empty,
   *                                  or the quantity is negative
   */
  void buyStockToPortfolio(String portfolioName, String stockName, String date, int quantity)
          throws IllegalArgumentException;

  /**
   * Sell a specific number of shares of a specific stock on a specified date,
   * and remove them from the portfolio.
   * WARNING: All purchases must be made in chronological order.
   *
   * @param portfolioName the name of the portfolio
   * @param stockName     the name of the stock
   * @param date          the date of the sale
   * @param quantity      the number of shares to sell
   * @throws IllegalArgumentException if the portfolio name is null or empty,
   *                                  the stock name is null or empty, the date is null or empty,
   *                                  the quantity is negative, or the quantity is greater than
   *                                  the number of shares in the portfolio
   */
  void sellStockFromPortfolio(String portfolioName, String stockName, String date, double quantity)
          throws IllegalArgumentException;


  /**
   * Determine the composition of a portfolio at a specific date. Note that the composition
   * may change over time. The composition must include (a) the list of stocks and (b) the
   * number of shares of each stock
   *
   * @param name the name of the portfolio
   * @param date the date for which the composition of the portfolio is to be calculated
   * @return the composition of the portfolio
   */
  Map<String, Double> getPortfolioComposition(String name, String date);

  /**
   * Returns the total value of the portfolio.
   * The value for a portfolio before the date of its first purchase would be 0,
   * since each stock in the portfolio now was purchased at a specific point in time.
   *
   * @param name the name of the portfolio
   * @param date the date for which the total value of the portfolio is to be calculated
   * @return the total value of the portfolio
   */
  double getTotalValue(String name, String date);

  /**
   * The distribution of value of a portfolio on a specific date (to be exact, the end of that day).
   * The distribution of value should include (a) the stock itself (b) the value of each individual
   * stock in the portfolio. The sum of the values in (b) should equal to the value of that
   * portfolio on that date.
   *
   * @param name the name of the portfolio
   * @param date the date for which the distribution of the portfolio is to be calculated
   * @return the distribution of the portfolio
   */
  Map<String, Double> getPortfolioDistribution(String name, String date);

  /**
   * Save the portfolio object in XML format in ./portfolios/ directory.
   * The file name is portfolioName.xml.
   *
   * @param name the name of the portfolio to be saved
   * @throws IllegalArgumentException if the portfolio is null
   */
  void savePortfolio(String name) throws IllegalArgumentException;

  /**
   * Load the XML file as a portfolio object into the system.
   * This method will try to load the portfolio object from the XML file in ./portfolios/ directory.
   * The file name is portfolioName.xml.
   *
   * @param portfolioName the name of the portfolio to be loaded
   * @throws IllegalArgumentException if the portfolio is not found
   */
  void loadPortfolio(String portfolioName) throws IllegalArgumentException;

  /**
   * Allow a user to examine the gain or loss of a stock over a specified period.
   *
   * @param symbol    the symbol of the stock
   * @param startDate the start date of the period
   * @param endDate   the end date of the period
   * @return positive if the stock has gained value, negative if the stock has lost value
   * @throws IllegalArgumentException if the stock is not found or the date is not found
   */
  double getGainOrLoss(String symbol, String startDate, String endDate)
          throws IllegalArgumentException;

  /**
   * Allow a user to examine the x-day moving average of a stock for a specified date
   * and a specified value of x.
   *
   * @param symbol the symbol of the stock
   * @param date   the date for which the moving average is to be calculated
   * @param x      the number of days over which the moving average is to be calculated
   * @return the moving average of the stock over the specified period
   * @throws IllegalArgumentException if the stock is not found or there is not enough data to
   *                                  calculate the average or the date is not found
   */
  double examineXDaysMovingAverage(String symbol, String date, int x)
          throws IllegalArgumentException;

  /**
   * Allow a user to determine which days are x-day crossovers for a specified stock over
   * a specified date range and a specified value of x.
   *
   * @param symbol    the symbol of the stock
   * @param startDate the start date of the date range
   * @param endDate   the end date of the date range
   * @param x         the number of days over which the moving average is to be calculated
   * @return a list of dates that are x-day crossovers within the specified range
   * @throws IllegalArgumentException if the stock is not found or there is not enough data to
   *                                  perform the analysis or the date is not found
   *                                  or the start date is after the end date
   */
  List<String> getXDaysCrossover(String symbol, String startDate, String endDate, int x)
          throws IllegalArgumentException;

  /**
   * Allow a user to create one or more portfolios and add stocks to them.
   *
   * @param name the name of the portfolio to be added
   * @return true if the portfolio is successfully added, false if the portfolio already exists
   */
  boolean addPortfolio(String name);

  /**
   * Allow a user to balance the portfolio by adjusting the number of shares of each stock
   * in the portfolio to match the specified weights.
   *
   * @param name    the name of the portfolio to be balanced
   * @param date    the date for which the portfolio is to be balanced
   * @param weights the desired weights of the stocks in the portfolio
   * @throws IllegalArgumentException if the portfolio is not found or the date is not found
   */
  void balancePortfolio(String name, String date, List<Double> weights)
          throws IllegalArgumentException;

  /**
   * Allow a user to get the performance of a portfolio in a bar chart format.
   * The scale may be absolute (one asterisk is equal to 1000) or relative to a base amount.
   *
   * @param name      the name of the portfolio
   * @param startDate the start date of the performance
   * @param endDate   the end date of the performance
   * @return a string representing the performance of the portfolio in a bar chart format
   * @throws IllegalArgumentException if the portfolio is not found or the date is not found
   */
  String getPerformanceBarChartPortfolio(String name, String startDate, String endDate)
          throws IllegalArgumentException;

  /**
   * Allow a user to get the performance of a stock in a bar chart format.
   * The scale may be absolute (one asterisk is equal to 1000) or relative to a base amount.
   *
   * @param name      the name of the stock
   * @param startDate the start date of the performance
   * @param endDate   the end date of the performance
   * @return a string representing the performance of the portfolio in a bar chart format
   * @throws IllegalArgumentException if the portfolio is not found or the date is not found
   */
  String getPerformanceBarChartStock(String name, String startDate, String endDate)
          throws IllegalArgumentException;

  /**
   * The method allows the controller can get the name of portfolios in the system now.
   *
   * @return a list of the names of the portfolios in the system
   */
  List<String> getAllPortfoliosNames();
}
