package model;

import java.util.List;

/**
 * Interface for managing stock data and calculations.
 * This interface provides methods for retrieving stock prices,
 * calculating moving averages, and identifying crossover days.
 */
public interface StockInfo {

  /**
   * Examine the gain or loss of a stock over a specified period only based on the closing price.
   * The gain or loss is calculated as the difference between the closing price on the end date
   * and the closing price on the start date.
   * If the stock is not found or the date is not found, an exception is thrown.
   * The date format is "yyyy-MM-dd".
   * The start date must be before the end date.
   *
   * @param startDate the start date
   * @param endDate   the end date
   * @return the gain or loss
   * @throws IllegalArgumentException if the stock is not found or the date is not found
   */
  double getGainOrLoss(String startDate, String endDate)
          throws IllegalArgumentException;

  /**
   * Calculates the moving average of a stock over a specified number of days.
   *
   * @param date The end date for the moving average calculation.
   * @param days The number of days over which to calculate the average.
   * @return The moving average value.
   * @throws IllegalArgumentException If the stock symbol is not found or
   *                                  there is not enough data to calculate the average.
   */
  double calculateMovingAverage(String date, int days)
          throws IllegalArgumentException;

  /**
   * Identifies the crossover days for a stock over a specified date range.
   * A crossover day is defined as any day when the price moves from below the moving average
   * to above the moving average, or vice versa.
   *
   * @param startDate The start date of the date range.
   * @param endDate   The end date of the date range.
   * @param days      The number of days to calculate the moving average.
   * @return A list of dates that are crossover days within the specified range.
   * @throws IllegalArgumentException If the stock symbol is not found or
   *                                  there is not enough data to perform the analysis.
   */
  List<String> findCrossoverDays(String startDate, String endDate, int days)
          throws IllegalArgumentException;

  /**
   * Returns the closing price of the stock on the given date.
   *
   * @param date the date for which the closing price is to be retrieved
   * @return the closing price of the stock on the given date
   * @throws IllegalArgumentException if the date is not found
   */
  double getClosePrice(String date) throws IllegalArgumentException;

  /**
   * Returns the symbol of the stock.
   *
   * @return the symbol of the stock
   */
  String getSymbol();

  /**
   * Generates a horizontal bar chart representing the performance of a portfolio between the
   * specified start and end dates. Each line of the chart corresponds to a specific timestamp
   * within the given range, showing the value of the portfolio at that point in time through
   * a series of asterisks.
   *
   * <p>Example of returned format:
   * Performance of portfolio XXX from Jan 2010 to Dec 2010
   * Jan 2010: *****
   * Feb 2010: ***
   * ...
   * Dec 2010: **************
   * Scale: * = $1000
   *
   * @param startDate The starting date of the time range for the performance chart,
   *                  formatted as "MMM yyyy" (e.g., "Jan 2010").
   *                  The date must be valid and precede the endDate.
   * @param endDate   The ending date of the time range for the performance chart,
   *                  formatted as "MMM yyyy" (e.g., "Dec 2010").
   *                  The date must be valid and follow the startDate.
   * @return The performance chart of the portfolio between the specified dates.
   * @throws IllegalArgumentException if the startDate or endDate are invalid, if the endDate
   *                                  is before the startDate, if the format of the dates does not
   *                                  match "MMM yyyy".
   */
  String getBarChartPerformance(String startDate, String endDate) throws IllegalArgumentException;
}
