package model;

import java.util.HashMap;
import java.util.Map;

/**
 * This class represents a simple portfolio that contains stocks and their quantities.
 * It allows the user to add stocks to the portfolio and get the total value of the portfolio.
 */
public class SimplePortfolio implements Portfolio {
  Map<StockInfo, Integer> stocks;
  String name;

  /**
   * Create a new portfolio with the given name.
   *
   * @param name the name of the portfolio
   */
  public SimplePortfolio(String name) {
    this.name = name;
    this.stocks = new HashMap<>();
  }

  @Override
  public void addStock(String stockName, int quantity) {
    StockInfo stock = new Stock(stockName, StockModelImpl.getData(stockName));
    if (stocks.containsKey(stock)) {
      stocks.put(stock, stocks.get(stock) + quantity);
    } else {
      stocks.put(stock, quantity);
    }
  }

  @Override
  public double getTotalValue(String date) {
    double totalValue = 0;
    for (StockInfo s : stocks.keySet()) {
      double stockValue = s.getClosePrice(date);
      totalValue += stockValue * stocks.get(s);
    }
    return totalValue;
  }

  @Override
  public String getName() {
    return name;
  }
}
