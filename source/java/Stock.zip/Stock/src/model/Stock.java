package model;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class represents a stock. A stock has a symbol and data.
 * The data is stored in a 2D array where each row represents a day and each column represents
 * a piece of data for that day.
 * The data has the following format:
 * date, daily open, daily high, daily low, daily close, daily volume
 * The date format is "yyyy-MM-dd".
 * The stock provides methods for calculating gain or loss, moving averages, and crossover days.
 * The stock also provides basic getter methods for the symbol.
 */
public class Stock implements StockInfo {
  private final String symbol;
  // data has format: date, daily open, daily high, daily low, daily close, daily volume
  private final String[][] data;

  /**
   * Constructs a Stock object with the given symbol and data.
   *
   * @param symbol  the symbol of the stock
   * @param dataStr the data of the stock in CSV format
   */
  public Stock(String symbol, String dataStr) {
    this.symbol = symbol;
    String[] lines = dataStr.split("\n");
    this.data = new String[lines.length][];
    for (int i = 0; i < lines.length; i++) {
      this.data[i] = lines[i].split(",");
    }
  }

  @Override
  public String getSymbol() {
    return symbol;
  }

  @Override
  public String getBarChartPerformance(String startDate, String endDate)
          throws IllegalArgumentException {
    StockModelImpl.ChartScale scale;
    List<Double> data;
    List<String> dateLabels;
    LocalDate start;
    LocalDate end;
    LocalDate date;
    try {
      scale = StockModelImpl.determineScale(startDate, endDate);
      data = new ArrayList<>();
      dateLabels = new ArrayList<>();
      start = LocalDate.parse(startDate);
      end = LocalDate.parse(endDate);
      switch (scale) {
        case DAILY:
          while (!start.isAfter(end)) {
            data.add(getClosePrice(start.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd yyyy");
            dateLabels.add(start.format(formatter));
            start = start.plusDays(1);
          }
          break;
        case WEEKLY:
          date = start.with(TemporalAdjusters.nextOrSame(DayOfWeek.FRIDAY));
          while (!date.isAfter(end)) {
            data.add(getClosePrice(date.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd yyyy");
            dateLabels.add(date.format(formatter));
            date = date.plusWeeks(1);
          }
          break;
        case MONTHLY:
          date = start.with(TemporalAdjusters.lastDayOfMonth());
          while (!date.isAfter(end)) {
            data.add(getClosePrice(date.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yyyy");
            dateLabels.add(date.format(formatter));
            date = date.plusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
          }
          break;
        case QUARTERLY:
          date = start.with(TemporalAdjusters.lastDayOfMonth());
          while (!date.isAfter(end)) {
            data.add(getClosePrice(date.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yyyy");
            dateLabels.add(date.format(formatter));
            date = date.plusMonths(3).with(TemporalAdjusters.lastDayOfMonth());
          }
          break;
        case YEARLY:
          date = start.with(TemporalAdjusters.lastDayOfYear());
          while (!date.isAfter(end)) {
            data.add(getClosePrice(date.toString()));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy");
            dateLabels.add(date.format(formatter));
            date = date.plusYears(1).with(TemporalAdjusters.lastDayOfYear());
          }
          break;
        default:
          throw new IllegalArgumentException("Invalid scale");
      }
      return StockModelImpl.drawBarChart(data, dateLabels, getSymbol(), start, end, false);
    } catch (Exception e) {
      throw new IllegalArgumentException(e.getMessage());
    }
  }

  @Override
  public double getClosePrice(String date) {
    for (String[] day : data) {
      if (day[0].equals(date)) {
        return Double.parseDouble(day[4]);
      }
    }
    LocalDate d = LocalDate.parse(date);

    if (d.isBefore(LocalDate.parse(data[data.length - 1][0]))) {
      throw new IllegalArgumentException("The date is too early, the stock data only goes back to "
              + data[data.length - 1][0]);
    }

    if (d.isAfter(LocalDate.now().minusDays(1))) {
      throw new IllegalArgumentException("The date data has not been added to the database yet.");
    }

    while (true) {
      d = d.minusDays(1);
      for (String[] day : data) {
        if (day[0].equals(d.toString())) {
          return Double.parseDouble(day[4]);
        }
      }
    }
  }


  @Override
  public double getGainOrLoss(String startDate, String endDate)
          throws IllegalArgumentException {
    Date start;
    Date end;
    double startPrice = -1;
    double endPrice = -1;
    double gainLoss;

    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    try {
      start = formatter.parse(startDate);
      end = formatter.parse(endDate);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date format");
    }
    // check if start date is before end date
    if (start.after(end)) {
      throw new IllegalArgumentException("Start date must be before end date");
    }

    for (String[] day : data) {
      if (day[0].equals(startDate)) {
        startPrice = Double.parseDouble(day[4]);
      }
      if (day[0].equals(endDate)) {
        endPrice = Double.parseDouble(day[4]);
      }
    }

    if (startPrice == -1) {
      throw new IllegalArgumentException("The start date is not found in database, this is because"
              + " the date is not a trading day or the date is not in the database.");
    }
    if (endPrice == -1) {
      throw new IllegalArgumentException("The end date is not found in database, this is because"
              + " the date is not a trading day or the date is not in the database.");
    }

    gainLoss = endPrice - startPrice;
    return gainLoss;
  }

  @Override
  public double calculateMovingAverage(String date, int days) throws IllegalArgumentException {
    // if date - days is before the first date in the data, throw exception
    // if date is not found in the data, throw exception
    if (days < 1) {
      throw new IllegalArgumentException("Days must be greater than 0");
    }


    double average = -1;
    double sum;

    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    try {
      formatter.parse(date);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date format");
    }

    for (int i = 0; i < data.length; i++) {
      if (data[i][0].equals(date)) {
        sum = 0;
        if (i + days > data.length) {
          throw new IllegalArgumentException("Not enough data to calculate average");
        }

        for (int j = i; j < i + days; j++) {
          sum += Double.parseDouble(data[j][4]);
        }
        average = sum / days;
      }
    }

    if (average == -1) {
      throw new IllegalArgumentException("The date is not found in database");
    }

    return average;
  }

  @Override
  public List<String> findCrossoverDays(String startDate, String endDate, int days)
          throws IllegalArgumentException {
    List<String> crossoverDays = new ArrayList<>();
    LocalDate start;
    LocalDate end;
    boolean inRange = false;
    double closePrice;
    double xDaysAverage;

    try {
      start = LocalDate.parse(startDate);
      end = LocalDate.parse(endDate);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date format");
    }

    if (start.isAfter(end)) {
      throw new IllegalArgumentException("Start date must be before end date");
    }

    for (String[] datum : data) {
      if (datum[0].equals(endDate)) {
        inRange = true;
      }
      if (inRange) {
        closePrice = Double.parseDouble(datum[4]);
        xDaysAverage = calculateMovingAverage(datum[0], days);
        if (closePrice > xDaysAverage) {
          crossoverDays.add(datum[0]);
        }
        if (datum[0].equals(startDate)) {
          inRange = false;
        }
      }
    }

    return crossoverDays;
  }
}
