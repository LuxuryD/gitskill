package view;

import javax.swing.*;

public class CheckStock {
  private JPanel checkStockPanel;
  private JPanel mainPanel;
  private JLabel instOne;
  private JLabel instTwo;
  private JLabel instThree;
  private JTextField textField1;
  private JTextField textField2;
}
