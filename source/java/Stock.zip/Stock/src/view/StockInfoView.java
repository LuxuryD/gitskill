package view;


/**
 * Viewer for this program.
 */
public class StockInfoView {

  private final String welcome;
  private final String menuOne;
  private final String menuTwo;
  private final String input;
  private final String inputCode;
  private final String inputStartDate;
  private final String inputEndDate;
  private final String inputX;
  private final String inputPortfolioName;
  private final String duplicatePortfolioName;
  private final String stockNumber;
  private final String done;
  private final String next;
  private final String nextTwo;
  private final String quit;
  private final String invalidInput;
  private final String date;
  private final String portfolioSubMenu;
  private final String purchaseQuantity;
  private final String sellQuantity;
  private final String keepWorkingOnCurrentPortfolio;
  private final String successfulCreatingPortfolio;
  private final String purchaseOrSell;
  private final String successfullOperation;
  private final String weight;
  private final String askForRebalance;
  private final String askForSaveLoad;
  private final String saveFileAlreadyExist;
  private final String keepSavingFile;
  private final String loadFileAlreadyExist;
  private final String keepLoadingFile;
  private final String askForYear;
  private final String askForMonth;
  private final String askForDay;
  private final String askForDate;

  /**
   * Constructor that initialize view data.
   */
  public StockInfoView() {
    this.welcome = "Welcome to the Easy Stock program!"
            + System.lineSeparator()
            + "In this program, you will be able to use the following functions"
            + "to learn and build your ability in the stock trading market."
            + System.lineSeparator();
    this.menuOne = "You can do the following by inputting operation Number."
            + System.lineSeparator()
            + "the operation Number is provided in the Parentheses"
            + System.lineSeparator();
    this.menuTwo = "(1) Checking the gain/loss of a stock over a period"
            + System.lineSeparator()
            + "(2) Checking the x-day moving average of a stock with specified date "
            + "and x"
            + System.lineSeparator()
            + "(3) Checking which days are x-day crossovers for a stock"
            + System.lineSeparator()
            + "(4) Portfolio operation"
            + System.lineSeparator()
            + "(5) Performance bar chart for a stock during certain period"
            + System.lineSeparator()
            + "(quit) Quit program"
            + System.lineSeparator();
    this.input = "Please enter your operation: "
            + System.lineSeparator();
    this.inputCode = "Please enter the stock code："
            + System.lineSeparator();
    this.inputStartDate = "Please enter the start date: "
            + System.lineSeparator();
    this.inputEndDate = "Please enter the end date: "
            + System.lineSeparator();
    this.inputX = "Please enter the x value (integer) for x-day moving average: "
            + System.lineSeparator();
    this.inputPortfolioName = "Please enter the name of your portfolio: "
            + System.lineSeparator();
    this.stockNumber = "Please enter the number of stock you are purchasing: "
            + System.lineSeparator();
    this.done = "Your operation is successful."
            + System.lineSeparator()
            + "Enter (done) to back to menu"
            + System.lineSeparator();
    this.next = done
            + "Enter (next) create a new portfolio."
            + System.lineSeparator();
    this.quit = "Thank you for your using, see you next time."
            + System.lineSeparator();
    this.invalidInput = "Invalid operation code, please check your input and try again."
            + System.lineSeparator();
    this.duplicatePortfolioName = "This portfolio already exists. "
            + "Would you like to add more items to it? "
            + System.lineSeparator()
            + "Enter 'Yes' to add more, or enter any other command to "
            + "create a new portfolio with that name."
            + System.lineSeparator();
    this.nextTwo = "Your operation is successful, enter (done) to finish current portfolio, enter"
            + " (next) to enter another stock in your current portfolio"
            + System.lineSeparator();
    this.date = "Please enter the date you are purchasing for (yyyy-mm-dd): "
            + System.lineSeparator();
    this.portfolioSubMenu = "Please Enter the following operation Number:"
            + System.lineSeparator()
            + "(1) Create a new portfolio"
            + System.lineSeparator()
            + "(2) Edit a current portfolio"
            + System.lineSeparator()
            + "(3) Check combination of a portfolio on a specific date"
            + System.lineSeparator()
            + "(4) Check the value of a portfolio on a specific date"
            + System.lineSeparator()
            + "(5) Check the distribution of a portfolio on a specific date"
            + System.lineSeparator()
            + "(6) Rebalance a portfolio on a specific day"
            + System.lineSeparator()
            + "(7) Demonstrate the performance as a chart in certain period"
            + System.lineSeparator()
            + "(8) Save / load "
            + System.lineSeparator()
            + "(9) Back to main menu"
            + System.lineSeparator();
    this.purchaseQuantity = "Please enter the quantity of stock you are purchasing. (Please "
            + "enter an Integer)"
            + System.lineSeparator();
    this.sellQuantity = "Please enter the quantity of stock you are selling."
            + " (decimal number is allowed)"
            + System.lineSeparator();
    this.keepWorkingOnCurrentPortfolio = "Do you want to keep working on current portfolio?"
            + System.lineSeparator()
            + "(Yes/No)"
            + System.lineSeparator();
    this.successfulCreatingPortfolio = "You have successfully created this portfolio. You can edit"
            + " this portfolio by using edit function."
            + System.lineSeparator();
    this.purchaseOrSell = "Please enter (operation number) if you want to purchase (1) or sell (2)"
            + System.lineSeparator();
    this.successfullOperation = "Your operation is sucessful."
            + System.lineSeparator();
    this.weight = "Please enter the weight of each stock you expected for current portfolio."
            + System.lineSeparator()
            + "eg. if I have total 4 pieces of stock in a portfolio, "
            + "then the weight of them should be: "
            + System.lineSeparator()
            + "0.25, 0.25, 0.25, 0.25"
            + System.lineSeparator()
            + "The sum of these weights should be 1"
            + System.lineSeparator();
    this.askForRebalance = "Do you want to rebalance your potfolio on this day? (Yes/No)"
            + System.lineSeparator();
    this.askForSaveLoad = "Do you want to save or load portfolio?"
            + System.lineSeparator()
            + "(1) save current portfolio as xml file"
            + System.lineSeparator()
            + "(2) load portfolio from xml file"
            + System.lineSeparator();
    this.saveFileAlreadyExist = "This portfolio is already existed."
            + System.lineSeparator();
    this.keepSavingFile = "Do you want to save it? This will cover what we have in the directory"
            + " (Yes/No)"
            + System.lineSeparator();
    this.loadFileAlreadyExist = "The portfolio you selected to load"
            + " is already exist in the program"
            + System.lineSeparator();
    this.keepLoadingFile = "Do you want to load it? THis will cover what we have in the program"
            + " (Yes/No)"
            + System.lineSeparator();
    this.askForYear = "Please enter the year of the date"
            + System.lineSeparator();
    this.askForMonth = "Please enter the month of the date"
            + System.lineSeparator();
    this.askForDay = "Please enter the day of the date"
            + System.lineSeparator();
    this.askForDate = "Please enter the date"
            + System.lineSeparator();
  }

  /**
   * Ask for date message.
   *
   * @return ask for date message
   */
  public String askForDateMessage() {
    return askForDate;
  }

  /**
   * Ask for year message.
   *
   * @return ask for year message
   */
  public String askForYearMessage() {
    return askForYear;
  }

  /**
   * Ask for month message.
   *
   * @return ask for month message
   */
  public String askForMonthMessage() {
    return askForMonth;
  }

  /**
   * Ask for day message.
   *
   * @return ask for day message
   */
  public String askForDayMessage() {
    return askForDay;
  }

  /**
   * Save file already exist message.
   *
   * @return save file already exist message
   */
  public String saveFileAlreadyExistMessage() {
    return saveFileAlreadyExist;
  }

  /**
   * Keep saving file message.
   *
   * @return keep saving file message
   */
  public String keepSavingFileMessage() {
    return keepSavingFile;
  }

  /**
   * Load file already exist message.
   *
   * @return load file already exist message.
   */
  public String loadFileAlreadyExistMessage() {
    return loadFileAlreadyExist;
  }

  /**
   * Keep loading file message.
   *
   * @return keep loading file message.
   */
  public String keepLoadingFileMessage() {
    return keepLoadingFile;
  }

  /**
   * Purchase quantity message.
   *
   * @return purchase quantity message
   */
  public String purchaseQuantityMessage() {
    return purchaseQuantity;
  }

  /**
   * Successful operation message.
   *
   * @return successful operation message.
   */
  public String successfullOperationMessage() {
    return successfullOperation;
  }

  /**
   * Sell quantity message.
   *
   * @return sell quantity message
   */
  public String sellQuantityMessage() {
    return sellQuantity;
  }

  /**
   * Keep working on current portfolio message.
   *
   * @return keep working on current portfolio message
   */
  public String keepWorkingOnCurrentPortfolioMessage() {
    return keepWorkingOnCurrentPortfolio;
  }

  /**
   * Successful creating portfolio message.
   *
   * @return successful creating portfolio message
   */
  public String successfulCreatingPortfolioMessage() {
    return successfulCreatingPortfolio;
  }

  /**
   * Purchase or sell message.
   *
   * @return purchase or sell message
   */
  public String purchaseOrSellMessage() {
    return purchaseOrSell;
  }

  /**
   * Asking for weight message.
   *
   * @return weight Message
   */
  public String weightMessage() {
    return weight;
  }

  /**
   * Ask for rebalance message.
   *
   * @return ask for rebalance message
   */
  public String askForRebalanceMessage() {
    return askForRebalance;
  }

  /**
   * Ask for save load.
   *
   * @return ask for save load message
   */
  public String askForSaveLoad() {
    return askForSaveLoad;
  }

  /**
   * Return welcome message.
   *
   * @return welcome message
   */
  public String welcomeMessage() {
    return welcome;
  }

  /**
   * Return instruction menu message.
   *
   * @return instruction menu message
   */
  public String instructionMenuMessage() {
    return menuOne;
  }

  /**
   * Return operation menu message.
   *
   * @return operation menu message
   */
  public String operationMenuMessage() {
    return menuTwo;
  }

  /**
   * Return done message.
   *
   * @return done message
   */
  public String doneMessage() {
    return done;
  }

  /**
   * Return next message.
   *
   * @return next message
   */
  public String nextMessage() {
    return next;
  }

  /**
   * Return quit message.
   *
   * @return quit message
   */
  public String quitMessage() {
    return quit;
  }

  /**
   * Return invalid input message.
   *
   * @return invalid input message
   */
  public String invalidInputMessage() {
    return invalidInput;
  }

  /**
   * Return input stock code message.
   *
   * @return input stock code message
   */
  public String inputCodeMessage() {
    return inputCode;
  }

  /**
   * Return input start date message.
   *
   * @return input start date message
   */
  public String inputStartDateMessage() {
    return inputStartDate;
  }

  /**
   * Return input end date message.
   *
   * @return input end date message
   */
  public String inputEndDateMessage() {
    return inputEndDate;
  }

  /**
   * Return input x message.
   *
   * @return input x message
   */
  public String inputXMessage() {
    return inputX;
  }

  /**
   * Return input portfolio name message.
   *
   * @return input portfolio name message
   */
  public String inputPortfolioNameMessage() {
    return inputPortfolioName;
  }

  /**
   * Return stock number message.
   *
   * @return stock number message
   */
  public String stockNumberMessage() {
    return stockNumber;
  }

  /**
   * Return input message.
   *
   * @return input message
   */
  public String inputMessage() {
    return input;
  }

  /**
   * Return duplicate portfolio name message.
   *
   * @return duplicate portfolio name message
   */
  public String duplicatePortfolioNameMessage() {
    return duplicatePortfolioName;
  }

  /**
   * Return another version of next message.
   *
   * @return another version of next message
   */
  public String nextTwoMessage() {
    return nextTwo;
  }

  /**
   * Return date message.
   *
   * @return date message.
   */
  public String dateMessage() {
    return date;
  }

  public String getPortfolioSubMenu() {
    return portfolioSubMenu;
  }

}
