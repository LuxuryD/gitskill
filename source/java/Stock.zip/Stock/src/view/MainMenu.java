package view;

import javax.swing.*;

public class MainMenu {
  private JPanel rootPanel;
  private JPanel mainMenuPanel;
  private JPanel stockPanel;
  private JPanel portfolioPanel;
  private JButton quitButton;
  private JButton checkStockButton;
  private JButton checkAverageButton;
  private JButton checkCrossOverButton;
  private JButton stockBarChartButton;
  private JButton creatPortfolioButton;
  private JButton editPortfolioButton;
  private JButton checkCombinationButton;
  private JButton checkDistributionButton;
  private JButton rebalanceAPortfolioButton;
  private JButton checkTotalValueOfButton;
  private JButton barChartButton;
  private JButton saveButton;
  private JLabel welcomeMessage;
  private JButton loadButton;

  public static void main(String[] args) {
    JFrame menu = new JFrame("Main Menu");
    menu.setContentPane(new MainMenu().mainMenuPanel);
    menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    menu.pack();
    menu.setVisible(true);
  }

}
